﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Services;

namespace SunRise.HOSP.Web
{
    /// <summary>
    /// CallServiceSoapClientNCKQYY
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消对下行的注释。
    // [System.Web.Script.Services.ScriptService]
    public class CallServiceSoapClientNCKQYY : System.Web.Services.WebService
    {
        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }
        [WebMethod]
        public string runservice(string InValue)
        {
            string response = string.Empty;
            #region   //1.1	获取病人信息（XH01001）
            if (InValue.Contains("<TRADEMSG>XH01001</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                //sb.AppendFormat("<ROOT>");
                //sb.AppendFormat("<HEADER><TRADEMSG>XH01001</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER>");
                //sb.AppendFormat("<BODY><BRID>0001147331</BRID><BRXM>管春</BRXM><BRXB>2</BRXB><SFZH>360102197202066326</SFZH><CSRQ>1972-02-06</CSRQ><HYZK>1</HYZK><MZDM>1</MZDM><JGDM>1</JGDM><SJHM>18979156836</SJHM><LXDZ>LXDZ</LXDZ><BRXZ>BRXZ</BRXZ><JZKH>360102197202066326</JZKH><YBKH></YBKH><NBKH></NBKH><MZH>360102197202066326</MZH><YCBZ>1</YCBZ><ZHZT>1</ZHZT><CJSH></CJSH><JZLX></JZLX><YCYE>3</YCYE><BRXBMC>女</BRXBMC><BAH>BAH</BAH><ZJLXDM>ZJLXDM</ZJLXDM><ZJLX>ZJLX</ZJLX><YBBZ>1</YBBZ><BRLX>省本级</BRLX><BRLXDM>4</BRLXDM><ZHXX>0^1133287^00011473310001^0^^0^^1148284^0001147331^1185720^P^^17^^0^1133287^00011473310001^0^^0^^1148284^0001147331^1185720^P^^17^</ZHXX><YNZH>1133287</YNZH></BODY>");
                sb.AppendFormat("<ROOT><HEADER><TRADEMSG>XH01001</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><BRID>1000472970</BRID><BRXM>黄怀英</BRXM><BRXB>男</BRXB><SFZH>54012319810516475X</SFZH><CSRQ>1981-05-16</CSRQ><HYZK> </HYZK><MZDM>汉族</MZDM><JGDM> </JGDM><SJHM>18098787890</SJHM><LXDZ> </LXDZ><BRXZ>0</BRXZ><JZKH>1000472970</JZKH><YBKH></YBKH><NBKH></NBKH><MZH></MZH><YCBZ></YCBZ><ZHZT></ZHZT><CJSH>2018-08-08</CJSH><JZLX>0</JZLX><YCYE>7.06</YCYE><ZYYCJE>0</ZYYCJE><ZYXFJE>0</ZYXFJE><YNZH>1000472970</YNZH></BODY></ROOT>");



                return sb.ToString();
            }

            #endregion

            #region   新病人建档（XH02003）
            if (InValue.Contains("<TRADEMSG>XH02003</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH02003</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<JZKH>360102197202066326</JZKH><MZH></MZH><BRID>0001147331</BRID><SFJH>0</SFJH><JYLSH>360102197202066326</JYLSH><YE>0.00</YE>");
                sb.AppendFormat("</BODY></ROOT>");



                return sb.ToString();
            }

            #endregion

            #region   //更新病人信息（XH02002）
            if (InValue.Contains("<TRADEMSG>XH02002</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH02002</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER>");
                //sb.AppendFormat("<BODY><BRID>0001147331</BRID></BODY>");
                sb.AppendFormat("</ROOT>");



                return sb.ToString();
            }

            #endregion

            #region   查询科室排班信息（XH03008）
            if (InValue.Contains("<TRADEMSG>XH03008</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                //sb.AppendFormat("<ROOT>");
                //sb.AppendFormat("<HEADER><TRADEMSG>XH03008</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                //sb.AppendFormat("<ITEM><KSBH>260</KSBH><KSMC>磁共振室</KSMC><KSLB>1</KSLB><SJKSBH>-1</SJKSBH><SJKSMC>-1</SJKSMC><Sort>1</Sort><KSWZ>门诊楼一楼</KSWZ></ITEM>");
                //sb.AppendFormat("<ITEM><KSBH>231</KSBH><KSMC>儿童眼科门诊</KSMC><KSLB>1</KSLB><SJKSBH>-1</SJKSBH><SJKSMC>-1</SJKSMC><Sort>2</Sort><KSWZ>综合大楼一楼</KSWZ></ITEM>");
                //sb.AppendFormat("<ITEM><KSBH>266</KSBH><KSMC>感染性疾病科门诊</KSMC><KSLB>1</KSLB><SJKSBH>-1</SJKSBH><SJKSMC>-1</SJKSMC><Sort>3</Sort><KSWZ>门诊楼一楼</KSWZ></ITEM>");
                //sb.AppendFormat("<ITEM><KSBH>267</KSBH><KSMC>皮肤科门诊</KSMC><KSLB>1</KSLB><SJKSBH>-1</SJKSBH><SJKSMC>-1</SJKSMC><Sort>4</Sort><KSWZ>门诊楼一楼</KSWZ></ITEM>");
                //sb.AppendFormat("</BODY></ROOT>");
                //return sb.ToString();

                string sss = @"<ROOT><HEADER><TRADEMSG>XH03008</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需(李启顺)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>1</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需(欧阳志强)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>2</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(廖岚)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>3</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(杨瑛)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>4</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需(李启顺)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>5</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需门诊(朱洪水)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>6</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>02010106</KSBH><KSMC>粘膜牙周科</KSMC><KSLB>粘膜科(黄美贞)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>7</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(杨健)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>8</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>020105</KSBH><KSMC>口腔种植科</KSMC><KSLB>种植科(吴润发)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>9</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(石连水)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>10</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020107</KSBH><KSMC>综合诊室</KSMC><KSLB>综合门诊(李学群)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>11</Sort><KSWZ>一楼</KSWZ></ITEM><ITEM><KSBH>020104</KSBH><KSMC>口腔预防科</KSMC><KSLB>预防科(万莉)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>12</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>020112</KSBH><KSMC>儿童口腔科</KSMC><KSLB>儿童科(黄彦)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>13</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(胡晓萍)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>14</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(郭小文)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>15</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020106</KSBH><KSMC>口腔颌面外科门诊</KSMC><KSLB>口外门诊(梁凯)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>16</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(付玉林)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>17</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020106</KSBH><KSMC>口腔颌面外科门诊</KSMC><KSLB>口外门诊(谭伟兵)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>18</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(刘红宝)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>19</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需门诊(胡楠)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>20</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>02010301</KSBH><KSMC>口腔正畸2科</KSMC><KSLB>正畸科(刘剑)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>21</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需门诊(李群)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>22</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>020104</KSBH><KSMC>口腔预防科</KSMC><KSLB>预防科(熊伟)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>23</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需(欧阳志强)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>24</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>020106</KSBH><KSMC>口腔颌面外科门诊</KSMC><KSLB>口外门诊(曾昭源)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>25</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020106</KSBH><KSMC>口腔颌面外科门诊</KSMC><KSLB>口外门诊(吴坚)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>26</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020112</KSBH><KSMC>儿童口腔科</KSMC><KSLB>儿童科(黄彦)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>27</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>02010301</KSBH><KSMC>口腔正畸2科</KSMC><KSLB>正畸科(姚芬)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>28</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>02010303</KSBH><KSMC>口腔正畸1科</KSMC><KSLB>正畸科(伍军)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>29</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>02010301</KSBH><KSMC>口腔正畸2科</KSMC><KSLB>正畸科(李志华)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>30</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>02010106</KSBH><KSMC>粘膜牙周科</KSMC><KSLB>粘膜科(宗娟娟)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>31</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需门诊(黄玮)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>32</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>020104</KSBH><KSMC>口腔预防科</KSMC><KSLB>预防科(欧晓艳)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>33</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>02010105</KSBH><KSMC>牙周科</KSMC><KSLB>牙周科(金幼虹)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>34</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(郑治国)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>35</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(王梦秀)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>36</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(邓梁昌)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>37</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(曾利伟)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>38</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(王建鸿)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>39</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(孙益平)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>40</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(李东方)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>41</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(郭小文)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>42</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(石连水)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>43</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需门诊(朱洪水)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>44</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>02010301</KSBH><KSMC>口腔正畸2科</KSMC><KSLB>正畸科(刘剑)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>45</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(王建鸿)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>46</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(陶天庆)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>47</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010303</KSBH><KSMC>口腔正畸1科</KSMC><KSLB>正畸科(唐镇)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>48</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>020107</KSBH><KSMC>综合诊室</KSMC><KSLB>综合门诊(王予江)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>49</Sort><KSWZ>一楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(连文伟)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>50</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010301</KSBH><KSMC>口腔正畸2科</KSMC><KSLB>正畸科(李志华)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>51</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(李东方)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>52</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020112</KSBH><KSMC>儿童口腔科</KSMC><KSLB>儿童科(赵爱民)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>53</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(胡晓萍)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>54</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020106</KSBH><KSMC>口腔颌面外科门诊</KSMC><KSLB>口外门诊(陈林林)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>55</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010106</KSBH><KSMC>粘膜牙周科</KSMC><KSLB>粘膜科(宗娟娟)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>56</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>020106</KSBH><KSMC>口腔颌面外科门诊</KSMC><KSLB>口外门诊(谭伟兵)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>57</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需(李启顺)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>58</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>020107</KSBH><KSMC>综合诊室</KSMC><KSLB>综合门诊(李学群)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>59</Sort><KSWZ>一楼</KSWZ></ITEM><ITEM><KSBH>02010106</KSBH><KSMC>粘膜牙周科</KSMC><KSLB>粘膜科(黄美贞)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>60</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010303</KSBH><KSMC>口腔正畸1科</KSMC><KSLB>正畸科(伍军)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>61</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>020105</KSBH><KSMC>口腔种植科</KSMC><KSLB>种植科(吴润发)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>62</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>020107</KSBH><KSMC>综合诊室</KSMC><KSLB>综合门诊(戴群)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>63</Sort><KSWZ>一楼</KSWZ></ITEM><ITEM><KSBH>020112</KSBH><KSMC>儿童口腔科</KSMC><KSLB>儿童科(赵爱民)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>64</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>020106</KSBH><KSMC>口腔颌面外科门诊</KSMC><KSLB>口外门诊(陈林林)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>65</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需(欧阳志强)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>66</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需门诊(胡楠)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>67</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需门诊(李群)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>68</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(连文伟)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>69</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(孙益平)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>70</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(杨瑛)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>71</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(张洪斌)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>72</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(邓梁昌)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>73</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(杨健)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>74</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(郑治国)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>75</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010105</KSBH><KSMC>牙周科</KSMC><KSLB>牙周科(金幼虹)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>76</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>020104</KSBH><KSMC>口腔预防科</KSMC><KSLB>预防科(欧晓艳)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>77</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>020104</KSBH><KSMC>口腔预防科</KSMC><KSLB>预防科(万莉)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>78</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>02010301</KSBH><KSMC>口腔正畸2科</KSMC><KSLB>正畸科(葛红珊)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>79</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>020104</KSBH><KSMC>口腔预防科</KSMC><KSLB>预防科(熊伟)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>80</Sort><KSWZ>五楼</KSWZ></ITEM><ITEM><KSBH>02010301</KSBH><KSMC>口腔正畸2科</KSMC><KSLB>正畸科(葛红珊)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>81</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(王梦秀)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>82</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010104</KSBH><KSMC>牙体牙髓科</KSMC><KSLB>牙体牙髓(刘红宝)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>83</Sort><KSWZ>三楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(张洪斌)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>84</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010234</KSBH><KSMC>口腔修复1科</KSMC><KSLB>修复科(曾利伟)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>85</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010233</KSBH><KSMC>口腔修复2科</KSMC><KSLB>修复科(付玉林)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>86</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010303</KSBH><KSMC>口腔正畸1科</KSMC><KSLB>正畸科(黄臻)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>87</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>02010303</KSBH><KSMC>口腔正畸1科</KSMC><KSLB>正畸科(唐镇)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>88</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>020107</KSBH><KSMC>综合诊室</KSMC><KSLB>综合门诊(戴群)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>89</Sort><KSWZ>一楼</KSWZ></ITEM><ITEM><KSBH>020106</KSBH><KSMC>口腔颌面外科门诊</KSMC><KSLB>口外门诊(梁凯)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>90</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020106</KSBH><KSMC>口腔颌面外科门诊</KSMC><KSLB>口外门诊(吴坚)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>91</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需门诊(黄玮)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>92</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>020107</KSBH><KSMC>综合诊室</KSMC><KSLB>综合门诊(王予江)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>93</Sort><KSWZ>一楼</KSWZ></ITEM><ITEM><KSBH>020106</KSBH><KSMC>口腔颌面外科门诊</KSMC><KSLB>口外门诊(曾昭源)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>94</Sort><KSWZ>二楼</KSWZ></ITEM><ITEM><KSBH>02010301</KSBH><KSMC>口腔正畸2科</KSMC><KSLB>正畸科(姚芬)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>95</Sort><KSWZ>四楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需门诊(朱洪水)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>96</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>020109</KSBH><KSMC>特需门诊</KSMC><KSLB>特需(李启顺)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>97</Sort><KSWZ>六楼</KSWZ></ITEM><ITEM><KSBH>02010303</KSBH><KSMC>口腔正畸1科</KSMC><KSLB>正畸科(黄臻)</KSLB><SJKSBH> </SJKSBH><SJKSMC> </SJKSMC><Sort>98</Sort><KSWZ>四楼</KSWZ></ITEM></BODY></ROOT>";
                sb.Append(sss);
                return sb.ToString();
            }

            #endregion
            #region  查询专家排班信息（XH03009）
            if (InValue.Contains("<TRADEMSG>XH03009</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                //sb.AppendFormat("<ROOT>");
                //sb.AppendFormat("<HEADER><TRADEMSG>XH03009</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");

                //sb.AppendFormat("<ITEM><PBZJ>2141||29</PBZJ><YSGH>200</YSGH><YSXM>杨雅</YSXM><YSZC>主任医生号</YSZC><GHF>12</GHF><ZLF>2</ZLF><ZFY>14</ZFY><JZSJ>1</JZSJ><SYHY>25</SYHY><PBRQ>2018-07-20</PBRQ><GHKSMC>内分泌代谢科门诊</GHKSMC><GHKSBH>138</GHKSBH><KSSJ>08:00</KSSJ><JSSJ>11:45</JSSJ><QTF>0</QTF><SYHXX>6,7,8,9,10,11,12,13,14,15,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,33,34,35,36,37,38,39,40,41,42</SYHXX><JZDD>门诊楼二楼</JZDD><XQS>XQS</XQS></ITEM>");
                //sb.AppendFormat("<ITEM><PBZJ>2143||24</PBZJ><YSGH>200</YSGH><YSXM>杨雅1</YSXM><YSZC>主任医生号1</YSZC><GHF>12</GHF><ZLF>2</ZLF><ZFY>14</ZFY><JZSJ>2</JZSJ><SYHY>25</SYHY><PBRQ>2018-07-21</PBRQ><GHKSMC>内分泌代谢科门诊</GHKSMC><GHKSBH>138</GHKSBH><KSSJ>13:00</KSSJ><JSSJ>17:45</JSSJ><QTF>0</QTF><SYHXX>6,7,8,9,10,11,12,13,14,15,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,33,34,35,36,37,38,39,40,41,42</SYHXX><JZDD>门诊楼二楼</JZDD><XQS>XQS</XQS></ITEM>");
                // sb.AppendFormat("</BODY></ROOT>");




                string sss = @"<ROOT><HEADER><TRADEMSG>XH03009</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ITEM><PBZJ>正畸科(刘剑)|20180813|上午|</PBZJ><YSGH>142</YSGH><YSXM>刘剑()</YSXM><YSZC>副主任医师</YSZC><GHF>0</GHF><ZLF>22</ZLF><ZFY>22</ZFY><JZSJ>上午</JZSJ><SYHY>13</SYHY><PBRQ>2018-09-04</PBRQ><GHKSMC>口腔正畸2科</GHKSMC><GHKSBH>02010301</GHKSBH><KSSJ>08:00</KSSJ><JSSJ>12:00</JSSJ><QTF>0</QTF><SYHXX></SYHXX><JZDD>四楼</JZDD><XQS>星期一</XQS><YSJS></YSJS></ITEM><ITEM><PBZJ>正畸科(姚芬)|20180814|上午|</PBZJ><YSGH>144</YSGH><YSXM>姚芬</YSXM><YSZC>副主任医师</YSZC><GHF>0</GHF><ZLF>22</ZLF><ZFY>22</ZFY><JZSJ>上午</JZSJ><SYHY>18</SYHY><PBRQ>2018-09-04</PBRQ><GHKSMC>口腔正畸2科</GHKSMC><GHKSBH>02010301</GHKSBH><KSSJ>08:00</KSSJ><JSSJ>12:00</JSSJ><QTF>0</QTF><SYHXX></SYHXX><JZDD>四楼</JZDD><XQS>星期二</XQS><YSJS></YSJS></ITEM><ITEM><PBZJ>正畸科(李志华)|20180814|下午|</PBZJ><YSGH>140</YSGH><YSXM>李志华</YSXM><YSZC>主任医师</YSZC><GHF>0</GHF><ZLF>50</ZLF><ZFY>50</ZFY><JZSJ>下午</JZSJ><SYHY>6</SYHY><PBRQ>2018-09-05</PBRQ><GHKSMC>口腔正畸2科</GHKSMC><GHKSBH>02010301</GHKSBH><KSSJ>14:00</KSSJ><JSSJ>16:30</JSSJ><QTF>0</QTF><SYHXX></SYHXX><JZDD>四楼</JZDD><XQS>星期二</XQS><YSJS></YSJS></ITEM><ITEM><PBZJ>正畸科(李志华)|20180815|下午|</PBZJ><YSGH>140</YSGH><YSXM>李志华</YSXM><YSZC>主任医师</YSZC><GHF>0</GHF><ZLF>50</ZLF><ZFY>50</ZFY><JZSJ>下午</JZSJ><SYHY>6</SYHY><PBRQ>2018-09-05</PBRQ><GHKSMC>口腔正畸2科</GHKSMC><GHKSBH>02010301</GHKSBH><KSSJ>14:00</KSSJ><JSSJ>16:30</JSSJ><QTF>0</QTF><SYHXX></SYHXX><JZDD>四楼</JZDD><XQS>星期三</XQS><YSJS></YSJS></ITEM><ITEM><PBZJ>正畸科(刘剑)|20180815|上午|</PBZJ><YSGH>142</YSGH><YSXM>刘剑</YSXM><YSZC>副主任医师</YSZC><GHF>0</GHF><ZLF>22</ZLF><ZFY>22</ZFY><JZSJ>上午</JZSJ><SYHY>13</SYHY><PBRQ>2018-09-06</PBRQ><GHKSMC>口腔正畸2科</GHKSMC><GHKSBH>02010301</GHKSBH><KSSJ>08:00</KSSJ><JSSJ>12:00</JSSJ><QTF>0</QTF><SYHXX></SYHXX><JZDD>四楼</JZDD><XQS>星期三</XQS><YSJS></YSJS></ITEM><ITEM><PBZJ>正畸科(葛红珊)|20180817|上午|</PBZJ><YSGH>141</YSGH><YSXM>葛红珊</YSXM><YSZC>主任医师</YSZC><GHF>0</GHF><ZLF>25</ZLF><ZFY>25</ZFY><JZSJ>上午</JZSJ><SYHY>24</SYHY><PBRQ>2018-09-07</PBRQ><GHKSMC>口腔正畸2科</GHKSMC><GHKSBH>02010301</GHKSBH><KSSJ>08:00</KSSJ><JSSJ>12:00</JSSJ><QTF>0</QTF><SYHXX></SYHXX><JZDD>四楼</JZDD><XQS>星期五</XQS><YSJS></YSJS></ITEM><ITEM><PBZJ>正畸科(葛红珊)|20180817|下午|</PBZJ><YSGH>141</YSGH><YSXM>葛红珊</YSXM><YSZC>主任医师</YSZC><GHF>0</GHF><ZLF>25</ZLF><ZFY>25</ZFY><JZSJ>下午</JZSJ><SYHY>21</SYHY><PBRQ>2018-09-07</PBRQ><GHKSMC>口腔正畸2科</GHKSMC><GHKSBH>02010301</GHKSBH><KSSJ>14:00</KSSJ><JSSJ>17:30</JSSJ><QTF>0</QTF><SYHXX></SYHXX><JZDD>四楼</JZDD><XQS>星期五</XQS><YSJS></YSJS></ITEM><ITEM><PBZJ>正畸科(姚芬)|20180818|上午|</PBZJ><YSGH>144</YSGH><YSXM>姚芬</YSXM><YSZC>副主任医师</YSZC><GHF>0</GHF><ZLF>22</ZLF><ZFY>22</ZFY><JZSJ>上午</JZSJ><SYHY>18</SYHY><PBRQ>2018-09-08</PBRQ><GHKSMC>口腔正畸2科</GHKSMC><GHKSBH>02010301</GHKSBH><KSSJ>08:00</KSSJ><JSSJ>12:00</JSSJ><QTF>0</QTF><SYHXX></SYHXX><JZDD>四楼</JZDD><XQS>星期六</XQS><YSJS></YSJS></ITEM></BODY></ROOT>";
                sb.Append(sss);
                return sb.ToString();
            }

            #endregion
            #region  查询专家预约排班时间段（XH03010）
            if (InValue.Contains("<TRADEMSG>XH03010</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT><HEADER><TRADEMSG>XH03010</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ITEM><SDBH>正畸科(李志华)|20180814|下午|2|</SDBH><SJD>14:25</SJD><SDHY>正畸科(李志华)|20180814|下午|2|</SDHY><SDBS>正畸科(李志华)|20180814|下午|2|</SDBS></ITEM><ITEM><SDBH>正畸科(李志华)|20180814|下午|4|</SDBH><SJD>15:15</SJD><SDHY>正畸科(李志华)|20180814|下午|4|</SDHY><SDBS>正畸科(李志华)|20180814|下午|4|</SDBS></ITEM><ITEM><SDBH>正畸科(李志华)|20180814|下午|6|</SDBH><SJD>16:05</SJD><SDHY>正畸科(李志华)|20180814|下午|6|</SDHY><SDBS>正畸科(李志华)|20180814|下午|6|</SDBS></ITEM></BODY></ROOT>");
                /*<?xml version="1.0" encoding="UTF-8"?><ROOT><HEADER><TRADEMSG>XH03010</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ITEM><SDBH>正畸科(李志华)|20180814|下午|2|</SDBH><SJD>14:25</SJD><SDHY>正畸科(李志华)|20180814|下午|2|</SDHY><SDBS>正畸科(李志华)|20180814|下午|2|</SDBS></ITEM><ITEM><SDBH>正畸科(李志华)|20180814|下午|4|</SDBH><SJD>15:15</SJD><SDHY>正畸科(李志华)|20180814|下午|4|</SDHY><SDBS>正畸科(李志华)|20180814|下午|4|</SDBS></ITEM><ITEM><SDBH>正畸科(李志华)|20180814|下午|6|</SDBH><SJD>16:05</SJD><SDHY>正畸科(李志华)|20180814|下午|6|</SDHY><SDBS>正畸科(李志华)|20180814|下午|6|</SDBS></ITEM></BODY></ROOT>*/
                return sb.ToString();
            }

            #endregion

            #region 挂号预结算（XH03017）
            if (InValue.Contains("<TRADEMSG>XH03017</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT><HEADER><TRADEMSG>XH03017</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ZJE>0.00</ZJE><YBZFJE></YBZFJE><GRZFJE></GRZFJE><GHXH>20180811000793</GHXH><YBXX></YBXX></BODY></ROOT>");
                /*
                 <?xml version="1.0" encoding="UTF-8"?>
                 */
                return sb.ToString();
            }

            #endregion

            #region 挂号结算（XH03018）
            if (InValue.Contains("<TRADEMSG>XH03018</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT><HEADER><TRADEMSG>XH03018</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><GHXH>4</GHXH><FPH>2018081148602</FPH><JZDD>四楼</JZDD><HL>正畸科(李志华)</HL></BODY></ROOT>");
                /*
                 <?xml version="1.0" encoding="UTF-8"?>
                 */
                return sb.ToString();
            }

            #endregion

            #region 获取未缴费就诊记录（XH05070）
            if (InValue.Contains("<TRADEMSG>XH05070</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                //sb.AppendFormat("<ROOT>");
                //sb.AppendFormat("<HEADER><TRADEMSG>XH05070</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                //sb.AppendFormat("<ITEM><JZLSH>123</JZLSH><JZRQ>2018-06-26</JZRQ><JZSJ>8:00~9:00</JZSJ><KSDM>10138</KSDM><KSMC>内分泌代谢科门诊</KSMC><YSXM>刘建萍</YSXM><YSDM>14105</YSDM><JSKSMC></JSKSMC><JSKSDM></JSKSDM><JSYSDM></JSYSDM><JSYSXM></JSYSXM><WJFJE>450.00</WJFJE><JSLXDM>0</JSLXDM><JSLX>自费</JSLX><YBLXMC></YBLXMC><YBLXDM></YBLXDM></ITEM>");
                //sb.AppendFormat("<ITEM><JZLSH>124</JZLSH><JZRQ>2018-06-26</JZRQ><JZSJ>8:30~9:00</JZSJ><KSDM>10118</KSDM><KSMC>皮肤科门诊</KSMC><YSXM>刘建萍2</YSXM><YSDM>14105</YSDM><JSKSMC></JSKSMC><JSKSDM></JSKSDM><JSYSDM></JSYSDM><JSYSXM></JSYSXM><WJFJE>110.00</WJFJE><JSLXDM>0</JSLXDM><JSLX>自费</JSLX><YBLXMC></YBLXMC><YBLXDM></YBLXDM></ITEM>");
                //sb.AppendFormat("<ITEM><JZLSH>127</JZLSH><JZRQ>2018-06-26</JZRQ><JZSJ>9:30~11:00</JZSJ><KSDM>10118</KSDM><KSMC>皮肤科门诊</KSMC><YSXM>刘建萍1</YSXM><YSDM>14115</YSDM><JSKSMC></JSKSMC><JSKSDM></JSKSDM><JSYSDM></JSYSDM><JSYSXM></JSYSXM><WJFJE>100.00</WJFJE><JSLXDM>6</JSLXDM><JSLX>医保</JSLX><YBLXMC>大学生医保</YBLXMC><YBLXDM>大学生医保</YBLXDM></ITEM>");
                sb.AppendFormat("<ROOT><HEADER><TRADEMSG>XH05070</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ITEM><JZLSH>2018081184023</JZLSH><JZRQ>2018/8/11</JZRQ><JZSJ>08:00~17:30</JZSJ><KSDM>02010105</KSDM><KSMC>牙周科</KSMC><YSXM></YSXM><YSDM></YSDM><JSKSMC>牙周科</JSKSMC><JSKSDM>02010105</JSKSDM><JSYSDM>8888</JSYSDM><JSYSXM>管理员</JSYSXM><WJFJE>65</WJFJE><JSLXDM>1</JSLXDM><JSLX>市医保</JSLX><YBLXMC>普通门诊</YBLXMC><YBLXDM>48788306</YBLXDM></ITEM></BODY></ROOT>");
                return sb.ToString();
            }

            #endregion
            #region 获取未缴费医嘱明细（XH05071）
            if (InValue.Contains("<TRADEMSG>XH05071</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                //sb.AppendFormat("<ROOT>");
                //sb.AppendFormat("<HEADER><TRADEMSG>XH05071</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                //sb.AppendFormat("<YBID>234</YBID><YBYHID>12</YBYHID><YBLB>大学生医保</YBLB><YBLXID>6</YBLXID><FBMS></FBMS><FBDM></FBDM><YZFY></YZFY><ExpStr></ExpStr>");
                //sb.AppendFormat("<ITEM><FXMC>西药</FXMC><FXDM>85</FXDM><FXJE>351</FXJE>");
                //sb.AppendFormat("<ITEM1><YBLX>大学生医保</YBLX><TMBBM></TMBBM><YPBH>45555</YPBH><YPMC>复杂阻生牙拔除</YPMC><DJ>390</DJ><DW>项</DW><SL>1</SL><GG></GG><JE>390</JE></ITEM1>");
                //sb.AppendFormat("<ITEM1><YBLX>大学生医保</YBLX><TMBBM></TMBBM><YPBH>45556</YPBH><YPMC>复杂阻生牙拔除</YPMC><DJ>390</DJ><DW>项</DW><SL>1</SL><GG></GG><JE>390</JE></ITEM1>");
                //sb.AppendFormat("<ITEM1><YBLX>大学生医保</YBLX><TMBBM></TMBBM><YPBH>45557</YPBH><YPMC>复杂阻生牙拔除</YPMC><DJ>390</DJ><DW>项</DW><SL>1</SL><GG></GG><JE>390</JE></ITEM1></ITEM>");
                //sb.AppendFormat("<ITEM><FXMC>西药1</FXMC><FXDM>86</FXDM><FXJE>121</FXJE>");
                //sb.AppendFormat("<ITEM1><YBLX>大学生医保</YBLX><TMBBM></TMBBM><YPBH>45655</YPBH><YPMC>复杂阻生牙拔除1</YPMC><DJ>390</DJ><DW>项</DW><SL>1</SL><GG></GG><JE>390</JE></ITEM1>");
                //sb.AppendFormat("<ITEM1><YBLX>大学生医保</YBLX><TMBBM></TMBBM><YPBH>45755</YPBH><YPMC>复杂阻生牙拔除1</YPMC><DJ>390</DJ><DW>项</DW><SL>1</SL><GG></GG><JE>390</JE></ITEM1>");
                //sb.AppendFormat("<ITEM1><YBLX>大学生医保</YBLX><TMBBM></TMBBM><YPBH>45855</YPBH><YPMC>复杂阻生牙拔除1</YPMC><DJ>390</DJ><DW>项</DW><SL>1</SL><GG></GG><JE>390</JE></ITEM1></ITEM>");
                //sb.AppendFormat("<ROOT><HEADER><TRADEMSG>XH05071</TRADEMSG><MACHINEID>SZ02</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ITEM> <FXMC>检查</FXMC><FXDM>D</FXDM><FXJE>10.00</FXJE><SFDY>1</SFDY><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310503004</YPBH><YPMC>龈上菌斑检查(公)</YPMC><DJ></DJ><DW>次</DW><SL>1</SL><GG>/</GG><JE>10.00</JE></ITEM1></ITEM><ITEM> <FXMC>治疗</FXMC><FXDM>E</FXDM><FXJE>2180.00</FXJE><SFDY>0</SFDY><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310513008A</YPBH><YPMC>超声根面平整加收(公)</YPMC><DJ></DJ><DW>每牙</DW><SL>30</SL><GG>/</GG><JE>600.00</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310513008</YPBH><YPMC>根面平整术(公)</YPMC><DJ></DJ><DW>每牙</DW><SL>30</SL><GG>/</GG><JE>300.00</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310513007</YPBH><YPMC>急性坏死性龈炎局部清创(公)</YPMC><DJ></DJ><DW>每牙</DW><SL>30</SL><GG>/</GG><JE>300.00</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310513001</YPBH><YPMC>洁治(公)</YPMC><DJ></DJ><DW>每牙</DW><SL>30</SL><GG>/</GG><JE>60.00</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310510004</YPBH><YPMC>口腔局部冲洗上药(公)</YPMC><DJ></DJ><DW>每牙</DW><SL>30</SL><GG>/</GG><JE>120.00</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310510007</YPBH><YPMC>口腔局部止血(公)</YPMC><DJ></DJ><DW>每牙</DW><SL>30</SL><GG>/</GG><JE>600.00</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310513005</YPBH><YPMC>牙面光洁术(公)</YPMC><DJ></DJ><DW>每牙</DW><SL>30</SL><GG>/</GG><JE>60.00</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310503006</YPBH><YPMC>牙周专业检查(公)</YPMC><DJ></DJ><DW>次</DW><SL>1</SL><GG>/</GG><JE>20.00</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310513002</YPBH><YPMC>龈下刮治(公)</YPMC><DJ></DJ><DW>每牙</DW><SL>10</SL><GG>/</GG><JE>30.00</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>310513002A</YPBH><YPMC>龈下刮治(后牙)(公)</YPMC><DJ></DJ><DW>每牙</DW><SL>20</SL><GG>/</GG><JE>90.00</JE></ITEM1></ITEM></BODY></ROOT>");
                sb.Append("<ROOT><HEADER><TRADEMSG>XH05071</TRADEMSG><MACHINEID>SZ05</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ITEM> <FXMC>西药</FXMC><FXDM>A</FXDM><FXJE>0.62</FXJE><SFDY>1</SFDY><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>0801001190</YPBH><YPMC>地塞米松磷酸钠注射液</YPMC><DJ>0.28</DJ><DW>支</DW><SL>1</SL><GG>1ml:5mg山东圣鲁</GG><JE>0.28</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>0801001190</YPBH><YPMC>地塞米松磷酸钠注射液</YPMC><DJ>0.28</DJ><DW>支</DW><SL>1</SL><GG>1ml:5mg山东圣鲁</GG><JE>0.28</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>0109004190</YPBH><YPMC>硫酸庆大霉素注射液</YPMC><DJ>0.34</DJ><DW>支</DW><SL>1</SL><GG>2ml:8万单位上海现代</GG><JE>0.34</JE></ITEM1><ITEM1><YBLX></YBLX><TMBBM></TMBBM><YPBH>0109004190</YPBH><YPMC>硫酸庆大霉素注射液</YPMC><DJ>0.34</DJ><DW>支</DW><SL>1</SL><GG>2ml:8万单位上海现代</GG><JE>0.34</JE></ITEM1></ITEM></BODY></ROOT>");
                return sb.ToString();
            }

            #endregion


            #region 门诊缴费预结算、结算（XH05072）
            if (InValue.Contains("<TRADEMSG>XH05072</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                //sb.AppendFormat("<ROOT>");
                //sb.AppendFormat("<HEADER><TRADEMSG>XH05072</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                //sb.AppendFormat("<ITEM><JYLSH>2354345345</JYLSH><YBJFJE>0.00</YBJFJE><GRJFJE>450</GRJFJE><FPID>11111</FPID><FPJE>450</FPJE><FYCK>kkkkkkkkkkk</FYCK><FPH>67676767</FPH><YBBJ></YBBJ><YBJB>0</YBJB><FPKZXX></FPKZXX><CZYDM></CZYDM><YBLY></YBLY><YBLX></YBLX><YBKZXX></YBKZXX><YBRKBJ></YBRKBJ><YBLXDM></YBLXDM></ITEM>");
               
                sb.AppendFormat("<ROOT><HEADER><TRADEMSG>XH05072</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ITEM><JYLSH>20180811282303</JYLSH><YBJFJE>0.00</YBJFJE><GRJFJE>65.00</GRJFJE><FPID> </FPID><FPJE></FPJE><FYCK></FYCK><FPH></FPH><YBBJ></YBBJ><YBJB></YBJB><FPKZXX></FPKZXX><CZYDM></CZYDM><YBLY></YBLY><YBLX></YBLX><YBRKBJ></YBRKBJ><YBLXDM></YBLXDM><YBXX>20180811B84023^0^熊能^0^02010105^SZ01^^48788306^0^11^^^0^0^20180811153529^20180811282303^Y@20180811B84023|2|31|2018081184023001|20180811153529|120400002a|60012040000202000000|静脉采血(公)|5|1|||||管理员|8888||次|牙周科|||1111||$20180811B84023|2|25|2018081184023002|20180811153529|250403014|60025040301400000000|丙型肝炎抗体测定(Anti-HCV)(公)|15|1|||||管理员|8888||项|牙周科|||1111||$20180811B84023|2|25|2018081184023003|20180811153529|250402035|61025040203501000000|类风湿因子（RF）测定（散射速率法）(公)|30|1|||||管理员|8888||项|牙周科|||1111||$20180811B84023|2|25|2018081184023004|20180811153529|260000002|60026000000200000000|ABO血型鉴定(公)|15|1|||||管理员|8888||项|牙周科|||1111||</YBXX></ITEM></BODY></ROOT>");
                return sb.ToString();
            }

            #endregion

            #region   //查询有效预约记录（XH04013）
            if (InValue.Contains("<TRADEMSG>XH04013</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                //sb.AppendFormat("<ROOT>");
                //sb.AppendFormat("<HEADER><TRADEMSG>XH04013</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                //sb.AppendFormat("<ITEM><BRID>0000000061</BRID><YQBH>000</YQBH><YQM>YQM</YQM><KSBH>152</KSBH><KSMC>中医科门诊</KSMC><YYLX>YYLX</YYLX><YYSJ>YYSJ</YYSJ><JZRQ>JZRQ</JZRQ><JZSJD>JZSJD</JZSJD><JZKSSJ>JZKSSJ</JZKSSJ><JZJSSJ>JZJSSJ</JZJSSJ><YSGH>123</YSGH><YSXM>飞天猪</YSXM><YYZJ>67</YYZJ><YYDH>YYDH</YYDH><PBZJ>PBZJ</PBZJ><YYZT>YYZT</YYZT><ZFY>25</ZFY><JZXH>12</JZXH><SFFF>1</SFFF></ITEM>");
                //sb.AppendFormat("<ITEM><BRID>0000000061</BRID><YQBH>000</YQBH><YQM>YQM</YQM><KSBH>155</KSBH><KSMC>中医科门诊</KSMC><YYLX>2</YYLX><YYSJ>YYSJ</YYSJ><JZRQ>JZRQ</JZRQ><JZSJD>JZSJD</JZSJD><JZKSSJ>JZKSSJ</JZKSSJ><JZJSSJ>JZJSSJ</JZJSSJ><YSGH>YSGH</YSGH><YSXM>资晓飞</YSXM><YSZC>主任医生号</YSZC><YYZJ>68</YYZJ><YYDH>YYDH</YYDH><PBZJ>ghj3</PBZJ><YYZT>1</YYZT><ZFY>18</ZFY><JZXH>3</JZXH><SFFF>1</SFFF></ITEM>");

                //sb.AppendFormat("<ITEM><BRID>0001147331</BRID><YQBH>111</YQBH><YQM>南昌大学第二附属医院</YQM><KSBH>152</KSBH><KSMC>中医科门诊</KSMC><YYLX>1</YYLX><YYSJ>2017-07-14</YYSJ><JZSJ>2017-07-15</JZSJ><JZSJD>8:00-9：00</JZSJD><JZKSSJ>7：30</JZKSSJ><JZJSSJ>11：00</JZJSSJ><YSGH>176</YSGH><ZFY>150</ZFY><YSXM>资晓飞</YSXM><YYZJ>2222</YYZJ></ITEM>");//<YYDH></YYDH></PBZJ></PBZJ><YYZT></YYZT><JZXH></JZXH><SFFF></SFFF>

                sb.AppendFormat("<ROOT><HEADER><TRADEMSG>XH04013</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ITEM><BRID>48788306</BRID><YQBH>491015900</YQBH><YQM>南昌大学附属口腔医院</YQM><KSBH>02010105</KSBH><KSMC>牙周科</KSMC><YYLX>1</YYLX><YYSJ>2018-08-11 12:28:08</YYSJ><JZRQ>2018-08-11</JZRQ><JZSJD>08:00~17:30</JZSJD><JZKSSJ>08:00</JZKSSJ><JZJSSJ>17:30</JZJSSJ><YSGH></YSGH><YSXM></YSXM><YSZC></YSZC><YYZJ>2018081184023</YYZJ><YYDH>2018081184023</YYDH><PBZJ>牙周科(普通)|20180811|白天|</PBZJ><YYZT>已取号</YYZT><ZFY>16.00</ZFY><JZXH>2</JZXH></ITEM></BODY></ROOT>");

                /*
                  response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordCount>1</RecordCount><Orders><Order><OrderCode>2222||3||2</OrderCode><OrderApptDate>2017-07-14</OrderApptDate><OrderStatus>normal</OrderStatus><OrderApptUser>徐业贵</OrderApptUser><PatientNo>0000000061</PatientNo><AdmitDate>2017-07-15</AdmitDate><DepartmentCode>152</DepartmentCode><Department>中医科门诊</Department><DoctorCode>176</DoctorCode><Doctor>资晓飞</Doctor><DoctorTitle>主任医生号</DoctorTitle><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><RegFee>9</RegFee><SeqCode>2</SeqCode><SessionName>下午</SessionName><AllowRefundFlag>Y</AllowRefundFlag><PayFlag>TB</PayFlag><HospitalName>南昌大学第二附属医院</HospitalName></Order></Orders></Response>";
                 */

                return sb.ToString();
            }

            #endregion
            #region   预约取消（XH04014）
            if (InValue.Contains("<TRADEMSG>XH04014</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH04014</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("");
                sb.AppendFormat("</BODY></ROOT>");



                return sb.ToString();
            }

            #endregion

            #region  取号预结算（XH04015）
            if (InValue.Contains("<TRADEMSG>XH04015</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH04015</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<ZJE>20</ZJE><YBZFJE>0.00</YBZFJE><GRZFJE>20</GRZFJE><YBXX>YBXX</YBXX>");
                sb.AppendFormat("</BODY></ROOT>");



                return sb.ToString();
            }

            #endregion

            #region  取号结算（XH04016）
            if (InValue.Contains("<TRADEMSG>XH04016</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH04016</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<GHXH>5</GHXH><FPH>55555555</FPH><JZDD>JZDD</JZDD>");
                sb.AppendFormat("</BODY></ROOT>");



                return sb.ToString();
            }

            #endregion


            #region   查询挂号记录（XH03053）
            if (InValue.Contains("<TRADEMSG>XH03053</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH03053</TRADEMSG><MACHINEID>013</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<ITEM><BRID>9854562</BRID><YQBH>123456785</YQBH><YQM>协和</YQM><KSBH>057702</KSBH><KSMC>骨科</KSMC><YYLX>1</YYLX><YYSJ>2018-6-27</YYSJ><JZRQ>2018-6-27</JZRQ><JZSJD>8：30-9：00</JZSJD><YSGH>05014</YSGH><YSXM>辽阔的</YSXM><YYZJ>0500050</YYZJ><ZT>正常</ZT><ZFY></ZFY><JZXH>15</JZXH><HZDD></HZDD><KTHBZ></KTHBZ><BKTHYY></BKTHYY><DZPH></DZPH></ITEM>");
                sb.AppendFormat("<ITEM><BRID>9854562</BRID><YQBH>123456785</YQBH><YQM>协和</YQM><KSBH>057702</KSBH><KSMC>骨科</KSMC><YYLX>1</YYLX><YYSJ>2018-8-26</YYSJ><JZRQ>2018-6-27</JZRQ><JZSJD>8：30-9：00</JZSJD><YSGH>05014</YSGH><YSXM>辽阔的</YSXM><YYZJ>0500050</YYZJ><ZT>正常</ZT><ZFY></ZFY><JZXH>15</JZXH><HZDD></HZDD><KTHBZ></KTHBZ><BKTHYY></BKTHYY><DZPH></DZPH></ITEM>");
                sb.AppendFormat("<ITEM><BRID>9854562</BRID><YQBH>123456785</YQBH><YQM>协和</YQM><KSBH>057702</KSBH><KSMC>骨科</KSMC><YYLX>1</YYLX><YYSJ>2018-7-26</YYSJ><JZRQ>2018-6-27</JZRQ><JZSJD>8：30-9：00</JZSJD><YSGH>05014</YSGH><YSXM>辽阔的</YSXM><YYZJ>0500050</YYZJ><ZT>不可退号</ZT><ZFY></ZFY><JZXH>15</JZXH><HZDD></HZDD><KTHBZ></KTHBZ><BKTHYY></BKTHYY><DZPH></DZPH></ITEM>");
                //<BRID>BRID</BRID><YQBH>YQBH</YQBH><YQM>YQM</YQM><KSBH>KSBH</KSBH><KSMC>KSMC</KSMC><YYLX>YYLX</YYLX><YYSJ>YYSJ</YYSJ><JZRQ>JZRQ</JZRQ><JZSJD>JZSJD</JZSJD><YSGH>YSGH</YSGH><YSXM>YSXM</YSXM><YYZJ>YYZJ</YYZJ><ZT>ZT</ZT><ZFY>ZFY</ZFY><JZXH>JZXH</JZXH><HZDD>HZDD</HZDD><KTHBZ>KTHBZ</KTHBZ><BKTHYY>BKTHYY</BKTHYY><DZPH>DZPH</DZPH>
                sb.AppendFormat("</BODY></ROOT></Xml>");
                return sb.ToString();
            }
            #endregion

            #region 预存账户充值/退款（XH06025）
            if (InValue.Contains("<TRADEMSG>XH06025</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH06025</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<YCYE>56</YCYE><YCJE>50</YCJE><YCSJ>YCSJ</YCSJ><PZHM>PZHM</PZHM>");
                sb.AppendFormat("</BODY></ROOT>");



                return sb.ToString();
            }

            #endregion


            #region  排队叫号查询（XH03074）
            if (InValue.Contains("<TRADEMSG>XH03074</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH03074</TRADEMSG><MACHINEID>013</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<DHSJ>30</DHSJ><SXH>35</SXH><DHRS>5</DHRS>");
                sb.AppendFormat("</BODY></ROOT></Xml>");
                return sb.ToString();
            }
            #endregion



            #region   诊断信息查询（XH05075）
            if (InValue.Contains("<TRADEMSG>XH05075</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH05075</TRADEMSG><MACHINEID>013</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<JZRQ>2018-8-8</JZRQ><ZDMC>二次元中二病</ZDMC><YS>李并用</YS>");
                sb.AppendFormat("</BODY></ROOT></Xml>");
                return sb.ToString();
            }
            #endregion


            #region 7.1	收费项目查询XH07029
            if (InValue.Contains("<TRADEMSG>XH07029</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH07029</TRADEMSG><MACHINEID>013</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<ITEM><XMMC>马杀鸡</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>降龙十八掌</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>蛤蟆功</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>碧血剑</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>八卦阵</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>黯然销魂掌</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>一阳指</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>小李飞刀</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>绝世好剑</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>寒冰掌</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>九阳神功</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>葵花宝典</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>圆月弯刀</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>打狗棒</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><XMMC>玉女经</XMMC><PY>MSJ</PY><DJ>120</DJ><DW>次</DW><FBMC>加班费</FBMC><XMLB>享受类</XMLB></ITEM>");
                sb.AppendFormat("</BODY></ROOT></Xml>");
                return sb.ToString();
            }


            #endregion




            #region 7.2	查询药品信息 XH07030
            if (InValue.Contains("<TRADEMSG>XH07030</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH07030</TRADEMSG><MACHINEID>013</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<ITEM><YPMC>含笑半步癫</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>化骨水</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>六味丸</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>东阿阿胶</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>自重益肾丸</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>健儿消食片</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>脑白金</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>含笑半步癫</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>化骨水</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>六味丸</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>东阿阿胶</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>自重益肾丸</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>健儿消食片</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>脑白金</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>含笑半步癫</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>化骨水</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>六味丸</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>东阿阿胶</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>自重益肾丸</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>健儿消食片</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("<ITEM><YPMC>脑白金</YPMC><PY>HXBBD</PY><DJ>100</DJ><DW>瓶</DW><GG>11</GG><SCS>云南制药</SCS><FBMC>自费</FBMC><XMLB>神经类</XMLB></ITEM>");
                sb.AppendFormat("</BODY></ROOT></Xml>");
                return sb.ToString();
            }
            #endregion

            #region 获取门诊已缴费记录头（XH05059）
            if (InValue.Contains("<TRADEMSG>XH05059</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH05059</TRADEMSG><MACHINEID>013</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<ITEM><JZLSH>11111101</JZLSH><JZRQ>2017-6-22</JZRQ><KSDM>0501</KSDM><KSMC>内科</KSMC><YSDM>050111</YSDM><YSXM>神盾局</YSXM><ZFFY>1000</ZFFY><FPBID>050512452</FPBID><ZFSJ>2018-7-8</ZFSJ><QYDD>中药房</QYDD></ITEM>");
                sb.AppendFormat("<ITEM><JZLSH>11111101</JZLSH><JZRQ>2017-6-22</JZRQ><KSDM>0501</KSDM><KSMC>外壳</KSMC><YSDM>050111</YSDM><YSXM>兄妹局</YSXM><ZFFY>1500</ZFFY><FPBID>050512452</FPBID><ZFSJ>2018-7-8</ZFSJ><QYDD>中药房</QYDD></ITEM>");
                sb.AppendFormat("<ITEM><JZLSH>11111101</JZLSH><JZRQ>2017-6-22</JZRQ><KSDM>0501</KSDM><KSMC>内科</KSMC><YSDM>050111</YSDM><YSXM>神盾局</YSXM><ZFFY>1000</ZFFY><FPBID>050512452</FPBID><ZFSJ>2018-7-8</ZFSJ><QYDD>中药房</QYDD></ITEM>");
                sb.AppendFormat("<ITEM><JZLSH>11111101</JZLSH><JZRQ>2017-6-22</JZRQ><KSDM>0501</KSDM><KSMC>外壳</KSMC><YSDM>050111</YSDM><YSXM>兄妹局</YSXM><ZFFY>1500</ZFFY><FPBID>050512452</FPBID><ZFSJ>2018-7-8</ZFSJ><QYDD>中药房</QYDD></ITEM>");
                sb.AppendFormat("<ITEM><JZLSH>11111101</JZLSH><JZRQ>2017-6-22</JZRQ><KSDM>0501</KSDM><KSMC>内科</KSMC><YSDM>050111</YSDM><YSXM>神盾局</YSXM><ZFFY>1000</ZFFY><FPBID>050512452</FPBID><ZFSJ>2018-7-8</ZFSJ><QYDD>中药房</QYDD></ITEM>");
                sb.AppendFormat("<ITEM><JZLSH>11111101</JZLSH><JZRQ>2017-6-22</JZRQ><KSDM>0501</KSDM><KSMC>外壳</KSMC><YSDM>050111</YSDM><YSXM>兄妹局</YSXM><ZFFY>1500</ZFFY><FPBID>050512452</FPBID><ZFSJ>2018-7-8</ZFSJ><QYDD>中药房</QYDD></ITEM>");
                sb.AppendFormat("<ITEM><JZLSH>11111101</JZLSH><JZRQ>2017-6-22</JZRQ><KSDM>0501</KSDM><KSMC>内科</KSMC><YSDM>050111</YSDM><YSXM>神盾局</YSXM><ZFFY>1000</ZFFY><FPBID>050512452</FPBID><ZFSJ>2018-7-8</ZFSJ><QYDD>中药房</QYDD></ITEM>");
                sb.AppendFormat("<ITEM><JZLSH>11111101</JZLSH><JZRQ>2017-6-22</JZRQ><KSDM>0501</KSDM><KSMC>外壳</KSMC><YSDM>050111</YSDM><YSXM>兄妹局</YSXM><ZFFY>1500</ZFFY><FPBID>050512452</FPBID><ZFSJ>2018-7-8</ZFSJ><QYDD>中药房</QYDD></ITEM>");
                sb.AppendFormat("<ITEM><JZLSH>11111101</JZLSH><JZRQ>2017-6-22</JZRQ><KSDM>0501</KSDM><KSMC>内科</KSMC><YSDM>050111</YSDM><YSXM>神盾局</YSXM><ZFFY>1000</ZFFY><FPBID>050512452</FPBID><ZFSJ>2018-7-8</ZFSJ><QYDD>中药房</QYDD></ITEM>");
                sb.AppendFormat("<ITEM><JZLSH>11111101</JZLSH><JZRQ>2017-6-22</JZRQ><KSDM>0501</KSDM><KSMC>外壳</KSMC><YSDM>050111</YSDM><YSXM>兄妹局</YSXM><ZFFY>1500</ZFFY><FPBID>050512452</FPBID><ZFSJ>2018-7-8</ZFSJ><QYDD>中药房</QYDD></ITEM>");
                sb.AppendFormat("</BODY></ROOT></Xml>");
                return sb.ToString();
            }
            #endregion

            #region 获取门诊已缴费记录头（XH05060）
            if (InValue.Contains("<TRADEMSG>XH05060</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH05060</TRADEMSG><MACHINEID>013</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<ITEM><FB>自费</FB><YZID>05010123456</YZID><YZMC>自律</YZMC><SL>100</SL><DW>瓶</DW><JE>1000</JE><GG>甲类</GG><DJ>10</DJ><JMJE>0</JMJE></ITEM>");
                sb.AppendFormat("<ITEM><FB>自费</FB><YZID>05010123456</YZID><YZMC>自律</YZMC><SL>100</SL><DW>瓶</DW><JE>1000</JE><GG>甲类</GG><DJ>10</DJ><JMJE>0</JMJE></ITEM>");
                sb.AppendFormat("<ITEM><FB>自费</FB><YZID>05010123456</YZID><YZMC>自律</YZMC><SL>100</SL><DW>瓶</DW><JE>1000</JE><GG>甲类</GG><DJ>10</DJ><JMJE>0</JMJE></ITEM>");
                sb.AppendFormat("</BODY></ROOT></Xml>");
                return sb.ToString();
            }
            #endregion

            #region 院内账户支付流水信息查询（XH06062）
            if (InValue.Contains("<TRADEMSG>XH06062</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH06062</TRADEMSG><MACHINEID>013</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<ITEM><JYLSH>11111111</JYLSH><JYKS>内科</JYKS><JYJE>1000</JYJE><JYSJ>2018-1-2</JYSJ><CZYXM>SDK</CZYXM><CZLSH>22222222</CZLSH></ITEM>");
                sb.AppendFormat("<ITEM><JYLSH>11111111</JYLSH><JYKS>外科</JYKS><JYJE>1000</JYJE><JYSJ>2018-1-2</JYSJ><CZYXM>SDK</CZYXM><CZLSH>22222222</CZLSH></ITEM>");
                sb.AppendFormat("<ITEM><JYLSH>11111111</JYLSH><JYKS>骨科</JYKS><JYJE>1000</JYJE><JYSJ>2018-1-2</JYSJ><CZYXM>SDK</CZYXM><CZLSH>22222222</CZLSH></ITEM>");
                sb.AppendFormat("<ITEM><JYLSH>11111111</JYLSH><JYKS>皮肤科</JYKS><JYJE>1000</JYJE><JYSJ>2018-1-2</JYSJ><CZYXM>SDK</CZYXM><CZLSH>22222222</CZLSH></ITEM>");
                sb.AppendFormat("<ITEM><JYLSH>11111111</JYLSH><JYKS>妇科</JYKS><JYJE>1000</JYJE><JYSJ>2018-1-2</JYSJ><CZYXM>SDK</CZYXM><CZLSH>22222222</CZLSH></ITEM>");
                sb.AppendFormat("<ITEM><JYLSH>11111111</JYLSH><JYKS>眼科</JYKS><JYJE>1000</JYJE><JYSJ>2018-1-2</JYSJ><CZYXM>SDK</CZYXM><CZLSH>22222222</CZLSH></ITEM>");
                sb.AppendFormat("</BODY></ROOT></Xml>");
                return sb.ToString();
            }
            #endregion



            #region 住院病人日费用清单查询（XH09032）
            if (InValue.Contains("<TRADEMSG>XH09032</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                sb.AppendFormat("<ROOT>");
                sb.AppendFormat("<HEADER><TRADEMSG>XH09032</TRADEMSG><MACHINEID>013</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                sb.AppendFormat("<ITEM><ZYID>010101</ZYID><FBMC>骨科X光</FBMC><BMMC>骨科</BMMC><XMMC>体检</XMMC><DJ>100</DJ><SL>1</SL><SFSJ>2018-8-8</SFSJ><SFRY>010101</SFRY><BH>102321354</BH><ZJE>300</ZJE><ZFJE>300</ZFJE><DW>次</DW></ITEM>");
                sb.AppendFormat("</BODY></ROOT></Xml>");
                return sb.ToString();
            }
            #endregion


            #region   住院病人基本信息（XH09033）
            if (InValue.Contains("<TRADEMSG>XH09033</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                //sb.AppendFormat("<ROOT>");
                //sb.AppendFormat("<HEADER><TRADEMSG>XH09033</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                //sb.AppendFormat("<ZYID>111111</ZYID><ZYH>123456789</ZYH><BQ>01</BQ><CWH>18</CWH><ZYYJK>1000.00</ZYYJK><ZZFJE>ZZFJE</ZZFJE><ZJZJE>ZJZJE</ZJZJE><ZLWJE>ZLWJE</ZLWJE><YJSJE>YJSJE</YJSJE><KZCJE>KZCJE</KZCJE><RYSJ>RYSJ</RYSJ><CYSJ>CYSJ</CYSJ><ZYXM>ZYXM</ZYXM><JZKS>JZKS</JZKS><JZKSBH>JZKSBH</JZKSBH><BQBH>BQBH</BQBH>");
                sb.AppendFormat("<ROOT><HEADER><TRADEMSG>XH09033</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ZYID>1000472970|1|</ZYID><ZYH>0012301</ZYH><BQ>口腔颌面外科病区</BQ><CWH>1</CWH><ZYYJK>510</ZYYJK><ZYYJYE>510</ZYYJYE><ZZFJE>0</ZZFJE><ZJZJE>0</ZJZJE><ZLWJE>0</ZLWJE><YJSJE>0</YJSJE><KZCJE>0</KZCJE><RYSJ>2018/8/8</RYSJ><CYSJ></CYSJ><ZYXM>黄怀英</ZYXM><JZKS>口腔颌面外科病区</JZKS><JZKSBH>020201</JZKSBH><BQBH>020201</BQBH><SFZH>54012319810516475X</SFZH><SJH>18098787890</SJH><ZYZT>Y</ZYZT></BODY></ROOT>");
                return sb.ToString();
            }

            #endregion
            #region 住院预缴款充值（XH09034）
            if (InValue.Contains("<TRADEMSG>XH09034</TRADEMSG>"))
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                //sb.AppendFormat("<ROOT>");
                //sb.AppendFormat("<HEADER><TRADEMSG>XH09034</TRADEMSG><MACHINEID>001</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY>");
                //sb.AppendFormat("<ZYID>123456789</ZYID><YE>100.00</YE><SJH>123456789</SJH><YJSJ>2018-07-11</YJSJ>");
                sb.AppendFormat("<ROOT><HEADER><TRADEMSG>XH09034</TRADEMSG><MACHINEID>SZ01</MACHINEID><ZDYQBH>000</ZDYQBH><RESULTCODE>0</RESULTCODE><RESULTCONTENT>成功</RESULTCONTENT></HEADER><BODY><ZYID>1000472970|1|</ZYID><YE>630 </YE><SJH></SJH>20180811142648<YJSJ>20180811152433I16</YJSJ></BODY></ROOT>");
                return sb.ToString();
            }

            #endregion








            return "";
        }
        
    }
}
