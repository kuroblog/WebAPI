﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.Services;

using System.Text;
namespace SunRise.HOSP.Web
{
    /// <summary>
    /// CallService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消对下行的注释。
    // [System.Web.Script.Services.ScriptService]
    public class CallService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }


        [WebMethod]
        public string Execute(string BusiCode, string InValue)
        {
            String response = "12354";

            switch (BusiCode)
            {
                case "3013": response = @"<Response>
    <ResultCode>0</ResultCode>
<ResultContent> 获取信息失败 </ResultContent>
<PatientID></PatientID>
<PatientName>张三</PatientName>
<Sex>0</Sex>
<SexCode></SexCode>
<DOB></DOB>
<DocumentID></DocumentID>
<Address>测试地址</Address>
<IDTypeCode></IDTypeCode>
<IDTypeDesc></IDTypeDesc>
<IDNo>330355555555555555</IDNo>
<YBFlag></YBFlag>
<PatType></PatType>
<Mobile>13588888888</Mobile>
<InsureCardNo></InsureCardNo>
</Response>
"; break;  //就诊卡查询 ， 判断卡号是否允许办卡

                default: response = String.Format(@"<Response>
<TradeCode>{0}</TradeCode>
<ResultCode>1<ResultCode>
<ResultContent>未找到 交易代码 <ResultContent>
<CardDepositAmt></CardDepositAmt>
</Response>", "000"); break;
            }

            return response;
        }

    }
}
