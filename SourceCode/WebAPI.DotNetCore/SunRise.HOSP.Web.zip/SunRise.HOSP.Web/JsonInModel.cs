﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SunRise.HOSP.HIS
{
    public class JsonInModel
    {

        public JsonInModel()
        {

        }
        public string TradeCode { get; set; }
        

    }
    /// <summary>
    /// 5.1.基础信息查询 GetDicInfo --  0000
    /// </summary>
    public class JsonIn_GetDicInfo : JsonInModel
    {
        /// <summary>
        /// String	是	字典类型：EMPLOYEE  人员 DEPARTMENT 科室 REGLEVEL  挂号级别  PACTUNITINFO挂号合同单位   NOON  午别 PAYKIND 支付类别
        /// </summary>
         public string dicType	{ get; set; }

        /// <summary>
         /// String	是	查询编码 ALL 全部
        /// </summary>
         public string dicCode	{ get; set; }
    }

    /// <summary>
    ///5.2.图片信息查询 GetPhotoInfo --  0001
    /// </summary>
    public class JsonIn_GetPhotoInfo : JsonInModel
    {
        /// <summary>
        /// String	是	字典类型：EMPLOYEE  人员
        /// </summary>
        public string dicType	{ get; set; }

        /// <summary>
        /// String	是	查询人员编码
        /// </summary>
        public string dicCode	{ get; set; }

    }


    /// <summary>
    ///  6.1.查询患者在医院中卡号 GetPatientCardNo   1002
    /// </summary>
    public class JsonIn_GetPatientCardNo : JsonInModel
    {
        /// <summary>
        /// String	否	就诊人姓名
        /// </summary>
        public string realName	{ get; set; }

        /// <summary>
        /// String	否	就诊人身份证
        /// </summary>
        public string idCard	{ get; set; }

        /// <summary>
        /// String	否	建档卡号
        /// </summary>
        public string mCardNo	{ get; set; }

        /// <summary>
        /// String	否	建档卡号类型 5身份证 6医保卡  7银行卡
        /// </summary>
        public string  mType	{ get; set; }

        /// <summary>
        /// String	是	查询方式 0 自费患者查询  姓名和身份证  1 物理卡号查询
        /// </summary>
        public string queryType	{ get; set; }

    }

    /// <summary>
    /// 6.2.医保读卡 ReadCard
    /// </summary>
    public class JsonIn_ReadCard : JsonInModel
    {
        /// <summary>
        /// String	是	就诊人姓名
        /// </summary>
        public string pactCode	{ get; set; }

        /// <summary>
        /// String	是	就诊人身份证
        /// </summary>
        public string operCode	{ get; set; }
    }

    /// <summary>
    ///  6.3 新建患者基本信息 InsertPatientInfo  1001
    /// </summary>
    public class JsonIn_InsertPatientInfo : JsonInModel
    {
        #region 建档入参
        /// <summary>
        /// String	是	就诊人姓名
        /// </summary>
        public string realName { get; set; }

        /// <summary>
        /// String	是	性别 M/男  F/女
        /// </summary>
        public string sex { get; set; }

        /// <summary>
        /// String	是	地址
        /// </summary>
        public string adress { get; set; }

        /// <summary>
        /// String	是	生日 yyyy-MM-dd
        /// </summary>
        public string birthday { get; set; }

        /// <summary>
        /// String	是	手机号码
        /// </summary>
        public string phone { get; set; }

        /// <summary>
        /// String	是	身份证
        /// </summary>
        public string idCard { get; set; }

        /// <summary>
        /// String	是	合同单位 1 自费  78 医保（医院定义）
        /// </summary>
        public string pactCode { get; set; }

        /// <summary>
        /// String	否	是否建档 0 否 1 是
        /// </summary>
        public string isCreateAccount { get; set; }

        /// <summary>
        /// String	否	建档卡号
        /// </summary>
        public string mCardNo { get; set; }

        /// <summary>
        /// String	否	建档卡号类型 5身份证6医保卡7银行卡
        /// </summary>
        public string mType { get; set; }

        /// <summary>
        /// String	是	操作员
        /// </summary>
        public string operCode { get; set; }

        /// <summary>
        /// String	是	自助机终端号
        /// </summary>
        public string termId { get; set; }

         /// <summary>
         /// 交易序号
         /// </summary>
        public string tradeNo { get; set; }
        #endregion

    }

    /// <summary>
     /// 院内账户充值 InsertMZPrepay
    /// </summary>
     public class JsonIn_InsertMZPrepay : JsonInModel
     {
        /// <summary>
        /// String	是	就诊人卡号
        /// </summary>
        public string patientCard	{ get; set; }

        /// <summary>
        /// String	是	金额 0.00
        /// </summary>
        public string prepayCost	{ get; set; }

        /// <summary>
        /// String	是	支付方式 CA 现金 CD 银联
        /// </summary>
        public string payMode	{ get; set; }
        /// <summary>
        /// String	是	操作员
        /// </summary>
        public string operCode	{ get; set; }

        /// <summary>
        /// String	是	交易流水号
        /// </summary>
        public string tradeNo	{ get; set; }
     }

    /// <summary>
    /// GetShemaInfo  2003(获取科室医生排班接口)
    /// </summary>
    public class JsonIn_GetShemaInfo : JsonInModel
    {
        /// <summary>
        /// 开始时间 yyyy-MM-dd
        /// </summary>
        public string beginDate { get; set; }

        /// <summary>
        /// 结束时间 yyyy-MM-dd
        /// </summary>
        public string endDate { get; set; }

        /// <summary>
        /// 科室编码
        /// </summary>
        public string deptCode { get; set; }

        /// <summary>
        /// 是否预约 0 不预约 1 预约
        /// </summary>
        public string isPre { get; set; }
         
    }

    /// <summary>
    ///可预约时间点信息(GetShemaPointInfo)
    /// </summary>
    public class JsonIn_GetShemaPointInfo : JsonInModel
    {
        /// <summary>
        ///  排班编号（his主键）
        /// </summary>
        public string shemaId { get; set; }
    }

    /// <summary>
    /// 预约挂号(SaveBooking 2008)
    /// </summary>
    public class JsonIn_SaveBooking : JsonInModel
    {
        #region 预约挂号入参
        /// <summary>
        /// String	否	排班编号 专家挂号必填
        /// </summary>
        public string shemaId { get; set; }

        /// <summary>
        /// 患者卡号
        /// </summary>
        public string cardNo { get; set; }
        /// <summary>
        ///患者姓名 
        /// </summary>
        public string realName { get; set; }

        /// <summary>
        /// 是否专家挂号 1 专家  0 不是专家
        /// </summary>
        public string isExpert { get; set; }

        /// <summary>
        /// String	否	科室代码  不是专家必填
        /// </summary>
        public string deptCode { get; set; }

        /// <summary>
        /// 预约时间 yyyy-MM-ddHH:mi:ss
        /// </summary>
        public string preTime { get; set; }

        /// <summary>
        /// 是否支付 0 未支付 1 账户支付 2 已经支付
        /// </summary>
        public string isFee { get; set; }

        /// <summary>
        /// 总费用
        /// </summary>
        public string clinicFee { get; set; }

        /// <summary>
        /// 预约来源 标识厂商
        /// </summary>
        public string bookSource { get; set; }

        /// <summary>
        /// 1 预约挂号取号  2 预约挂号直接就诊
        /// </summary>
        public string bookType { get; set; }

        /// <summary>
        /// 支付方式 CA 现金 ZB 支付宝 WX 微信
        /// </summary>
        public string feeSource { get; set; }

        /// <summary>
        /// 第三方订单流水号
        /// </summary>
        public string tradeNo { get; set; }

        /// <summary>
        /// 取号验证码
        /// </summary>
        public string IdentifyCode { get; set; }

        /// <summary>
        /// 操作员
        /// </summary>
        public string operCode { get; set; }

        /// <summary>
        /// 自助机终端号
        /// </summary>
        public string termId { get; set; } 
        #endregion
    }

    /// <summary>
    /// 预约取消( CancleBooking  2007)
    /// </summary>
    public class JsonIn_CancleBooking : JsonInModel
    {
         /// <summary>
         /// String	是	预约唯一号
         /// </summary>
         public string bookingNo	{ get; set; }

         /// <summary>
         /// String	是	操作员
         /// </summary>
         public string operCode { get; set; }
			

    }


    
    /// <summary>
     /// 预约查询明细(GetBookingInfo 2005)
    /// </summary>
   public class  JsonIn_GetBookingInfo :JsonInModel
   {
       /// <summary>
       /// String	是	预约唯一号
       /// </summary>
       public string bookingNo { get; set; }
       
       /// <summary>
       /// String	是	就诊人卡号
       /// </summary>
	   public string cardNo { get; set; }
       		
   }

    /// <summary>
    /// 新增挂号(SaveRegister  3004)
    /// </summary>
    public class JsonIn_SaveRegister : JsonInModel
    {
        #region 新增挂号入参
        /// <summary>
        /// 是	排班编号（可为空）专家号必填
        /// </summary>
        public string shemaId { get; set; }

        /// <summary>
        /// 就诊人真实姓名
        /// </summary>
        public string realName { get; set; }

        /// <summary>
        /// 就诊人卡号
        /// </summary>
        public string cardNo { get; set; }

        /// <summary>
        /// 挂号科室名称
        /// </summary>
        public string departmentName { get; set; }

        /// <summary>
        /// 挂号科室编号
        /// </summary>
        public string departmentCode { get; set; }

        /// <summary>
        /// 医生名称
        /// </summary>
        public string doctorName { get; set; }

        /// <summary>
        /// 医生编号
        /// </summary>
        public string doctorCode { get; set; }

        /// <summary>
        /// 挂号级别
        /// </summary>
        public string registrationLevel { get; set; }


        /// <summary>
        /// 挂号午别
        /// </summary>
        public string registrationNoonCode { get; set; }

        /// <summary>
        /// 门诊类型  PT 普通门诊  ZJ 专家门诊
        /// </summary>
        public string registrationType { get; set; }

        /// <summary>
        /// 挂号日期 yyyy-MM-dd
        /// </summary>
        public string registrationDate { get; set; }

        /// <summary>
        /// 挂号时间段 08:00 如果挂号不到时间点 默认为空
        /// </summary>
        public string registrationTime { get; set; }

        /// <summary>
        /// 挂号费用（单位:元）
        /// </summary>
        public string clinicFee { get; set; }

        /// <summary>
        /// 自费医保病人标识
        /// </summary>
        public string pactCode { get; set; }

        /// <summary>
        /// 自助机机器编号
        /// </summary>
        public string termId { get; set; }

        /// <summary>
        /// 操作员工号
        /// </summary>
        public string operCode { get; set; }

        /// <summary>
        /// 是否支付 0未支付 1账户支付 2已经支付
        /// </summary>
        public string isFee { get; set; }

        /// <summary>
        /// 支付方式 （支付必填）ZB 支付宝WX 微信 CA 现金 CD 银行卡
        /// </summary>
        public string feeSource { get; set; }

        /// <summary>
        /// 支付流水号
        /// </summary>
        public string tradeNo { get; set; }

        /// <summary>
        /// 医保结算参数 多个#分隔
        /// </summary>
        public string siInfo { get; set; } 
        #endregion
    }

    /// <summary>
    ///挂号取消 cancelRegister 3005
    /// </summary>
     public class JsonIn_cancelRegister : JsonInModel
     {
        /// <summary>
        /// String	是	挂号唯一号（his）
        /// </summary>
        public string clinicNo	{ get;set;}

        /// <summary>
        /// string	是	操作员工号
        /// </summary>
        public string operCode { get; set; }
      }

    /// <summary>
    /// 预约取号(InsertRegisterForBooking - 2011)
    /// </summary>
    public class JsonIn_InsertRegisterForBooking : JsonInModel
    {
        #region 入参
        /// <summary>
        /// 预约唯一号
        /// </summary>
        public string bookingNo { get; set; }

        /// <summary>
        ///  挂号费用（单位:元）
        /// </summary>
        public string clinicFee { get; set; }

        /// <summary>
        /// 自费医保病人标识
        /// </summary>
        public string pactCode { get; set; }

        /// <summary>
        /// 支付方式 ZB 支付宝  WX 微信  CA 现金  CD 银行卡
        /// </summary>
        public string feeSource { get; set; }

        /// <summary>
        ///支付流水号
        /// </summary>
        public string tradeNo { get; set; }

        /// <summary>
        ///  设备ID
        /// </summary>

        public string operCode { get; set; }
        
        #endregion
             
    }

    /// <summary>
     /// 挂号预结算SavePreReg
    /// </summary>
     public class JsonIn_SavePreReg : JsonInModel
     {
         #region 入参
         /// <summary>
         /// String	是	合同单位
         /// </summary>
         public string pactCode { get; set; }

         /// <summary>
         /// String	是	科室编码
         /// </summary>
         public string deptCode { get; set; }

         /// <summary>
         /// 	String	是	医生编码
         /// </summary>
         public string docCode { get; set; }

         /// <summary>
         /// 挂号级别
         /// </summary>
         public string registrationLevel { get; set; }

         /// <summary>
         /// 挂号午别
         /// </summary>
         public string registrationNoonCode { get; set; }

         /// <summary>
         /// 就诊人真实姓名
         /// </summary>
         public string realName { get; set; }

         /// <summary>
         /// 就诊人卡号
         /// </summary>
         public string cardNo { get; set; }

         /// <summary>
         /// 预约唯一号
         /// </summary>
         public string bookingNo { get; set; }

         /// <summary>
         /// 操作员
         /// </summary>
         public string operCode { get; set; }
         
         #endregion
     }

     /// <summary>
     ///查询挂号缴费列表（医保）GetRegFeeList-3006
     /// </summary>
     public class JsonIn_GetRegFeeList : JsonInModel
     {
          /// <summary>
          /// String	是	合同单位
          /// </summary>
          public string pactCode { get; set; }	
     }

    /// <summary>
      /// 9.1.查询检验、检查报告列表(默认查询一个月内的报告)findInspectionReport
    /// </summary>
      public class JsonIn_findInspectionReport : JsonInModel
      {
          /// <summary>
          /// String	是	姓名
          /// </summary>
          public string realName { get; set; }		

          /// <summary>
          /// String	是	就诊人卡号
          /// </summary>
          public string patientCard	{ get; set; }	
      }

        /// <summary>
      /// 9.2.查询检验报告详情findCompleteInspectionReport
        /// </summary>
      public class JsonIn_findCompleteInspectionReport : JsonInModel
      {
          /// <summary>
          /// String	是	唯一标识
          /// </summary>
          public string queryId { get; set; }	

          /// <summary>
          /// String	是	1-检验 2-检查
          /// </summary>
         public string checkType	{ get; set; }
      }
     
      /// <summary>
      /// /9.3.查询检查报告详情
      /// </summary>
      public class JsonIn_findCompleteInspectionReport1 : JsonInModel
      {
          /// <summary>
          /// String	是	唯一标识
          /// </summary>
          public string queryId { get; set; }

          /// <summary>
          /// String	是	1-检验 2-检查
          /// </summary>
          public string checkType { get; set; }
      }
     
    /// <summary>
    /// 10.1.查询病人挂号信息  GetRegListByCardNo 4000
    /// </summary>
      public class JsonIn_GetRegListByCardNo : JsonInModel
      {
           /// <summary>
           /// String	是	姓名
           /// </summary>
            public string realName	{ get; set; }

           /// <summary>
           /// String	是	就诊人卡号
           /// </summary>
            public string cardNo	{ get; set; }

           /// <summary>
            /// String	是	查询方式  0 所以有效记录 1 存在未收费的记录
           /// </summary>
            public string queryType	{ get; set; }
      }

    /// <summary>
    /// 10.2.查询门诊缴费列表 GetFeeListByClinicCode - 4002
    /// </summary>

     public class JsonIn_GetFeeListByClinicCode : JsonInModel
     {
         /// <summary>
         /// String	是	门诊挂号流水号
         /// </summary>
         public string clinicNo	{ get; set; }

         /// <summary>
         /// String	否	就诊人卡号
         /// </summary>
         public string patientCard	{ get; set; }
     }

     /// <summary>
     ///10.3.门诊预结算 SavePreFee - 4003
     /// </summary>
     public class JsonIn_SavePreFee : JsonInModel
     {
        /// <summary>
        /// String 	是	唯一号 多个 | 分隔
        /// </summary>
        public string recipe_Key	{ get; set; }

        /// <summary>
        /// String	是	就诊人姓名
        /// </summary>
        public string realName	{ get; set; }

        /// <summary>
        /// String	是	门诊流水号
        /// </summary>
        public string clinicNo	{ get; set; }

         /// <summary>
        /// String	是	缴费操作员
         /// </summary>
        public string operCode	{ get; set; }
     }

    /// <summary>
    /// 10.4.门诊结算SaveFee -4004
    /// </summary>
    public class JsonIn_SaveFee : JsonInModel
    {
        #region 入参
        /// <summary>
        /// String 	是	唯一号 多个 | 分隔
        /// </summary>
        public string recipe_Key { get; set; }

        /// <summary>
        /// String	是	就诊人姓名
        /// </summary>
        public string realName { get; set; }

        /// <summary>
        /// String	是	门诊流水号
        /// </summary>
        public string clinicNo { get; set; }

        /// <summary>
        /// String	是	缴费操作员
        /// </summary>
        public string operCode { get; set; }

        /// <summary>
        /// String	是	支付方式
        /// </summary>
        public string feeSource { get; set; }

        /// <summary>
        /// String	是	总费用
        /// </summary>
        public string totCost { get; set; }

        /// <summary>
        /// String	是	报销费用
        /// </summary>
        public string pubCost { get; set; }

        /// <summary>
        /// String	是	个人卡内费用
        /// </summary>
        public string payCost { get; set; }

        /// <summary>
        /// }String	是	自费费用
        /// </summary>
        public string ownCost { get; set; }

        /// <summary>
        /// String	是	交易流水号
        /// </summary>
        public string tradeNo { get; set; }

        /// <summary>
        /// String	是	设备编号
        /// </summary>
        public string termId { get; set; }

        /// <summary>
        /// String	否	医保结算参数 多个#分隔
        /// </summary>
        public string siInfo { get; set; } 
        #endregion
    }

    /// <summary>
    /// 11.1.获取就诊人已预缴的住院费用 QueryFeeMaster
    /// </summary>
    public class JsonIn_QueryFeeMaster : JsonInModel
    {
         /// <summary>
         /// String	是	就诊人姓名
         /// </summary>
        public string realName	{ get; set; }

         /// <summary>
        /// String	是	就诊人卡号
         /// </summary>
        public string patientCard	{ get; set; }
    }

    /// <summary>
    /// 11.2.获取某日住院费用清单 QueryFeeDay 
    /// </summary>
     public class JsonIn_QueryFeeDay : JsonInModel
     {
         /// <summary>
         /// String	是	就诊人姓名
         /// </summary>
         public string realName	{ get; set; }

         /// <summary>
         /// String	是	就诊人卡号
         /// </summary>
         public string patientCard	{ get; set; }

         /// <summary>
         /// String	是	日期
         /// </summary>
         public string date	{ get; set; }
     }

    /// <summary>
    /// 12.预缴住院费用接口 InsertPrepay
    /// </summary>
    public class JsonIn_InsertPrepay : JsonInModel
    {
        /// <summary>
        /// String	是	就诊人姓名
        /// </summary>
        public string realName	{ get; set; }

        /// <summary>
        /// String	是	就诊人卡号
        /// </summary>
        public string patientCard	{ get; set; }

        /// <summary>
        /// String	是	预缴金额
        /// </summary>
        public string prepayaAmount	{ get; set; }

        /// <summary>
        /// String	是	商户订单号
        /// </summary>
        public string tradeNo	{ get; set; }
    }




}
