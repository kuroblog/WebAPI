﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.IO;

namespace SunRise.HOSP.Web
{
    /// <summary>
    /// CallServiceSoapClient1 的摘要说明CallServiceSoapClient1SoapClient
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消对下行的注释。
    // [System.Web.Script.Services.ScriptService]
    public class CallServiceSoapClient1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }
        [WebMethod]
        public string OPAutoPayment(string InValue)
        {
            string path = Server.MapPath("WebService20180112.txt");
            string request = InValue;
            string response = string.Empty;
            int startIndex = request.IndexOf("<TradeCode>");
            int endIndex = request.IndexOf("</TradeCode>");
            request = request.Substring(startIndex, endIndex - startIndex);
            string text = string.Empty;
            bool exit = false;
               List<string> pathList = new List<string>();
            pathList.Add("WebService20180112.txt");
            pathList.Add("WebService20171220.txt");
            pathList.Add("WebService20171211.txt");

            pathList.Add("WebService20180301.txt");
            pathList.Add("WebService20180302.txt");
            pathList.Add("WebService20180303.txt");

            pathList.Add("WebService20180304.txt");
            pathList.Add("WebService20180305.txt");
            foreach (string item in pathList)
            {
                path = Server.MapPath(item);
                using (StreamReader reader = new StreamReader(path))
                {
                    text = reader.ReadToEnd();

                }
                while (text.Contains("Stack(WriteModuleLogLn DoService )"))
                {
                    text = text.Replace("Stack(WriteModuleLogLn DoService )", "");
                }
                while (text.Contains("\r\n"))
                {
                    text = text.Replace("\r\n", "$");
                }
                string[] arry = text.Split('$');
                for (int i = 0; i < arry.Length; i++)
                {
                    string value = arry[i];
                    if (value.Contains("Request") && value.Contains(request))
                    {
                        response = arry[i + 1];
                        int startIndex2 = response.IndexOf("<ResultCode>");
                        int endIndex2 = response.IndexOf("</ResultCode>");
                        string responseCode = response.Substring(startIndex2, endIndex2 - startIndex2).Replace("<ResultCode>", "").Replace("</ResultCode>", "").Trim();
                        if (responseCode != "0" && responseCode != "0000" || response.Contains("<Reclocs></Reclocs>"))
                            continue;

                        int requestStartIndex = response.IndexOf("<Response>");
                        response = response.Substring(requestStartIndex, response.Length - requestStartIndex);
                        exit = true;
                        break;
                    }
                }
                if (exit)
                    break;
            }
            return response;
            //if (InValue.Contains("<TradeCode>3300</TradeCode>"))
            //{
            //    return GetPatInfo(InValue);
            //}
            //else if (InValue.Contains("<TradeCode>34001</TradeCode>"))
            //{
            //    return GetPatInfo(InValue);
            //}
            //else if (InValue.Contains("<TradeCode>10121</TradeCode>"))
            //{
            //    return QueryDepartment(InValue);
            //}
                
            //else if (InValue.Contains("<TradeCode>1012</TradeCode>"))
            //{
            //    return QueryDepartment(InValue);
            //}
            //else if (InValue.Contains("<TradeCode>1004</TradeCode>"))
            //{
            //    return QueryAdmSchedule(InValue);
            //}
            //else if (InValue.Contains("<TradeCode>1014</TradeCode>"))
            //{
            //    return QueryAdmSchedule(InValue);
            //}
                
            //else if (InValue.Contains("<TradeCode>10041</TradeCode>"))
            //{
            //    return QueryScheduleTimeInfo(InValue);
            //}
            //else if (InValue.Contains("<TradeCode>1101</TradeCode>"))
            //{
            //    return OPRegister(InValue);
            //}
            //return "";
        }
        [WebMethod]
        public string SelfRegService(string requestCode,string InValue)
        {
            string returnValue = string.Empty;
            if (requestCode == "3300")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><PatInfos><PatInfo>
            <PatientID>0000000048</PatientID><PatientName>新测试</PatientName><Sex>男</Sex><SexCode>1</SexCode><DOB>1990-08-08</DOB>
            <TelephoneNo>13333333333</TelephoneNo><Mobile>13333333333</Mobile><DocumentID></DocumentID><Address></Address>
            <IDTypeCode>20</IDTypeCode><IDTypeDesc></IDTypeDesc><IDNo>340123198508154127</IDNo><InsureCardNo>XINCESHI</InsureCardNo><AccInfo>-200^^^0^0^0^^^^^P^^^</AccInfo>
            <AccInfoBalance></AccInfoBalance><AccInfoNo></AccInfoNo><PatientCard>000000000231</PatientCard><YBFlag>0</YBFlag><PatType>自费</PatType>
            <PatTypeCode>01</PatTypeCode></PatInfo></PatInfos></Response>";
            }
            if (requestCode == "8080")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><PatientID>0000000048</PatientID><PatientName>新测试</PatientName><SexCode></SexCode><Sex>男</Sex><DOB>1990-08-08</DOB><MRID></MRID><Address></Address><IDTypeCode></IDTypeCode><IDType></IDType><IDNo>340123198508154127</IDNo><PatType>自费</PatType><AccountID>36224</AccountID><DepositAmount>10099</DepositAmount></Response>";
            }
            if (requestCode == "4902")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><ResultContent>获取就诊记录成功</ResultContent><AdmItems><AdmItem><AdmRowid>53</AdmRowid>
            <AdmDate>2018-03-20</AdmDate><AdmDoctor>曹晓慧</AdmDoctor><AdmLocCode>KS017</AdmLocCode><AdmDoctorCode>10392001</AdmDoctorCode><AdmAmt>2370</AdmAmt>
            <AdmReasonCode>07</AdmReasonCode><AdmReasonDesc>全自费</AdmReasonDesc></AdmItem></AdmItems></Response>";
            }
            if (requestCode == "4903")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><ResultContent>获取费用信息成功.</ResultContent><AdmReasonCount>1</AdmReasonCount>
            <AdmReasons><AdmReason><InsuTypeDesc>全自费</InsuTypeDesc><InsuTypeDR>1</InsuTypeDR><AmtSum>2370.00</AmtSum><TarOCCateItems><TarOCCateItem><TarOCCateDesc>西药</TarOCCateDesc>
            <TarOCCateAmt>1370</TarOCCateAmt></TarOCCateItem><TarOCCateItem><TarOCCateDesc>其他</TarOCCateDesc><TarOCCateAmt>1000</TarOCCateAmt><OEOrdItems><OEOrdItem>
            <InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>普通门诊诊察费</ArcmiDesc><Price>10</Price><Qty>1</Qty><UOM>次</UOM><TotalAmount>1000</TotalAmount>
            <PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount></OEOrdItem></OEOrdItems></TarOCCateItem></TarOCCateItems></AdmReason></AdmReasons></Response>";
            }
            if (requestCode == "1012")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><RecordCount>41</RecordCount><Departments><Department><DepartmentCode>2</DepartmentCode><DepartmentName>产科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼四楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>7</DepartmentCode><DepartmentName>耳鼻咽喉头颈外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress><DepartmentAgeLimit>1</DepartmentAgeLimit></Department><Department><DepartmentCode>188</DepartmentCode><DepartmentName>耳鼻咽喉头颈外科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>15</DepartmentCode><DepartmentName>儿科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>181</DepartmentCode><DepartmentName>儿科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>171</DepartmentCode><DepartmentName>妇产科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>3</DepartmentCode><DepartmentName>妇科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼四楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>21</DepartmentCode><DepartmentName>风湿免疫科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>182</DepartmentCode><DepartmentName>风湿免疫科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>8</DepartmentCode><DepartmentName>骨科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>170</DepartmentCode><DepartmentName>骨科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼一楼</DepartmentAddress></Department><Department><DepartmentCode>17</DepartmentCode><DepartmentName>呼吸内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>1</DepartmentCode><DepartmentName>康复医学科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼四楼</DepartmentAddress><DepartmentAgeLimit>1</DepartmentAgeLimit></Department><Department><DepartmentCode>5</DepartmentCode><DepartmentName>口腔科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>186</DepartmentCode><DepartmentName>口腔科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>口腔诊疗中心一楼、二楼</DepartmentAddress></Department><Department><DepartmentCode>12</DepartmentCode><DepartmentName>泌尿外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>175</DepartmentCode><DepartmentName>泌尿外科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>23</DepartmentCode><DepartmentName>内分泌科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>177</DepartmentCode><DepartmentName>内分泌科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>27</DepartmentCode><DepartmentName>皮肤性病科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>189</DepartmentCode><DepartmentName>皮肤性病科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>9</DepartmentCode><DepartmentName>普外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>172</DepartmentCode><DepartmentName>普外科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>24</DepartmentCode><DepartmentName>神经内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>185</DepartmentCode><DepartmentName>神经内科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>11</DepartmentCode><DepartmentName>神经外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>13</DepartmentCode><DepartmentName>烧伤科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>20</DepartmentCode><DepartmentName>肾脏内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>184</DepartmentCode><DepartmentName>肾脏内科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>19</DepartmentCode><DepartmentName>消化内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>176</DepartmentCode><DepartmentName>消化内科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>16</DepartmentCode><DepartmentName>心血管内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>10</DepartmentCode><DepartmentName>心胸外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>25</DepartmentCode><DepartmentName>血液内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>183</DepartmentCode><DepartmentName>血液内科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>6</DepartmentCode><DepartmentName>眼科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>187</DepartmentCode><DepartmentName>眼科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>26</DepartmentCode><DepartmentName>肿瘤科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>169</DepartmentCode><DepartmentName>整形美容科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼一楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>4</DepartmentCode><DepartmentName>中医科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼四楼</DepartmentAddress><DepartmentAgeLimit>0</DepartmentAgeLimit></Department><Department><DepartmentCode>174</DepartmentCode><DepartmentName>中医科门诊(南区)</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department></Departments></Response>";
            }
            if (requestCode == "1004")
            {
                if (InValue.Contains("<DoctorCode></DoctorCode>"))
                {
                    returnValue = @"<Response><ResultCode>0</ResultCode><RecordCount>4</RecordCount><Schedules><Schedule><ScheduleItemCode>957||74</ScheduleItemCode><ServiceDate>2018-03-22</ServiceDate><WeekDay>4</WeekDay><SessionCode>01</SessionCode><SessionName>上午</SessionName><StartTime>08:30</StartTime><EndTime>12:00</EndTime><DepartmentCode>17</DepartmentCode><DepartmentName>呼吸内科门诊</DepartmentName><DoctorCode>222</DoctorCode><DoctorName>曹晓慧</DoctorName><DoctorTitleCode>4</DoctorTitleCode><DoctorTitle>主治医师</DoctorTitle><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主治医师</DoctorSessType><Fee>10</Fee><RegFee>10</RegFee><CheckupFee>0</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>30</AvailableTotalNum><AvailableLeftNum>6</AvailableLeftNum><TimeRangeFlag>0</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>963||1</ScheduleItemCode><ServiceDate>2018-03-22</ServiceDate><WeekDay>4</WeekDay><SessionCode>01</SessionCode><SessionName>上午</SessionName><StartTime>08:30</StartTime><EndTime>12:00</EndTime><DepartmentCode>17</DepartmentCode><DepartmentName>呼吸内科门诊</DepartmentName><DoctorCode>224</DoctorCode><DoctorName>刘丽光</DoctorName><DoctorTitleCode>2</DoctorTitleCode><DoctorTitle>普通号</DoctorTitle><DoctorSessTypeCode>2</DoctorSessTypeCode><DoctorSessType>普通号</DoctorSessType><Fee>10</Fee><RegFee>10</RegFee><CheckupFee>0</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>30</AvailableTotalNum><AvailableLeftNum>6</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>957||82</ScheduleItemCode><ServiceDate>2018-03-22</ServiceDate><WeekDay>4</WeekDay><SessionCode>02</SessionCode><SessionName>下午</SessionName><StartTime>13:00</StartTime><EndTime>22:00</EndTime><DepartmentCode>17</DepartmentCode><DepartmentName>呼吸内科门诊</DepartmentName><DoctorCode>222</DoctorCode><DoctorName>曹晓慧</DoctorName><DoctorTitleCode>2</DoctorTitleCode><DoctorTitle>普通号</DoctorTitle><DoctorSessTypeCode>2</DoctorSessTypeCode><DoctorSessType>普通号</DoctorSessType><Fee>10</Fee><RegFee>10</RegFee><CheckupFee>0</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>30</AvailableTotalNum><AvailableLeftNum>6</AvailableLeftNum><TimeRangeFlag>0</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>963||9</ScheduleItemCode><ServiceDate>2018-03-22</ServiceDate><WeekDay>4</WeekDay><SessionCode>02</SessionCode><SessionName>下午</SessionName><StartTime>13:00</StartTime><EndTime>22:00</EndTime><DepartmentCode>17</DepartmentCode><DepartmentName>呼吸内科门诊</DepartmentName><DoctorCode>224</DoctorCode><DoctorName>刘丽光</DoctorName><DoctorTitleCode>2</DoctorTitleCode><DoctorTitle>普通号</DoctorTitle><DoctorSessTypeCode>2</DoctorSessTypeCode><DoctorSessType>普通号</DoctorSessType><Fee>10</Fee><RegFee>10</RegFee><CheckupFee>0</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6,7,8,9,10</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>50</AvailableTotalNum><AvailableLeftNum>10</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule></Schedules></Response> ";
                }
                else
                {
                    returnValue = @"<Response><ResultCode>0</ResultCode><RecordCount>2</RecordCount><Schedules><Schedule><ScheduleItemCode>957||74</ScheduleItemCode><ServiceDate>2018-03-22</ServiceDate><WeekDay>4</WeekDay><SessionCode>01</SessionCode><SessionName>上午</SessionName><StartTime>08:30</StartTime><EndTime>12:00</EndTime><DepartmentCode>17</DepartmentCode><DepartmentName>呼吸内科门诊</DepartmentName><DoctorCode>222</DoctorCode><DoctorName>曹晓慧</DoctorName><DoctorTitleCode>4</DoctorTitleCode><DoctorTitle>主治医师</DoctorTitle><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主治医师</DoctorSessType><Fee>10</Fee><RegFee>10</RegFee><CheckupFee>0</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>30</AvailableTotalNum><AvailableLeftNum>6</AvailableLeftNum><TimeRangeFlag>0</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>957||82</ScheduleItemCode><ServiceDate>2018-03-22</ServiceDate><WeekDay>4</WeekDay><SessionCode>02</SessionCode><SessionName>下午</SessionName><StartTime>13:00</StartTime><EndTime>22:00</EndTime><DepartmentCode>17</DepartmentCode><DepartmentName>呼吸内科门诊</DepartmentName><DoctorCode>222</DoctorCode><DoctorName>曹晓慧</DoctorName><DoctorTitleCode>2</DoctorTitleCode><DoctorTitle>普通号</DoctorTitle><DoctorSessTypeCode>2</DoctorSessTypeCode><DoctorSessType>普通号</DoctorSessType><Fee>10</Fee><RegFee>10</RegFee><CheckupFee>0</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>30</AvailableTotalNum><AvailableLeftNum>6</AvailableLeftNum><TimeRangeFlag>0</TimeRangeFlag></Schedule></Schedules></Response>";
                }
            }

            if (requestCode == "10041")
            {
                returnValue = @"<Response>
              <ResultCode>0</ResultCode>
              <RecordCount>2</RecordCount>
              <TimeRanges>
                <TimeRange>
                  <ScheduleItemCode>963||1</ScheduleItemCode>
                  <ServiceDate>2018-03-22</ServiceDate>
                  <WeekDay>4</WeekDay>
                  <SessionCode>01</SessionCode>
                  <SessionName>上午</SessionName>
                  <StartTime>08:30</StartTime>
                  <EndTime>09:00</EndTime>
                  <AvailableNumStr>1,2,3,4,5</AvailableNumStr>
                  <AvailableTotalNum>5</AvailableTotalNum>
                  <AvailableLeftNum>5</AvailableLeftNum>
                </TimeRange>
                <TimeRange>
                  <ScheduleItemCode>963||1</ScheduleItemCode>
                  <ServiceDate>2018-03-22</ServiceDate>
                  <WeekDay>4</WeekDay>
                  <SessionCode>01</SessionCode>
                  <SessionName>上午</SessionName>
                  <StartTime>09:00</StartTime>
                  <EndTime>09:30</EndTime>
                  <AvailableNumStr>6</AvailableNumStr>
                  <AvailableTotalNum>5</AvailableTotalNum>
                  <AvailableLeftNum>1</AvailableLeftNum>
                </TimeRange>
              </TimeRanges>
            </Response>";
            }
            if (requestCode == "4904")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><ResultContent>结算成功</ResultContent><Invoices><Invoice><InvoiceNO>221547</InvoiceNO><InvoiceAmt>23.70</InvoiceAmt></Invoice></Invoices></Response>";
            }
            if (requestCode == "4905")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><PayListInfos><PayListInfo><Adm>56</Adm><AdmDate>2018-03-21</AdmDate><AdmDep>19</AdmDep><AdmDepName>消化内科门诊</AdmDepName><DoctorId>242</DoctorId><DoctorName>夏先明</DoctorName><PayAmout>1000</PayAmout><ReceiptId>221548</ReceiptId><ChargeDate>2018-03-20 17:10:36</ChargeDate></PayListInfo><PayListInfo><Adm>57</Adm><AdmDate>2018-03-21</AdmDate><AdmDep>19</AdmDep><AdmDepName>消化内科门诊</AdmDepName><DoctorId>242</DoctorId><DoctorName>夏先明</DoctorName><PayAmout>1000</PayAmout><ReceiptId>221549</ReceiptId><ChargeDate>2018-03-20 17:22:43</ChargeDate></PayListInfo><PayListInfo><Adm>58</Adm><AdmDate>2018-03-21</AdmDate><AdmDep>19</AdmDep><AdmDepName>消化内科门诊</AdmDepName><DoctorId>242</DoctorId><DoctorName>夏先明</DoctorName><PayAmout>1000</PayAmout><ReceiptId>221550</ReceiptId><ChargeDate>2018-03-20 17:31:12</ChargeDate></PayListInfo><PayListInfo><Adm>60</Adm><AdmDate>2018-03-21</AdmDate><AdmDep>17</AdmDep><AdmDepName>呼吸内科门诊</AdmDepName><DoctorId>229</DoctorId><DoctorName>吴敏</DoctorName><PayAmout>1000</PayAmout><ReceiptId>221551</ReceiptId><ChargeDate>2018-03-21 09:08:02</ChargeDate></PayListInfo><PayListInfo><Adm>67</Adm><AdmDate>2018-03-21</AdmDate><AdmDep>17</AdmDep><AdmDepName>呼吸内科门诊</AdmDepName><DoctorId>229</DoctorId><DoctorName>吴敏</DoctorName><PayAmout>1000</PayAmout><ReceiptId>221554</ReceiptId><ChargeDate>2018-03-21 10:00:17</ChargeDate></PayListInfo><PayListInfo><Adm>69</Adm><AdmDate>2018-03-27</AdmDate><AdmDep>19</AdmDep><AdmDepName>消化内科门诊</AdmDepName><DoctorId>243</DoctorId><DoctorName>杨冰冰</DoctorName><PayAmout>1000</PayAmout><ReceiptId>221556</ReceiptId><ChargeDate>2018-03-21 14:26:21</ChargeDate></PayListInfo><PayListInfo><Adm>70</Adm><AdmDate>2018-03-21</AdmDate><AdmDep>17</AdmDep><AdmDepName>呼吸内科门诊</AdmDepName><DoctorId>222</DoctorId><DoctorName>曹晓慧</DoctorName><PayAmout>1000</PayAmout><ReceiptId>221557</ReceiptId><ChargeDate>2018-03-21 14:26:44</ChargeDate></PayListInfo></PayListInfos></Response>";
            }

            if (requestCode == "1013")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><RecordCount>13</RecordCount><Doctors><Doctor><DoctorCode>222</DoctorCode><DoctorName>曹晓慧</DoctorName><DoctotLevelCode>副主任医师</DoctotLevelCode><DoctorLevel>2</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>223</DoctorCode><DoctorName>钱堃</DoctorName><DoctotLevelCode>主治医师</DoctotLevelCode><DoctorLevel>3</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>224</DoctorCode><DoctorName>刘丽光</DoctorName><DoctotLevelCode>主治医师</DoctotLevelCode><DoctorLevel>3</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>225</DoctorCode><DoctorName>黄红春</DoctorName><DoctotLevelCode>主治医师</DoctotLevelCode><DoctorLevel>3</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>226</DoctorCode><DoctorName>黄芸</DoctorName><DoctotLevelCode>主治医师</DoctotLevelCode><DoctorLevel>3</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>227</DoctorCode><DoctorName>李娟娟</DoctorName><DoctotLevelCode>主治医师</DoctotLevelCode><DoctorLevel>3</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>228</DoctorCode><DoctorName>林明珍</DoctorName><DoctotLevelCode>主治医师</DoctotLevelCode><DoctorLevel>3</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>229</DoctorCode><DoctorName>吴敏</DoctorName><DoctotLevelCode>医师</DoctotLevelCode><DoctorLevel>4</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>230</DoctorCode><DoctorName>常静静</DoctorName><DoctotLevelCode>医师</DoctotLevelCode><DoctorLevel>4</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>231</DoctorCode><DoctorName>吴海燕</DoctorName><DoctotLevelCode>医师</DoctotLevelCode><DoctorLevel>4</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>232</DoctorCode><DoctorName>严青</DoctorName><DoctotLevelCode>医师</DoctotLevelCode><DoctorLevel>4</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>263</DoctorCode><DoctorName>王锦</DoctorName><DoctotLevelCode>主治医师</DoctotLevelCode><DoctorLevel>3</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor><Doctor><DoctorCode>944</DoctorCode><DoctorName>doctor</DoctorName><DoctotLevelCode>主任医师</DoctotLevelCode><DoctorLevel>1</DoctorLevel><DeptId>17</DeptId><DeptName>呼吸内科门诊</DeptName></Doctor></Doctors></Response>";
            }
            if (requestCode == "10041")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><RecordCount>1</RecordCount><TimeRanges><TimeRange><ScheduleItemCode>969||2</ScheduleItemCode><ServiceDate>2018-03-23</ServiceDate><WeekDay>5</WeekDay><SessionCode>01</SessionCode><SessionName>上午</SessionName><StartTime>08:30</StartTime><EndTime>09:00</EndTime><AvailableNumStr>2,3,4,5,6</AvailableNumStr><AvailableTotalNum>15</AvailableTotalNum><AvailableLeftNum>5</AvailableLeftNum></TimeRange></TimeRanges></Response";
            }
            if (requestCode == "1000")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><ResultContent>预约成功</ResultContent><OrderCode>969||2||2</OrderCode><SeqCode>黄芸</SeqCode><RegFee>10</RegFee><AdmitRange>10</AdmitRange><AdmitAddress>门诊楼二楼</AdmitAddress><OrderContent>000000000333^60^测试二^男^2 号(上午)^2^呼吸内科门诊^黄芸^2018-03-22^15:44:04^2018-03-23^^^0000000060^2018-03-23 08:30-09:00^自助机0001^窗口预约^10^普通号^周五</OrderContent><TransactionId></TransactionId></Response>";
            }
            if (requestCode == "3006")
            {
                returnValue = @"<Response><TradeCode>3006</TradeCode><ResultCode>0</ResultCode><ResultContent>保存成功</ResultContent></Response>";
            }
            if (requestCode == "1005")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordCount>2</RecordCount><Orders><Order><OrderCode>1026||1||1</OrderCode><OrderApptDate>2018-03-20</OrderApptDate><OrderStatus>normal</OrderStatus><OrderApptUser>新测试</OrderApptUser><PatientNo>0000000048</PatientNo><AdmitDate>2018-03-21</AdmitDate><Department>消化内科门诊</Department><Doctor>夏先明</Doctor><DoctorTitle>普通号</DoctorTitle><RegFee>10</RegFee><SeqCode>1</SeqCode><SessionName>上午</SessionName><AllowRefundFlag>Y</AllowRefundFlag><PayFlag>TB</PayFlag><HospitalName>安徽医科大学第四附属医院</HospitalName></Order><Order><OrderCode>1026||1||2</OrderCode><OrderApptDate>2018-03-20</OrderApptDate><OrderStatus>normal</OrderStatus><OrderApptUser>新测试</OrderApptUser><PatientNo>0000000048</PatientNo><AdmitDate>2018-03-21</AdmitDate><Department>消化内科门诊</Department><Doctor>夏先明</Doctor><DoctorTitle>普通号</DoctorTitle><RegFee>10</RegFee><SeqCode>4</SeqCode><SessionName>上午</SessionName><AllowRefundFlag>Y</AllowRefundFlag><PayFlag>TB</PayFlag><HospitalName>安徽医科大学第四附属医院</HospitalName></Order></Orders></Response>";
            }
            if (requestCode == "2001")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><ResultContent>取号成功</ResultContent><SeqCode>3</SeqCode><RegFee> 10.00元</RegFee><AdmitRange>21/03/2018 09:00-09:30</AdmitRange><AdmitAddress>门诊楼二楼</AdmitAddress><DeptName>消化内科门诊</DeptName><DoctorName>夏先明</DoctorName><DoctorLevelDesc>普通号</DoctorLevelDesc><TimeRange>上午</TimeRange><RegistrationID>16</RegistrationID></Response>";
            }
            if (requestCode == "8080")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><PatientID>0000000048</PatientID><PatientName>新测试</PatientName><SexCode></SexCode><Sex>男</Sex><DOB>1990-08-08</DOB><MRID></MRID><Address></Address><IDTypeCode></IDTypeCode><IDType></IDType><IDNo>340123198508154127</IDNo><PatType>自费</PatType><AccountID>36224</AccountID><DepositAmount>99</DepositAmount></Response>";
            }
            if (requestCode == "8081")
            {
                returnValue = @"
<Response><ResultCode>0</ResultCode><ResultContent>充值成功.</ResultContent><DepositAmount>10099</DepositAmount><InvoiceNo></InvoiceNo></Response>";
            }
            if (requestCode == "3013")
            {
                returnValue = @"<Response><ResultCode>0</ResultCode><ResultContent>可以发卡</ResultContent><CardDepositAmt>0.5</CardDepositAmt></Response>";
            }
            if (requestCode == "3014")
            {
                returnValue = @"<SavePatientCardRp><TradeCode></TradeCode><PatientCard>000000000299</PatientCard><SecurityNo>6472958783</SecurityNo><PatientID>0000000068</PatientID><ResultCode>0</ResultCode><ResultContent>建卡成功</ResultContent><ActiveFlag></ActiveFlag><TransactionId></TransactionId><DepositAmount>0</DepositAmount></SavePatientCardRp>";
            }
            if (requestCode == "10016")
            {
                returnValue = @"
<Response><TradeCode>10016</TradeCode><ResultCode>0</ResultCode><ResultContent>取消订单成功</ResultContent></Response>";
            }
            return returnValue;
            //string path = Server.MapPath("WebService20180112.txt");
            //string request = InValue;
            //string response = string.Empty;
            //int startIndex = request.IndexOf("<TradeCode>");
            //int endIndex = request.IndexOf("</TradeCode>");
            //request = request.Substring(startIndex, endIndex - startIndex);
            //string text = string.Empty;
            //bool exit = false;
            //List<string> pathList = new List<string>();
            //pathList.Add("WebService20180112.txt");
            //pathList.Add("WebService20171220.txt");
            //pathList.Add("WebService20171211.txt");

            //pathList.Add("WebService20180301.txt");
            //pathList.Add("WebService20180302.txt");
            //pathList.Add("WebService20180303.txt");

            //pathList.Add("WebService20180304.txt");
            //pathList.Add("WebService20180305.txt");
            //foreach (string item in pathList)
            //{
            //    path = Server.MapPath(item);
            //    using (StreamReader reader = new StreamReader(path))
            //    {
            //        text = reader.ReadToEnd();

            //    }
            //    while (text.Contains("Stack(WriteModuleLogLn DoService )"))
            //    {
            //        text = text.Replace("Stack(WriteModuleLogLn DoService )", "");
            //    }
            //    while (text.Contains("\r\n"))
            //    {
            //        text = text.Replace("\r\n", "$");
            //    }
            //    string[] arry = text.Split('$');
            //    for (int i = 0; i < arry.Length; i++)
            //    {
            //        string value = arry[i];
            //        if (value.Contains("Request") && value.Contains(request))
            //        {
            //            response = arry[i + 1];
            //            int startIndex2 = response.IndexOf("<ResultCode>");
            //            int endIndex2 = response.IndexOf("</ResultCode>");
            //            string responseCode = response.Substring(startIndex2, endIndex2 - startIndex2).Replace("<ResultCode>", "").Replace("</ResultCode>", "").Trim();
            //            if (responseCode != "0" && responseCode != "0000" || response.Contains("<Reclocs></Reclocs>"))
            //                continue;

            //            int requestStartIndex = response.IndexOf("<Response>");
            //            response = response.Substring(requestStartIndex, response.Length - requestStartIndex);
            //            exit = true;
            //            break;
            //        }
            //    }
            //    if (exit)
            //        break;
            //}
            //return response;
            //if (InValue.Contains("<TradeCode>3300</TradeCode>"))
            //{
            //    return GetPatInfo(InValue);
            //}
            //else if (InValue.Contains("<TradeCode>34001</TradeCode>"))
            //{
            //    return GetPatInfo(InValue);
            //}
            //else if (InValue.Contains("<TradeCode>10121</TradeCode>"))
            //{
            //    return QueryDepartment(InValue);
            //}

            //else if (InValue.Contains("<TradeCode>1012</TradeCode>"))
            //{
            //    return QueryDepartment(InValue);
            //}
            //else if (InValue.Contains("<TradeCode>1004</TradeCode>"))
            //{
            //    return QueryAdmSchedule(InValue);
            //}
            //else if (InValue.Contains("<TradeCode>1014</TradeCode>"))
            //{
            //    return QueryAdmSchedule(InValue);
            //}

            //else if (InValue.Contains("<TradeCode>10041</TradeCode>"))
            //{
            //    return QueryScheduleTimeInfo(InValue);
            //}
            //else if (InValue.Contains("<TradeCode>1101</TradeCode>"))
            //{
            //    return OPRegister(InValue);
            //}
            //return "";
        }
        #region  //获取发票
        [WebMethod]
        public string GetINVImage(string InValue)
        {
            String response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><INVImage>iVBORw0KGgoAAAANSUhEUgAAAzcAAAJpCAMAAACn/DzbAAAC6FBMVEUAAACcAP8mJykA/ync4OYXNV339/ffDA4AXv8RERK1ub1dco6f/wAA/xMAEv/v7+//AFL8/v7Dy9V2h5//5QCWpLZUV1ri7vf/XgAA/2pyd3zo8vj/ALk1AP/y+PvM0tuvucdM/wAA/8c+Pj58fX75/P3/GwCIl6v+/v6jr7//nQAAnf/r7fEAJ/84ODi5ws7u9Pr/AIdpAP/0+PvfAP/U2uHk5+zm7/f6/P3s9Pn/ACocHh8A/5XJ/wAf/wDw9vp2/wAA5f8HBwgAx///QADBAP88PT//uwD4+vwA/1Hq9PlFRkYAfv//fAASAP8AQP//AA+Zm57/AO3/ANnv9voxMjT/AGb/AJsA/6nd/wCIAP9EAP8u/wA5Oz71BgTo8fjm8Pg6PD4A/P0A/4EA/90C/wK+vr/0+vy6/wBd/wAAsf//zwDq9PqG/wD5/P7/KgD/ADmwAP8A/z1MT1Hp8vr+/ACqrK78/f0LCwwDAf/q8/rk7vh4e30Aav9aXV7s8/oAif//hwDl8Pj/aAD/AMP/pwDpAP8A0f//SgDLAP8ASv//AHD/AKUA/7Pn/wAjJSb9AP8ANv94AP8A/2AhAP//AB5TAP89/wBs/wCV/wD/AEgQ/wAA//Hw9vz2+fwrLS5+f3+6vL7/DAAA/3YA/9MWFhfy8/Xf3995fH1XWl0/QECp/wD/AFz/7wAAp///AJEA/5/T/wAA7///xQD/AOMA/4sA/+cAu///2QD/NAAAdP8Ak///kQD/cgD/AM3/sQDzAP8A2///VADVAP8AVP//AHr/AK8A/73x/wD2+vw0NTfq8vgODw8fICH0+Pz6/P7/APfy9vu3t7dYW12fn59gYGD4+/51eX1ISEjy9/wpKizy+Pzs9PoeHx9QUFB6fH78/f4TExQzNDZERklXWl5AQEA8Pj/p8frj7vhcXl94e34SEhJ4fH5ZXF41Njjm7/ksLi85PD4MDA0ODxAgICAHCAhYW14REhKuvDs7AABSUklEQVR42u29TYwcR9omFjA6qmD3oaq60RKxA1QT2CEYBApOFYQuj3oOAghiQAyggwE557RW6/LpMhgWwEGtIS38QdKFQB188iWBT548uHP8oYA+E5i5EKjDWJaELae5an+rXZq9PRwvaI66e/jx6vzP+M3K6q7frudpsrvyp6oi34gn3p+IeIM0GQAAE4I0IAMAmJg30DcAAH0DANA3AAB9AwDQNwAAfQMAy43G9AB9A6wNmsdT+4G+AdYGlUajOaX/0DfAOumbypT+Q98A6+PfhJoixNX/Qt8A66NvKol3cvW/0DcA/Bv4NwAA/wYApunfpGhGP+HfRq1RaVSSV6EmiY9CP6aSXQ9RSe5PfBzoG2Cd9E30c3B+l1wEP3eDn4tOcKbTJHe94Ohv4Zng+vEBuVu5SO5pkovs7uCogvEbYE39m9fkG/I6+Pkh+B9okkDTBH+jM8FPcL0mHEe/z8PfwbsqtQr8G2A9/RtyUTuIX3sXx2+Ti+NA3wR0CHXKRfgqOgp0Sy08d0AugqPo/tpdcgD/Blg3/yYdf/mGNGM/p9YgB4E+CTVQcIa8CXTKm0ADBdomOHodapZQ35w3Q+8m1FShNgp/MH4DrJG+ScZfAu8l1DCRt3L3ONQgB8d/PY59m/B/dK0V+TLh71D73I2utmIdhPEbYE39m/B/8FNrRtol/Al0SahdzmN/Jrge3lsL/4e6KLonvF5rYvwGWFf/JvJhAl+mWQt9myhedhxrm4uQQORuQKi3K834h8T3hL5NpIPg3wDr5d+kCP2XJHZ2fpAcRyM2oUYJX1dev2mm8bTKOadvzpORH+gbYJ30TfwTeC+xBgk0zPFBKzquNVvNTnB8cTcezznORmyC1wepdiJYfwOsr38TRshiBz/WPOeRv1MJx3KajYPI/wn9nUC3kB8ibRTOJIiia4G/cwD/BlhP/+ai9vZxTJyLSjMds4l8l4OAOtGIzXGkW2rR+E0nOh+N6WD8Blg7/yYdv3kdjdTEv5uNN1F0LRypCcdnGiTxfwLt8iYevyH5z3misaBvgPXRN9n6mUBreJHmqTWP/xr6N+SbSLvcvRuO6ASeThhBOw99ngvy19DfibTMi0r4rgOsvwHW07+JZgpEvkz0vxJpn8jbee01SHj9IPZ34hkC6f3xX4zfrDhubnfCP61N2jHcQPeC3zumy6x1e+dwOkW5vdma5pPtblqz9W+ieWhhhCyak/Y68m+Sa5Vo/CYcswmOA6/m+G463hOGC2oYv9HWzu6Wet8e3dY1r43NabW6S2KT0t2oeDTih4odSjcYCy4bytkJLunksqX5pE4qCxM2klvvRIVpbW3k9NztTPhkW5TulKIrneiTufGbeH5zMkOAJP5Mst4m9mSydTmRvxPNMSDJPas6ftPZnrjFblC1R9TVzo6hVbS03bmhvUrNMLuJEIMIuZfZ611r3DPu0NtJMbZMN4S0iJ9y76baxHZj4pWTQVKazt5hctNO9NlbmnfvxpTksFdOQFzNaAhhFVbMeHll4zd7gQfzghy0krGci2h8pnU3Ha+JZ7DVojU357FmuhtrqtqK50+zCmrCMvaILb5yt7La6exYclML+sgSHdkhpZslCMt9r0gcor7ibmgZ6ZCXdSfudBV9YhVqhDHNM5NBeD1TTJb2y7W82YnfsZWf2SwroOKCbWxIdgDlvmW8vHL/phb4KeehwRX7MdF8gHS9zXloivHH0e+DeK5aOo6zqv7NptoKWmnz2ejwFbij0/gbUStKa2ePaxVpm9nSd8XRJaVBtMw0tugm36hDXpAcCl0Ir3tux/pkDG8C9t5RH7Aj65sdum0miPgAWt7kbXJvT+bN7s1WMW92irrAzUNWkjdq59ARrbbb5fybg1iv1OIRmYta5PHUwrGaeH7ahReO1wSvvPDc28HVbyrxGtG3a6s9frMXVotiT2xrmpW20mLaxbWzsRd1XLtim9kx15xemXUMnvm2ySIT9A3haGV+d26oRsZS/Gh7GkUSPpTCmx2xozZrozG8KbLiJuaN8IiZU5Tz5s4dc6+hyNwor9S/ycdvkmhZrZGs+Hz9Q/w6PB+6/0kkrRaN6jS4GdFxdoKVHb/ZpBu7N/daST0WdMe6SrNimkS10wrpFjakm0KbSY+1vNkpW8pdviJJkVuT/yEliLMXFS9+tDv5PfnttzVNmyt1Z6PoScbwhpdrfF6w4sILtzd3y/FGEJDsFMXQ65DDTV0FjSFOtv4m1DjH0ezmWjI37fjtaD7aQejlhOM0we9wvU0zWpUTRdOiOWoH1yB/2s2bWf83GW86CSlC3rTirnY3dX+SNrOXG93bXAVFgd3yvOkIprsSFVCJROTTO/SO4YN300fb1Knc2HaLAwepvlGs/5bqtVyWN1vFwbadUgLKvybTN3qDbWOjZVDwBnnJ/k2yviYcs4km16Trb5pv0nkBoY+TLCMIfaFQKwUUe5OuyVlF/2ZjNzIKWjd3DbyJjRSRNxbnrqS6JKiUm6mFlmr9pM2IJuBNLhKwNwFvtgUfaSxveGstL+uuvr11kkfbSNvaBnfrXvx6O2nbSXmtLcXL250SbxIJtVp6O+12KQHpeaMv4I7RGNgd79+EFDmIQ8uVi3Q85zheX5PlGDhOcgpU0uvx/SucPy1W0dadQwNvDBG1PVmB7N3cyaJsh7lfEx9taFVVYP+0lEq7c9PkhG2zcrwhorbh7tzTNhyON3e4XqCTt0c97pTyvrVx6GLe7BjiArt05zBiUxkBTcKbTbPjO378ppbMcI59lTSDWpopzWs0msKctGR8h+R511Yznha5JGxnhxl4s5XqDE7f5H3enbxH2uFa0uEhx5s7iZmzown0BDWzIxskeuLcFs0gA2/SyBoh+V1crG1TF6rjeBM8wp3kuXIxtKLQenImbdV3ZJrcEQS3nTXiMfpmu9gQy3izEX9CQXBYEtAkvMmedK8ld6p7Y8dvmul4TOvg+EUrzfscj+e8SGenpZon/qlF74l+/rqy4zdhbWzs7E7Gm6Rqt3Y6nBe6oa2STtyENLzZCE6FraSzIWg3y2AzdMrrG9FGI5xLdaeIN7ubW1u3N8R2n72TtnjeJPQ2j/inH5CNt5jiaXI3cWezI/Kmc/t2/PBbRd2/LKBL8KalDEnfLPBwsrlpiT7xoqgZSfMNfBOtt3kd+z9eI56zFq7NqUXXz1+TN7XmSucXCOR7Z7s1hjebWt4k8rb28tkCLW7gM6qS7bgutvVWtNC7Hm4aA9YdqVzj7DSmnVCwqzNJct7c3mad7Zua5ny4nbaoqLxWHitPR/y1Az9iH6PlTas1ZlRp+za9s8HzprV5u4yA9PE0xsawXSTObsEgK5ffOR6pOY7Gb8KxmXj9TTSGE1w/v4hHdsJ8N7GuqSQrPivxHOoVjadt7LXy3tXEm7iu9bzpmOyMkDfpMF52WghvHnJ3H+4WDNBNzhtF2egal8CbvZ0wwLcZO/l7oo+3JTjfu8rY7J7Jhx7DG413vyd5R3GA0jy0ZuaNUd+kbJfstPEfqh+/iTIJRNol9nVev3ndCCNmodaJx3ei61FW6PM050C02rOx0utvtnLbyMCbDk1mA+t4c4dXGrwxEFSJVWDCxB33TSmgPSXeZOwhpXljWZGbsBGVK2tYrcBK2joU9evuoTrYYZjvOYY3VkHMhR3uxIOgyVsL7bSJeGPwbybiTbb+JvJvouxpd6NcapVkbCaaMRDFz+7ePb57Ht3fiXRTJRrpIVmEbVXHb7Zz7WzgzW7cLHS82RIH+CXepNOgOpr+2IriAlt5HW1OkTfa24p5k5gmN0OB5LbQ7q4mKLan2pu5EhCG5TfH6JuNDeMjb6bKOxmNXS7eiOM3PyQjNdFsgKb3upHMEojWgSb509J1OY0fohGe8/hodeenbXAN1sCb2wJhON4EDf/OXhFvMktZnnBoRca0wJtOoRfWmpw38l27OhMn/uLkCUPL8fBQJnnyIJ1OUpRNjboxhARpcRzaEP7txB+5E5fqduw7jYsLtKbOm92CKQPi+ptYcxy8icZmaqH+eR3vRhAcH5xfHIcRtdckW58TnI+yDaz0/LQdrp71vOnkA5mhmZX5+JZumruWN2G8VZybHg1vc2poDG9Eu78UbwiRL90xxNO2tnO3LJCGJRtdO6mTF62f0A0UcmvNRO86I5Gqb1qbhe55OLKWDuxYndRca1l7pQQ0Fd7cKYin8etvwkwC0VhMOOM5HMFpRitx3lTS2WiNfPTmPB67CXMPvG40VnX/m86OOA1Rz5udxAHak1z/Q7XF6/VNcHZjS7JvwkEeTlWN4Y0lVmGJOHQeVyN5FGJP270H7M106J5mLstO6uTdYWzc3KAdQVnlHYPGTmttFLnnoXzSWQy7hUsYdAIqiqeV5c0hLTF+E8+H/iGabXYRjtt04ihZPFZzEPo/oVfzQzhjIJqR9sPdcCVOOLLTStbgrKK+aW0L4tTyZkvy2NV42hjetKJet6V6BlZ+9xjeHIp2SCFv+GkCfGBgR2t2BGXYPOSeaVttmvGDpFNpCnkjhdryjsEcT9vaSr7i8FAbVbhJt3PhGNffSALS6ptN7VfQgig4K+HfhJqF/BCuwyFZzoBKkqGzluWPju5N568ls6Qrqzx+I4zx6XizJwe6JuVNKzVWLHlK7nbeSY7hTfDe7ZK8IQYPxzQV5o44n2FX9V/iB7GksU9tNyT1DFb2WUbeWMl8bBqSbE8j6U26xfNmp5SA0hAo99ghZ7a2yvOmeOGOsEdnvLKzcuDF+dMOKt8kPk84VnMR7YZzkUbQkh0Mmscrnj9NqAkdb+7ssnG8KfRvuKVs3OIcuZWN403qHZfgjZ5Ce4UrjPNn2lTn+sQPknYwuiHOQA1sxG/ekwp9cwxvNuI4QfQV4cCvJZcqnCVWhjeigALhHmqa/85Oad4UyysfvwnpEe6dFmqQZLQmjKS9eR1liA7OvKk1Ev8mzGMTReAaYcTt/LwSa53V1Dd0HG+KmTZW39zkL+8JDYMfAx3LG145ibwRlnvycQFSvhlkz7StmSQXLXkI9JB1h+502JalD9nSO4d3pO84zB9qR8+bdHJLcvmm2LGEpQqdy1K8EQRkUBvleTNGXtz4zUXowRyH+9ncDVdwhsfHFyRa4xl6N+d303U2lfT+cMeCZrInzqqO33S0vGlxWn7cGhCZNy2+SmTx793Mx6oP+TeO503QLrJlwJK+IcSw/oaPFG+U0bqRUtnWJA+JJ8BGUQN90oo9dZJ0II0dVsibVmq4ppdvCjP0glJ1+IDmmHXS2+PWSbdU78jAm3HyyuenvYk1TC3K99yIcwg0vHhtTbTuRpoP/SbdL6fR9FY4f1pIjB3zWoFy+ka/yjn4WDVtETcvIAuA797Z2topsQze0ufC0chRYk3YPA9LWKvp6rOQOLdbEiu2c3rcNIXSpIfYFoQRGGXW1tZtjjdxjo7WIdd8b6ZdVxy83IkmMHRKrFszCYjnjajr9nZubm1po2zj5cXnhyY/VLL9OtN8abUkY0285008bkO4PT/Jiq+/CUW0ebjRKqDVON5sSfqmk6sTA24mDSO10g4tY34oiXQ39y7XOeyM42T0TPkMuTvSjBe+sW8ZG++eFOvd4/RPzJttIZKcRNtuCrOPMgYdRuyNhFVS32gFtGuMRbfi/nLzMvLKxm/S/TtD7yVbWxON6ATHb2qJvxPNYGtk+aKT3QhWOX/auC5+U22pG3usDG/YXtGMM2li707h9LR5RBV3DvklLHs0t3l2pdUNe6bV5JG3wrW421yEK01Jtp2HFG9mrsxNjqSH1i4XVdi5ySTebE76aDsFCay2abm8dVp9k89P8y6iHW3uxruphbMEovGcaL8bchGtxYlmDxxftKL7o1wD4UjPwRrvf7PLt3h+qm0x7siLERb6EDt096YYo43jUYGrTze3pGfa294yam+OKnuWRoO2bt/Rfr3+8ZPUc53t9E27W9PuLzqXeyO//02UHzreMzqZEd2IF1A34vU4ybVmsh9BcOy9DiNu2N8TWDdw+dNqSe7neD5a5UXt4DzOppblgz5O1+dEvo4XRdUusL8nsH7g19/E2iXJxvl2JZmv5jVJlju6kfg0yT1x3rRa6ANh/xtgrfRNhdvfsxVqlB+SaNlBvO6m0zxO8wpE2sZrHmc5BuLZacfY/wZYN2T+TTPJ81yrJLmg8/nP8fhN7ZtoO/Zv4jGbZAVompsA/g2wlv5Nvv9NtJIz/nscpljPztXi8Zpw/c2LKNvaRZyiY6XHbwDgUv6NsP7mTZ4ZLdnvJvNtQm2U7UYQxdsCyqQjPLXrOn4DACZ9k/o3lchPCUdnvGj3zigfdBRNC7NCR7nSwjU3Yb7oaBZBNB86nkHdPIa+AdbRv6m9IZmfE0fWGlF+6CTDTZLQNj0O80HX4jWgYf60ld7/BgCu5N9kOQbCV/GMgThb2kX8EyZcr4Uzn++eXyS5O+8m4zvwb4A182/4/GmRJxOutqlku3cm2WwSr6eW7o9znnk90T0rvf8NAEyub/j8aUnGzljz3A3zpIX73rQCn+c89HQuOgfRjIJvohWe0XrP81Dr/HXl978BgMv5N2n+AHLeCJM7hVG0t+N9O8MxnTS+Fu1QkOy6luS4eZPkHIB/A6y1f3MQ7n+TrbMJr10kqQXDmdLR/jixdxON5yRz02rwb4C18m/y8ZtU88Sra6KxmUq0JifJqZb5O+nxeaN2Hr2+vutvAMCkbxL/5ptW+vpuK927M8wFHa7BifKnxfkGju9eRLvixB4Qyd4PfQOsp3/D7aRWifyWeJwmi6gl+aFr8XhOGH2LV+esdv40ALiKf3N+N5v1fFGL56dFuw9UDmp3s3wCccrBuyTZL+c42RsH/g2wbv5NMn6T7CkgzI4O/ZZK8rdxUInmocW50pL7GnHErbHa+98AwOT6Jh2/CXMEhHnTapkGakXz1VoH4ThOK977U8jumdx7kO4yDX0DrJ1/42XRtGitTaRxavHO0vEYTvS6lmmiSpI/urKRHUPfAOvn31QSumg0Sva/xh8fVJKdCLD+Blg//2Z6gL4B1knfTOsH+gZYO/9mCv+hbwBgEYC+AQDoGwBYSn0j5pnX5Z0XMoBT+cQSghoPCs4tR8ll8VNNyemSSJiuiFBnpW+o9Nhy3eh4Q6WqXoJ2Fh8JJabC0yS3UW0VE/1ropwg82iTlDsQOrElET8vZlnoC28U8/JvhMfWbHOiqziWKSdjX0M0GzIT06VLNkcqE54yofRUaGVUPsEVi+hJNG/eyOKncvWUED/hxUsUgZPiKiDino1GuctKkfK9k7ZREKW2la9Kj8n8eXNFfUPVPo3qFDTVdOhKB06EF3nVKJcImx5v5JoV6lfLG6KrqbyAQanzGp9xnYriT/WjWEljxE/UX6T4jFoFZDy3NbVAWVGj4AtADJ2SsTaWX9+U4w3X0+h5Q8RmxstLd+nyvBF4QdUbqKJJC2o07W7zbo+IV2fdGcril+y0icRPDHUxvgpIqSZDuT8yuU1+GFHVOGElerHl1zeyoSAdMdloWzBvqODOUKk7LGWnEU1jIVyBc2viakblFey0rHJKil/k99R5QwVzMf7JdCNlZXnDKTtpN28yBz/yavrGsHGjEhQQexjuzUzilblmCJuFvmEyLwoNCKmPyG0xzug2MiRTRfOrVCqaZaXEn7Nc8BaI/oymCkiJRsPpQ1no5kaRfTIRfWAiXyJk3jrnyvE0iURSMJqKt8rXi3gjGtlT0zd8EF0O6hS5ZekNROGKVgcZ4m2zUziShhE88LHizxof1ySJ9sxleEMz8zdzwvhoxbhGodE3WgtursS5qn9TqG8KOng61k7L3IbZ6hslGqjcqypWYoiuESnqM2+zO3PGKLuE+PVdl+GFRhmUsI6l3pQWl0ofpiRCmI8tijdX0zdqDEqnfqjqlo/nDWMzstOoIaahNUG13QORozpC1JaIcdNZGmmGEGABbwrEPyveUEXulPcbjaUyDIuppshq6BtqiJqNuZnquhbJlNUbr/oQ9ZXi0MIInDguyKjJ585KS+TOkCikujrFJ68RUYWWFr8acC71YqKaELta2QvTNwrCxvKG8GGZZfdvNI6MLASq6eo401bLm4nGPS/bjVNlYEMdbzdPuxErlIhxaJLEC7QRjdlyRrCAJhc/0Y1pjn1BJhlzlML+VJ6WoeVN/g2mF5wpv+zxNLPjz/vSVPZJGaXFBva8wk3aQdks8qSyWTdCazS/SOqY5eFSQmZOG7ET0PJm0eLX+TdK1HKlpqxNqm9Ut5nJczy0vJF68QVJSJqfJobK+HgaHR9xL5DpfNsjFYY8mX7qymLFT8X2wrRyXakJalh/AwBziacBAHhzqXiabm69bljHYOkscFUIVeJPBdEp8dZL2WwA9A3j7OiSvDG3Rsrb4YviDVUmQTJjhH0Znddx69aWhOu6frL4WB7sWLpO61LxNKqdZKSZOqznDT/MtVDeUNO4IC3NGyUonbzIjsUzYhxXuccY/dWF5LVPpJkPzRa+bo2ntG65TRrTVDoAOkb4ZPwCLV7whMnhbUXMs9I36cAaU8Sfj7mX1jeseLHS2AVSxuEczVIsJkRDdYPruuW8fB1quzx+iRA3MKguEpGmWGmWjhQPMipDwERnCGum6GvqZiG8kRqQcVKJOjxg4k3h8Gwmb91UHP0Co1nqm0RRKKpFDe1eijfawWvTAill1qH+UxgR6kxaLESppmPIn5SOaWVEL3p1gqdphkrBXP2CJRXp73Hr1qhx8e18aSNNpqWKNaZrNJQxzWIoVkpgGrmaaudSo9NX8G/oeEPWOH6Qre83LboosdBDP6VN8ynMyBtKZWtNnEHMKB3TyPIGXbhyej68UfML6KtnAmunjOVoMoS0nq/BM1Z5k3RZZqNyCry5/KyOy80XUJdRcN1J6XgaP9fiKrwxL1wmSuEp42YHUEHpUDlQoF39KS9eEdcK6WvGwBvRyi5qBrqJO0V2Gi12M8pbO2UsR8kQIqqJovJGu5xO7JjH6sUJeZOTWekL2ORrCy8zX4Aa9U3ZeJps1Kn6t8RCDyI0Pq1UiXRF4E1B1Fm/yIpqmkPeqifmDTE8cZmlSKYOkqoJecSkXcoKsYlmQRONxzZuNQ41TqthRt4o8RtdpzUZb7RzgjkGzVjfcIEwetl4WnEcuqCBiQECVd8QeekLkZQOZZxhxnSZ36gy/XDskoIi3piXkCjuUFFzVZYiZb+L161JA1C6mccz5w0bwxtTdE0XsxGe5RJ2mlbwbD7+DePWR11x/IaZlrqXWuhR5N8Qk22r9cCoNsROx7umQhsiE/GGsPK8YSX1jRqaodqQB3/+krwhquemhHcL4gLmiLMyV93YaS2WN5eZn0Z1vQbVeT0lx2/UpbFX4w1hJXmjSTZGlQiBvi/I7bRUrxG9B6MwWQkHkPFxaJVxhJVYt6Y4P8oKscvxRlMyYqyp4rVABbyhxYMAZVYHaXJ6yMbxpRa9XSKeRrkF40wyaUrxRjc2UhAhNC6QKo5D63t2rfIXiELVDo+O4w3TjGWKlScPbgrDb+MDW4ozywetzOvWNP7adOw0Pmg2touTEyBpBpq0dprGHpGEX2J1kDKqTJRBvsss9pjcv2FMwxtDkLMwnqYLmWhGzwsWSJnGPXVj8DreqMuJZfKPm7+2cBSvW5Narm6F2GX9mwlMA6rvo4p5ox+hFXmzQFzGv6FMjTlzLs/YcU916c6c2pgcX1LqQDqjKR5dPtoUrFsbo2+uFIfWZZbRDwqoBKGKta+30+jSdlpYf7PKGLduzcB1yU240rin1kDQ9LOmxYLKEAA165Ql6rSw/gYAoG8AAPoGAFZa3zQaz767des3AHA9cevWdz/77tmzZ1PVN41nz249/dMn737y1Z8A4Brik08++dPTp7e++26q+iZgzX/7H3//+3/z8t8AwHXE70P8x5/2bj2bor5p3Prq2z8TALju+H/vf9eYnr757n7zH37xi/fe++Uvv34PAJYFJPk/Dfw6aN3v/fA/fnWrMT198/T4nV9//PFPfvuTX/7kl7/+9S8BYBlAuN9XQdikv/7lTz766Cc///+O7z+bnr55+m9/+dHZxx/9FtoGWDJ1My2F8/WnPzn44ouf//P7f3o2NX3T+NOHH312dnbw9TvvvQMAywLC/b4q3nvn64Mv/vLz//PDr342NX3T+OSdj/5ydvbRO+83/+mfmsF/AFgCEO73VRA26eb77/024M3/9s4nP5uevvnqnYO3zz7+5fufvPvJJ1GoGwAWD8L9vgrCJv3uJ+9/ehDy5qvp+TcJb9779umtW7e+++7WLXorQvJHejkDUNOX0Bl8y5iPn+2TTlA+WShUukX3OHRu1UPLijGbKT359xLu91UQNulbT5vvfPTZJLwppW/+m7+cffzh/Z/960YjnHJDGxGSP9LLDCT5zx9LL0mjFMTvi8Vs/Nqy4NfiJB9GpY+m2VckF+iYryTFZ8gUyycKRb5XKxx6NYGNqx8qnBEaR160WIyaKqTSg5f5XjKpTPUIm/S//tn99z/9bPr65rOPf9HMQnTKjgTqmk4+40x2inErNybZikyzHl23GpCQS3yosEqE/1Aqr/Oi+m0YhBLE2SkKV7RPtLTGXD513QoT0nZq1tnOePEKNZWdyutp1a3XxmXiNdTqFDeze3a/+ekX09Y370W8ecqRRJcgiWpaEJ/sTeTNBA2JUh1vqCbF+QSZfjWJbYR1qLp8F2N4Q5L9PfnU1ERNETCF8sk54KkupZXcq80oo7q6FYJh93d9NpsymXgvk8B5Ujz9p7//Ytr6JuLN8S1eEHydaTIFKJmRuJyI4layJRoQlb4vWzh4RX0j15jc8qgmBVQhbwgjXJ+gPOVEvWNx+aiSGmHCjX2mr2pMewdIWaBoqd5CyVszc+Lc+vbfz0bfHD8VeKOmUVF4Q7Rr0CfVN1TNhW76zsn0TdGWHpey0wi3nzTTJeuajDcF5aNKYhpKjfkGZ84bkRl5H6dm304ajlH1mTPxzpw3T//p0xnpm6cNTkxMu0V59lriTdr5ponGyKS80aShoXIajcn9G3mjck0ufKq1krgdzPld2DU51K7Am0nKp7Q4MSmspCqnbK4VbQ6i8xrN9rCSiVdMuTNDNCblTXNS3uj2ilb2BY6bENFb96ndP1kTl7pWlTeTCZcqSfl4a4yaukBa0PIyh4YID6nz8K5YPjEZLFc41X7TGFJT5s2YJOhyVg7KCjwx1cpbVt5cTt8wuTuT42lqd0vEmIE2dX2B0as4j9SUJJdcqpOUtihgegVHS/s32XPytiq5fCcub6HA80bj9xfyZsrahupzhPIWmrBfgilxWlGmqtXXN/KGMVT7qIktRqRYAOf7lA8iUm3I1RgXmIA3VP1QagxBjW13KU24NH1Eyj9OJuONqXw653v86Vk5OOqnU8XVp/wGMLpOV/aUlp03k+ubcZsvSv4NEQIFXM9L2OV4oyRulrJLl+eN7CBQaYsP3UYSZktHSrpHhLTRE6chHlM+DUFoCd7Qufg3VNfLyXrH8BmaxjSPOPRc9M2YwCMV2lDOGyJYceXN/dK8maRjoswwzkl1lc8K4iASb0hhfvxJlGxR+Yp5o6gfMQo8Y97oxm+42I4x9bEmE6+cCHrl/RtWvEk2YbyVJg/ZyF3xRLyhRoudTCJhqtlQgQ96qC2MjrPSWBaHFvZ6kjOsT6d8ig9GmRqEpnJjnImpJpsf6qZ1yhyT0vpmXphPPI3R4t2+jVsIXLZepIFHqiaXVtLNj48CUeM2LFSMPZUfcZ9ev1hYPq5/Fv6KAwSass6INwUqRB8FkHPyF2fiXUbeXMa/AYBrhnn4NwCw9ryBvgEA6BsAgL4BAOgbAIC+AQDoG/AGAG+gbwAA+ubyqPwdMGf8bhXx09//u3/xv05f31xgkwfguuN8+vrmv/j5f/7p79YPPrTHdODBvwEA+DeIpwEA9A0AQN8AAPQNAEDfAAD0DXgDgDcz1jfyRg36heszTYNfCKp5Nb/vHCuhksmbl13KCxb4VIU/H32jJiLmU4upufvpvKWo5rmceqtSE2fIuUq0EpKy5iibouirfxmlPG+Bz1T4c9A31EBoKm+Fsqga5bI5CxKb1beIbYcWSYhJWdrM+xwsvZTnLvCZCn9++dOyFOQyoTXJfui8a1Helo3OvOooU6tOlZCSgH8sb5ZVyvMX+EyFPzd9IyWT024StBDLW5cTeSZ2GmOG1MaFEuKz1RbtR7XkUl6AwGcq/Il5wy7HG6rbTFLdlG7+3rmybRGlZp/66ja9lOOPjpXQRHbaskp5IQKfqfDnxRs5VbGs9xZbo8I2ZVROmD5160SzaW2RhMTtdMyJxpddynMW+EyFPxfeUMnVkk8uDW/yreFmwRt9RIfSAglRNTxq5M3SS3nOAp+p8OfBG5rvQMOK9l1eiOVtKNCM9Y24PVKRhLQegUZCyy3lRQh8psKfp52m29OLyonzF2yn5b7gTHhDtfvTmCWky9BOjZ7vkkt5zgKfqfDnwBspEMpHLqjG3px3jYrjW6mbOhveUFkM4r5Oxk2dTHv6aRvHUkp5AQKfqfDnxxsqxXSUrY4XOH5DVS+RzuhrlJEDOk5C6phdYeNYUinPX+AzFf7ceCPMZWDaHVkXZHmLscYZx6E1kVFaKCF1Qypaqj0um5TnL/CZCn9evFFdWqpsELSY8RtNwH4m2ylTzRi+OL6mkZC4IdWY/aiWV8oLEfhMhT8f3gDA9QJ4AwDgDQCANwAA3gAAeAPeAOANeAMA4A0AgDcAsB68efX//Plf/uMpMBb/1++AVd036s1b0+fNf7mqvPkb9kMCSuIh7DQAgH8DAOANAIA3AADegDcAeDM73hDTASn1ocClQdR6IwTiX3reRJVE1I+J/mdYfPNahkLMijfZo8UPmR4uXvz5d3NFBG8yQeTdWlxNJGMTWY4+j5R8uhXlTSb9WNiE770WKH7C/eJLCN5woiCqVJZH3bBryptMvITnTdKpL4f4iSR88CY1oEmqZqLXXF0RskzMua52GhHVft5/LYX4CQNvDP5NypL8EwiRPZ0l6JivJ23SnirvxKJTyyF+Turgjezf8O8igiOhOIXQNzNrmSQlUe7RLIX4oW+MvOGtbNEBh38zBytNistwR/Bvlpw3nIUmy4gsj6iuazyNcE6OHFFbvPjBG71/w8R443Lyhlxv3uQPKCqfBYufgDeX4w1bmgHHaz3uqfRUZEmeO/t2McQK3vDzApgSTcsHEhgwa97oIs8Q//L6N4XdDapgLn060Yoa4l9R3gAAeAPeAOANeAMA4A0AgDcAAN4AAHgD3gDgDXgDAOANAIA3AADeAAB4A/EC4M2leSNMvZX+IPEdAN4YeMP9IeIqpUXnUxG/WZckAgCWhDcky6ey6MR3yppttlR5QoA15o2wQRWXQkW8uEARiPlURK0IAEuhb5jJTiPgDQDeiHEBwscDEr0jGUdk0bRRciYDwCJ5QwgTc+AzMffqYv0JwhTeLFFiKmCteSMyhT9e+D4STMMbcm1z2wCrExcQTB+OLsvQvROm4Q1j0DfAUsQFiOBxk2VJfCf6NoRpkhUDwOJ4Y/zDFpr4TknrhnFPYMl4Q/S8QeI7ALwp0jc67QO+AOCNgTcAAN6ANwAA3gAAeAMA4A0AgDcAAN6ANwB4A94AAHgDAOANAIA3AADegDcAeAPeAAB4AwDgDQCANwAA3oA3AHgD3gAAeAMA4A0AgDcAAN6ANwB4A94AAHgDAOANAIA3AADegDcAeAPeAAB4AwDgDQCANwAA3gAAeAPeAAB4AwDgDQCANwAA3gAAeAPeAOANeAMA4A0AgDcAAN4AAHgD3gDgDXgDAOANAIA3AADeAAB4A94A4A14AwDgDQCANwAA3gAAeAPeAOANeAMA4A0AgDcAAN4AAHgD3gDgDXgDAOANAIA3AADeAAB4AwDgDXgDAOANAIA3AADeAAB4AwDgDXgDgDfgDQCANwAA3gAAeAMA4A14A4A34A0AgDcAAN4AAHgDAOANeAOAN+ANAIA3AADeAAB4AwDgDXgDgDfgDQCANwAA3gAAeAMA4A14A4A34A0AgDcAAN4AAHgDAOANAIA34A0AgDcAAN4AAHgDAOANAIA34A0A3oA3AADeAAB4AwDgDQCAN+ANAN6ANwAA3gAAeAMA4A0AgDfgDQDegDcAAN4AAHgDAOANAIA34A0A3oA3AADeAAB4AwDgDQCAN+ANAN6ANwAA3gAAeAMA4A0AgDfgDQDegDcAAN4AAHgDAOANAIA3AADegDcAAN4AAHgDAOANAIA3AADegDcAeAPeAAB4AwDgDQCANwAA3oA3AHgD3gAAeAMA4A0AgDcAAN6ANwB4A94AAHgDAKvAm58TYI3wX5+uGf7xX/75F2ev/++p8+bVN//5p78D1gXfgzew0wAA/g0AgDcAAN4AAHgD3gDgDXgDAOANAIA3AADeAAB4A94A4A14AwCL4Q2VX1H+DVT70gR6iafkSk3kJ+BOEO6YxIek8PmJ4TtKyQkAb4p5QxXiUIEIMnFoCDaOWpRHIaP4dkxYOoeXe6KcK/nr+I78fcKbGH+UTwsGb2YGXtzKqfhggja6EryhQmvX8YAKTFApQHWv1ZPUIHEmUcPEhpgo6S3ESAF+Bj3/mYT/GGCqtOF+EfmUKHNyPXiTaA5qMM2o7ncBbfQcKrLhBGVAxIcIT/P9V978o+oRVAwvhJgvJKUk4QlI5tbpXV9QqqtMnjCigIXKvQ684ehCaYHSEPwe2U6jBsOMCQdmS03SA1wTF00swvGKGJq/nka8viEMxLk6cTSVSdj68EawvqLXjGv6+VHCquR0UbCgSN/oiCOaVELrJkLDzxVHzAHBE5JdGMngVtQNI/OxF9aGN4r/QnSn5uZbzj0OTYssr4Q0VBMrMMcYzBYd1drGolZIeSI4nNp4GpGOpDAAMcQdgEtbasX6huhU0Lx8y6XiDU3EVZo3tNBQS04r8TFNLEz0aDLeEJ4sQlSOpFqGVziMITAwLdbwFkqBfyOfmleXNY+4gNC2Rd4oDstE+qY4xiYaUXLj14XX+P4q0UNqlIzkXZ0QwBE1E3hzdUPtMryZl2c5B95oPf+C4BqVeWOIWuuEPLbgWjtNyxvJruN5k9FR7OWILkAKXE3fMFWmugpRjbZrxxtlOIdyjEniAmV4w6kqPW8yyZv1jTwmauaNXDt52CYLJOjqGLiivlHCMIR/Jdjh7FrzhioqhgraiGqMMVrgHSm6TOKNOkapi0OnkpcGeuRBGZ6BxDDnhjCGWNpM7LQlwoL9m9yjyXWIzhijxfYYHWelXRVk/Ml5jlavhaG27rzRe/dyWCDTQ5SZJpsZxlDZckoWuM7AOgIAAG8AALwBAPAGAMAb8AYAb6bNm//l50u4j8d/OAWAKe7j8T9h3yhsoARMzJv/HXYaAMC/AQDwBgDAGwAAb8AbALwBbwBgGXmjrEcrzkgovlzMxGda9mhM9t5FT9s2lZwW3rq45zAUQpOitUSCvSmXfea8UVcKyFk5hTUFTFmqs6S8obqlQnSFeMN3WFxiLiVl8LjnmFEaDMo0CVj4b9ckrMyr5BrwhumzQVNNL5GtYZPX5WjX8Mwr1RLVLx1i4lpVagAzr7abd64oXSIgqlRJfqZcLbDZLEwWvpBqDBJ9mmMqkIjL1DflFjRv3uTPlaxR0ywG1XYWcsanuSWNoXo9QtMn0K1gHV96toCsN9RoUEq80ST0LqqFWTyGZIXp0krkGkbgjVBAOqsWNA/eyImeOIuMmVNCCTsPqPU9ryzM1GisUG51ahFvqF7fzDONtNj5UiYmTeVqiKodQfFzzJQ3ooYsIhg1mM50Vi1oDrwxalxGZYNNs0eHYCjNnzeUGXwYyrcx6YbxpWeLSL8uM4DqjKCMVOWeY0ZPoUvmQqmme+WMF8l0Fq20FeSN1Nikk9wvOQOhYrnyNT2XZkep1KXxj0DFGIfOFTCWfhG8odrQJS3cC2Lsc8zmKQTbizNAKNUl25PMS6qaeUr/F37k0usbbTiNCt1HkaunKKb58UbrDdASdtq40i+cN2JnzCeikzLajXmOmTyFJsSsd7cYp3WoYqfp+ugV4o362HkPzTVA3e5plBkMumXmDStR+sXyhip2DePzCUmxgsLnmNlT6EZsqGykUMFCk/UNowUuwUrwRrQvqbSpANX7gtS4S84CecPnFjXE08qUfgG8oZITI5Sf8s1OSGk37jlmGIfWDpHLxr1KE8o0hV9J/0biPZUqg8rGgzFuKlsIhC2MN7qOeUzUV9p4bs5xaFFz0LyPFnhDlUDIuOeYzSgU1X01Va1gqlym+mCgJtCw9HFoxfFMa4tqBg3G65t0f455DRtSrddF5Y66pL7JA6pzHfc0eP9U+aeh2JjnmJ3ItTn5s+1edI8lz7+hBbxZ8nFPjXugdG3qLAIu9Fhqv4G58Ea0Nrn9erSpqZej9JoyyLwRXQRDAHiez0G1sVUhsKnOIeAnBlC58NMu+7znp+nCBMKgFqVMDj3qbltIm9MMw2knFi5V6ZWSM6lMiqmjGYFe1HNQE4e1AT+eMFLhp112rCMAAPAGAMAbAABvAAC8AW8A8Aa8AQDwBgDAGwAAbwAAvAFvAPAGvLnGKEoEZ760fAmtwJulb2nKVK3CZiPO5TY200W1RDNv5AUcFLxZPG90k1pL1Osy1Bg1l4XqOKVMM2a6dHgLei5DIrh81b6YGq5kArW5p4EDb4pyeS4hb8QcdlTfZcureZXlyAtLqGhIBKddfaPvMbSJ4OaeBm5NeEOVxRT6/HZMWLtfMuXlvO00Lk8XVZue8CYpn5c+/8gcEyqa02+LvDEulZxvAjXoG8UISHKoFOXyLNXTzcFK0PW9/KI1XlXq+nbKdOnwFpFQ0ZgITlrwSbm8kAtMoAbe6HiTpxwy5PIs09PNw0rQ8CbXl8qKfT6ZkpJUibJyKQlnk1mpIBEcVxlGt27eCdTAGylYQwXSFGTPLpPycva1Jus/KvTPphZGheXT6svCljjDR6L6KIHk3zB9Qgw2xwRq4I0ke2rIAsHkxJGlUl7OgTdSUnvKpxKREiiaWphkpy0woWIZ3ug8uoUkUANv5JycxqbHjJkI9Ckv56VvJGpTtf1L+YcENalLv7qYhIrFCa2o6cbCBGrgzXzjAhpTh08cycqkvFw8b+Q8PLpcnpo0kgtKqGjijWALT5pADXHohcTTCnJ5jk15OTfeCP6YIVO3zG9qToe3qISK2kRwVPbZ6IQJ1DDuOQveaEZiqN5r0ebyLKyxefCGVzWZfyPu7KWNIIhhBM2uEwU9+Kwaokme0tjskqaxg77hm6Lr+v6g+ujJvXuPq/ceVf84+NF3zxrlerrZWwmUD4WLCd+pfhc2xdhR5hgsriVqE8EJMUym2WaRd9hESxq8mSVvlJSkaZtxT+zqvtN16i+Hvj/y3eej537/ZdXZd6p1u3darn3NY9xT+xjSFmZ8i1LS+WUjJ2iJ4E1J3mgSLFL66uTHavVx9cfq6akaQWt4bnDl3oMvfa+C9gWsq50m49gb1vedvus1Cz6labn97n59GFAHAMCbin/jwZPPEzp4wb+R8ZMq3udPHjzxwRxg3Xnjvuw6fe84PbRHrGczv1VAnaGz/9JFRQHry5uG++TxI7fGnXF6dt9pO6Oiz6uNHt174kLpAOvJm+bI3u+7gk/j2fXwx/O4U1ZIFUt6Z//BjVETtQWsH2+8G/dueLLVNrDb9mjAs8QZdO3+sC5/aPjuGqoLWDPedPyuHXkpLu/LHPm9o0Fn2Bf9G8vr+R3uMKaVa++/9FBhwBrxptl79HgUeyj9IXdr22/XB87QKdQkA3vg9YLPqvQeOz3klgLWhjetgROrlF7b6/UF1XLktXtsYBV83KjdG7q25QXcavUdu4U6A9aDN+69J5GJ1rQ92+7ZzOLUi1vzB35hPC14h9fvNZ3IRnOf3ENMeh1By16lbC6z/WbPm4q//zIhilv3B726Z7e5MIA9sI+OCnhjDduWf8RGfhIfeNn1oXLWgCfGFGG6VEdCChR+DS41ZHNZft54Xz7InRLf8YZ9p8+ZarbVDLwbt2f2btq9UXC/nYYEGqMHg8WFB5at27u2D2JOEaYrITWuiFDzXE5nIvCseWM5XS8rdqvXtgftzulR/sh998y2baetVBlNHaAjr35kPRzmJ6njuEripbl3e0rftpBu79o+SNkUYaL20TyKzJspLTyZMW9Gj55UuGLbVd9jo26mb6g3sINzVq/PxNR+WbWdntn1fs+u8rxpPLk3UtJDzCvHpWZdNL1Mt7dk/bco+fn335rymlKEKeylcrWoqWGnvtBxtrzxHbvJF/tXR7Qz7O+7uXTc1tD+FesdxY/8KpGHl0rF658ctdvspG0Lldh3fKoUi8y32xMqZeJuj815ffG4/ptpE/HOr/9Wy2tOEWbusGTXR9WPK8Eb/94HYj14Trc+qnVfnVSzhEqvutXTateOH/2hM+i3ffcs8GDiJ7Xdqj/oWV2L8UvEaPODxz/KqWFnlRzW2O3JjWiSbo/NO5/FuBSP4jqp+fffeg9LmyJMQ2GqXqSaO+lq8KbdbWdGaHKt3euwt+zWkd1O68S36cBy/FQ2Na/nDoeOFR9Zdq/btobfd4XaDzwm+mO1rZRqzt2emmisfLc39/xJBQ+i0mYB/bemvKYUYZR/HEo1KpUyrX5cEd749/4g918RTgeO3Uuf2XO8V4Naz0slwdsHjJ5Vu2c26zonfOWOunbgOf3tnj8X3sym21sAb4wPotKm3IPMNEtiQYowykz5RZWubBXtND/SNp7Cm5O+M8zSvbQGgWZxOkxNjhZJx/Zqvsv8I77i3K7n9zuMtqvPp96LTNrtcf7NZN3eIvSNOcWjLhP3+AeZPW/0KcKEBGJUzqjKCjyhVeDN3+59EGgF264xWus/zEr+atDvean+CByeMKJcYwbeVC1WGzDWt7j8RIG28ZlfPaH0g8ejOfCmsNuTKqV8t7dYfaNN8cg0kbX59d+mOAbV8UZOp0V1eYQMHdaSx6F/rNrNgDfNfqBbanY3e5RX4bK1oy7TudmUd/6D31Zw25FFrSGX18vtntH975k1eMia1a47FzvN0O0J/dyE3d5ieGNK8cjbawvqv3VxDKaJmVFjKnumtyhVRb/M455etdqMxj2b1b43bIt5kRvP66+UTpDKG14wZp0xz/ZO+l5efaOBP/Abtu/ZVUYbN57U5hSH1nZ7TNlpqXy3twjemFI8ahpimQeZaXZRqksCT6ULQkL7PFEiNYStp4nZ8KZlV0/i+QL0Rb/b5VVK5KHoeEPFJKvx0ckJ7R7lj31i+32vb7u27Ud3dvutqfYik3R72ohU+W5vAXFo04Podu0o8SAzzS6q3W9PmjJAqZxCkXLsETfAWw3e+A/O0vlptaEz9CR17408ypgpT6zUq/j5PJ1Rt9evt53T6rAX95begz+wmc75KOj25DDUxN3enMc9zQ8ihQIW0n+vGmbCG3e/l85P6wzbTXtwJlrZTNX+gg1AqcSG+KBnd9uDk33HG7lpstjR/myXFRR0e1Lft5hubzoPIswQWPIHuca8qT3+Yy3lTbsdqBynyk1hFrcql0azuGqRq7kx7FarPd/p2YP8oxof3EOiG+Ba8KY5qHfE9Z7eYGS33RbrXKGgnu2326P+oG3b/KIDr24jzw1wHXjTezyS8wv4Nhv1nbpzed3g97227dcc27PFtTruvR5qEVh93niP+kpejlqYy8bzj66y4KwdrtPxh/ZQOt93kOUGWH3e/OFxRc0D5b+8akG9nhcwr/tSyUVQefwHVCOw6rzpdEea/Gkt58UUCvuiZ0vKpXXE2Gi/g3oEVps3jRtfVnR5B/vWFArbGzhC2Lk2cvqBwrlxA6EBYLV5M+qOGl+5RwpvhtNwQsJ50DyN7IEVBrjd7ggVCawybxqDG6zxVeDCn0q86U1D3whpPb2B7TMvyiR940uk8QRWmTfuvscatWHHrZ5aIm+mnPTMatdHrtu3nWEYqesiGSGwyrx58sfgI3v+gX/2o91vjGYVIa4MB3Xb6fcDK21kB1roj09Qk8Dq8sYN/XZ30On0X50M3MawPhM9UPOdttcbMM8Pvy6cPzByoHCA1eXNB0+aUbMe+h9Xe0+9emVoy6P5tOBQmNRuShRZ8e16qMdse9Af1QMXZ9BgjSefz0dctNzB8ufrBJaIN60osNX46u0j+7nTejrssFH7P3QfmhJFMtNKw8JEkUe2M+qN/HY9nINwlNBytD+bpNEFaS655ar5o+jTji1Bvk5giXnjP6qxfL2n1WbNQYP6g5Ep46WaeFFaYKVNFNm2e77ddt5U3ySFIYTVouw2hF/Swr2+/DqXwjSX/BIWaYb+otJcAivIm+N6lMA2zstx6rUt1nbZK5t5RRkv81ZWpG/4X63QTHP3WafeJ3GRgj/DeoURvoDcckoyNd4IpeeXP0hZPBeW5hJYQd54D7ycN7/w655nM1b1ijNeyr1ziUSRPZvV+sFH+yOSFSr4bqKWM+fV5XljTnOpW0ScpRRlC0lzCawgb4aDY443x5bd7zHr+7IZL02JidVEkbW+24tyrnG6pVJvz4Y3BWkuKZ86Le8K6ALTXAKrx5vKozioleeHHvXb7VO+qVFtgoXi3JCaRJFnfceV/ZfPnxDVpUmsoavZafrSy9mVs1RW40o/24RvwMrxxtv3JN6EYzkPx2S8lCyZNDdkcaLIZMc23pfx9s+JdCrjzJX0jTnNZaZLcr2T8GZuaYqB1eeN/6ii8IY1n4uqRch4aYwEjEsUWakIpSGRtiPyqZg3hFwhdFWYr1PWJ6m+WWCaS2D1eJNuPyjuU1ic6FfVN7oD485LPEn6VS1vrtY+C0vPpxPJbqRskWkugZXjTfPByMSbooyXZTwbY0Jvnhfug9eMM8tUo+2yvClMU5xFAlN7TYimzTxNMbDyvHHjpZgdlTclE/2OiQgoCVZT8+vi/Idq1WWW4yZnks58SuOe5tJz/o2UaHRuaYqBleeN/zhcddl3Ko2ayBtzol9lvgDlc+SXSBTp9Xy73n3ZHnU91ng8g8Q25tIrqRG5ODRDmkvwpixv7Mi96fVZv97rec8z3oxP9JtFpjLCjE8UWev0/L5dPzryB7Zj18MAW9+eAW+MpdekRqR5vlGkuQRvSvImnpLs9Zk/9F/Wq9WXvje7BE2eXW/7bWfUa9dd5vfbTiMcwUF1AqvGm8q+yzr13rDHevZw1K92675t91uzKrfbCf7bzrDusXbPtd3ekLn7x6hPYMV4497zmDdqh0ZTzx6EewY8bTr1mSXMsBzf9SxvZPtsEGic7qDHvHtYvAasHG+6UYY02/Ns1z2y952h541mmNisddQPKHrk+GzUbo2OgjMv9sEbYNV440feRW3Aak67/9I5qw7tQX2mGWitXnvoDPqBXVgfOGEs7ZGP+gRWjTdhQibWsVnb/pXrtz/uWk8bMwwMsGPbHvZGnY7db3rR9rqMDcAbYNV4M/gg/O0FbsbID/yb6v/sWzPNomnVfbcdEMXPs019PkB9AivGm362T0A4X2Dvx7O+7dj+380Odr3f6wln6oO/WzRGvwPWAz/9/b/7F//HydV5kzsX0Tyb/yGahvyGzBPnVQIAc8R/d3XeOCJvnv/4X7nz7uxfdv9u9VCDzbPWdlq+7VlDtx/BPDC6h/oEVow3kr5ZBG98B/UJrBhvHriL1zcPUJ/AivGmW07fdLg5ZLUWa+UjPIaNPrzyDoDfRX0C19O/6dUr2fik53i+nRGnnnyA53uu53lWP77i94NTJfXNY9QnsGK8qZfTN347cIUSk86yI1akH5Cww7P7R4N+v10PFFDHs9y61euXm+cWT1kAgBXizaNyvOkFRKlHJlnF8xxm+7E2sTxr0PPa7VgLsXAiwMCK9lQbtJ16v5zC8R+hPoEV443dL+BNus7R65w5+3T/1Sml9Mx2bdo9fXXiBEfdrrPfHh71wxtti/UDjRRl5AwVknPELCp+TnYgrD4e2ko6QABYbt7E89PG8MYd2M5gMKjXh4z27ECzdId2NXB3gutuPbmRVh+edZ+fuIHddvb92anTq/rt+qmGN1L2C0p/rGIZP7BivPEHJXgT3Hbk9hy371LWO7LsXveEJvvjvBXqK69bY9QeBv7N/lHAGzo8OnVPRr/ye68KeJMt+g/ZBd4Aq8WbJ3reSElren2/N7D6QQsfBfqmvd+rda2ALs6gOgj+d6vfsxOHBf4NDf0byuxu/9Qe1itcFgzGW2JCXoxHP4I3wIrxxt1v6nkj/mrbdqfu7Qe+S69tDepvtb3wfSeMfX+U3HPSDdydt2jo39Dg7KuTTtfh99HgtmoSt5hq7p/AvwFWjTf3vPG88QYD2+sOTsOYc68f+Den3bNu3NSro0AFuRFvPLfb9qzQTmPVrn3W79tcvkwqp2ROeUNPq8+hb4AV482LrjveTnOd/e/pw/2H3VdBM++GCc+cdry1gGfXbccehLyx+0f74fhNyJujbufEax+V4U2g8ajIG+gdYOl5w7ItnYvsNK/XD0y16sD3vJHTDzyZ02qyba4Xjtz4QVM/qQacOqM08W+crlMdmHnD+TefPwFvgJXjjf2yjH/TO2LD3ve2O/SsthvuNThI1NTIY8Pvw5Z+Fiigbjx+E+iQV2y/Y711xOsVOYd0eu1ln8K/AVaNN/69xlg7Ldyb0+tWqDuwI/1CX3X3Q5st9G+qbbsWcuDUD7jjs1o4fjPsn9pV+2W1fqbnDb9JE62eUfg3wKrxxnWsYn0TaZX20dBntNN3WtH8tHa/U2+fxJfs/ovwxv0Opd2HXb8e6JuTV1an61odT69v+G0NqBdOexP3FQR/gKXnTfNBT8cbriEHv+1BP9IqvWj2mePblPlON77WiyYOnA6DX23/1BkkHlHXkqw9deuM6I/7oAHeACvHm2w/gCLeNI+GXvTCDe20o8hvcV8lF4/CSMDD8JfHaG8Uv60TjvWIvGFM2gAt+hNu96abxgYAS80b/1HNxBsm7nIj7JfJj2ly+5bzNh6/Da3wlTT/wMojnz8EgBXhjW4/6fnB63qoTWAFeVN59PkCefP5kwpqE1hB3rAP6hWON82npVXFFLYtOK4PUZnA/HB/erzxHng8b+6PJ0zyx0lfBHA9N1zeWZvQ6kq+GwDmxJvmv58WbyqDYcybd2J9M85O84bxdmxWujGnbx/1j4Z9ZxTudzgZD4YDbLYGzNFOm6K+SSJqCW/ev/+smDg1O9yNzW0G+oZP92Q5fvjan8juqt3DHh7AHGnz7H5zerypRTuehXbaX84+fv/+d88KP7QXZSQ4csJtn+w0HU7Hi7N2BA6LNcFzuA+QZxmYG549++7+8aef/fw/TYc37INHzYg3HwW8eeerp88C5hjR6Hrhn/7wmec8ezZw47M9Z5Rc7w2elUbj0QfPAGBe+O7Z/W8/fBHy5t2p8MYN54g1vo30zd9/+9X9p09/Y4Rrx3+Gv7GCV04nPuvbnd/U3PCVZ3u/KQu36/4GAOaEp0/vf3X8zou/BLz59mfT4A178sdY33x29vGn/9D89t13vzKiZ0d/wt3anZd23frK6/kjv+30gv9eeCX+XQp/fPQVAMwL77777b/9h1//NeTNu9PhjfvAC+MCv/3iX118/Itf/OLPBaieRn9Oq98/7z7/fv/0z/9YPQ1+utXT56fPwyvd538uibP//uzPADA/BG3747N/dfefP5yOncYaX95g7KsPv/7ibOxeVW/i3dGq1ehVVTwbXSm9W1sVG60Bi8A/v39/Orxho8DDud9856MvPvvs4IuDjwrQ6yd/vJ5tec5efNa30+sd2/qoHFxn9BEAzBFB2/7ssy8+eqf5dEq8adz4snLrk/e//ujgIPxXgI7TCf/07X7faffr/tsxjZycDQflnqF248kBahKYK2+i1v31+5/cakyHN8zbHz273/zwnb//+tPf/vbTIrT96PfRp9bg0097vhud7A3Sy/3ep+Uw2vc+BYB5ImjaX//9Ox8e/6mkuhnPG/aHx81b97/69vj99z8shjdwkxdO8Mu2otc9J7nqD2oflkLt8csPAWDOeP/942+/ul9W3ZTgjef0G8/CEPfTP43BqB3/tWzPs9rD4JV3ZPfjc17f+lM59B3vTwAwZzwNByeflV4qM543rPfYbZSDW4n/9gfOwPGDF0170ItPeV7Zz7jXawDAgjBF3jTt+oRz+o+tjhW/pTnp9MyaM2hivhSw7CjBG1a594HMwyktjhnJn9P4/B6WeQLXgzfM6o5k280eXf27a74yR3q0b6FOgGvCG+bLqy/b8b7RSjZNKhwL2c/ki4wO61ZVUmMP/nD9RV4oI2bKekXkF4SZzyy/DISsr5RKWWANYlgiGZT7nlqUj5NTCwFtPNcbxxtdE+EOh6M4aXQuzGp1DXI+XY43Sssg+UH8kqwScZTnpkyz3evyyqDk19Se3OBcnF69x6y6H+5OKOkT4enlLkS427erI58997Oka5Q2nzypXfccg6KMMvmU5Q2J/4ZzqeJf2SWSXltF3mjUjZk3SyGDst/iOv0szuXZbpick3XfSncZpEKb4NMM8o2E36ajM6ReuF10pnAoa9pVSxEXJ5j0FSH5NSaeWR3e8EJjbJyBEvekJGszSQshmWCyVrOivJE2o9CLYZlkUPprRmlQrVK324nWcbuDnrjdk9CdqrxJtZdnNZwTrx6ca9dTkjU/ePxcERdRf2WiIYwX4ErxhkqEobIbaKorkj129C/vbMmKmWmX4c0yyaD89/hOTBfWGYS5oN2B7brdZl3mjbAVB697OXPNP2r3H+7b+84Zpd12crLt+NTsDhKlzOrvleENFVuI1uPRtpe82XAyIdyVa22nLZMMJvgeP80x0/C8wdAPA2p0ZFPvtMaottcQ9E3WVrzThuOx0z7tej37lHmxFqN/q/7ItDTjnb9rwptcRtzu2fkd/AEnBb5lENFeZakBs3rhNFMgSCeGJZLBJN8TaITk1a9s/0Xg47jd7sjffzhopTyhZt6k50dH3/f9I+bbJ32LHT1MBfNjrG24nogKPgzJvZkV5w1VLJJSvBF9YvGZiSifFYyn6dSNRgzLI4OJvsfPJg70bMfqndBTz3M82vYett346Sj/xJIwKPNG+16/Ru3eoN2vf+/bfnAQXWp+UPUZNShokrn+5BrwRpCRLp5GTYZa7hPzSxSTbpistJ02Tt8snwwm+x4/i6p5HrPd4/2ObTtvsd6+N2Cs9YqJvBEF49HaYPBW7ahr2ceW37P2mWUlI0DHtvM8b0TU7N+Q62OnUUP7oeYQLOEteMKPAq44bzRmm1YMSySDCb9n9CjfJmDgtau9gXVSp873tUFtaPdr+oHQmDY2ZXaFstppd+C4Ae+6eUN6cm9EGdPaadeNN0zaIjv1+wyTKjIpEI13RwR9TFYtHm9sKiYxLJMMJv0Wt57tS9PxR7TXZyftbpta+6593Pdcp99h1KJSJ/IweE/g0DD3qN+3To46rs0Gw5NUJl61bjF5eJQXFdEJSXdmdZoMZdzOjNSsfjIvL6svwo+Ryz3syvJGcoV1YlguGUz8Ld6XD3rZ1AHa7r3q+/aIVU+Dtt/u2afukDp+uIF6u1bzhx57GM7I6VecgDjPWW3Q61XDYZsBq1mJUBqjatUTHGWh3xHGPbMzxHBmxUJqaouhxiCsoHxXqp8ooI1AH8rKimEJZDD5t9f8/aGXmqWt7rDP6seefTqosXrPptb3Rz3W96g1sCyf2a1Xvs96wb8j5jqMnlLqnDjdh/1MJrXhvk8lx/mag/LhRiqMftE1EQNVvRxhe8vlF8NlWOvde+LyxwPW7vds5trtgCC27Qa8YS/tRtsLNBDze2HC9cAyY/Ua84bBqXC2QGb23bjnMgBYNVxK27Vsp/8iP2wP28e+y47aRy5rj+ot1vZGo36oZoYj1hkyq89aDgsZ5Nm9Ibci4UXfGbRQB8Ca8IY1e48ej4SFmW7fdWr9MDg9YMwJ9IoTkMS3fWa1WcOpBTqJ9YZWuANb9pZK77HTa6AKgLXhTWCrvdy3BQvLP+qwo1FgjznMskd+z+4HJAkUEAs1TTucxxayiGea/eAl9iIE1os3AXNu3LshtXvPtmvM9vyQHw6rWaGjE7k1/sCXchJo3g0Aa8Ab1hzZ3b6rZJ/xjtqB73Nkey3HbYczco4CfrwQ3+n29+0R8tYA68gbxhruk8ePXO2Ogp5VM+0hXRs9uvfIRdoaYF15E8UD9p2hV54Ex17feTB0oWuAteZNOA5648GTz0tRp+J9HtzrQ9UA4E1Ih3Z9v94feUVapOmN+k63PvSOIXRgnXkjTEj2/GoENyCPnK2n4bl/+OPjew+q5JxbMaH5cjKmWFxCDvGDtOdXYKq0PusXP4GRMJ28lCWwfNYFIp7LxMB9rPhlRHiZrQ3T1JRZwESsPFJG8mSylqjm3SA6meneqSn2AvUNYXlpgn9N4tvV/e5+fVDt+37Pd0nP96vDekyo89inIZpayuonqy1GpOcVS0sMTNMdKdwkZWVCSortEjMMifCYTOoDiKkB6ha8mnjD53ch8tJ7DVOYmNmCjPlKKWGKzBuhavOJuNqWLExvNjb3TGBEaC9ig9F9hywgrpUt0k6TWlDTdX1/8OWjJ/fuPa7ee/Toy+offNc919VvsthISExjbvOCpA3dTBnelO4GScmnvsRiKSIXkXvNNzQiTZLnacZPFc8+QlBQsgIg2mck4gHRaIFCwWtSCnGKgZhlStS2MFbQkuSUxEaqFaKTqk5fz5k3RJjVLyY7U3tQIuinbPFz8iP3IqZlFSRfNC19g3ie6Ns0MfbZE/DmahKUHpMxYWG81N75/jYXCzGZQmq/Kqws1vIm68qz7p/o1LgkeA19FePSzBs+JU2BYUe03abQXrgshFq7I+8S+GdcnL4RVw8xvn4M5hQRUioKKlRMj5ZLVOp9iUg1xYwgAg3z0hAynjfkUrS5hATlx2RiEYnUBJmcioJIwtfyRnovkRkgVEgqKMIIUU1DsZ6IpJVIoY7QG9oCAQkj5l6MaHLaCu2Fl6TCG6IrBplGwqjp+TeqJlSMJYn23Ht5LZF2KUxraovNSLmmXCayD5ISiRAlV6qmrIa2QvLskYRIDZ2/yn+p2D/mj8mrX03EQzJmNQ+n6esVaRAieTK5SuITYBKdSyW8y5TBTO/vEWMAROwFjWsPiWCCpUUgQt/BSdLkKcofuVD/hjC9mlCyXGn1jWpVC56shjd8RGRC3qilJkInplVHZt7oTHipPRHTBd4hIHoDRokeSLwpSurKBRtkO82gb8RP1+kb3r8RBKy1eHQ2p2kDAcFYNUXZZIEpvJGNPaINKuR2y8L1DeM7DSJ6KNrGSHK5KvpGZIxJ37CSdtoUeJOrJqk1qInwJfNDwxtm5o0Yc5LtGrUvJUWuNB+k476GyCYPYdIFwfkvZacRTdchqQ+TnaaGuYneQhbjZgJvCCvijdHwI8utb5gu6whRg1+cPcRK6RvCLhEXIKQkbwhTBiWIYeRAq2/0wxdqny9+qDElKRFcE6ItvuRN8C0s75j1ZNBcKOCNInhDZMpspxHD6J9A68IOircDVN6QMfGorF1ceRxnivomT3LNddYaIklBQ8Uh4uJtBtmXjEPrYhCJpyFoEWNJTRowcwyIFPnjgxCiZ0eybxbyj6odiXiaFCfyGetIq6EBjaMolonohpAM0WdyBd7kTUdvPOjeIaW61XllxBz3lsJQi+MNUVI0acfAdHFopovd8224UN+UGPck5RNtk8lj0KQgUFbmncJjyiTgzBftkLpuINEQh1asGU2cheuDiV4DGULkhOktHmM8jRREmFjx+A3nDohqWpSkiTeyql8GO00IpxHBWNYN2qj6Rm91EUFtafWN4pFK50kpO3ZiCZrfMOFHCfETnVlPtPOSVHkZeMN9MCEGZU2I+IXCTfLOGKrg9fpGX+OGUWwujlhmgJnonp/InbNSSs7ELDsPaIbjngCwlgBvAAC8AQDwBgDAGwAAbwAAvAEAALwBAPAGAMAbAABvAAC8AQAAvAEA8AYAwBsAAG8AALwBAAC8AQDwBgDAGwBYNfz/mG6yp4WGlFIAAAAASUVORK5CYII=</INVImage></Response>";

            // response = @"<Response><ResultCode>0</ResultCode><PatientID>0000000166</PatientID><PatientName>志明</PatientName><Sex>男</Sex><SexCode>1</SexCode><DOB>1985-06-09</DOB><TelephoneNo>mobile</TelephoneNo><Mobile>mobile</Mobile><Address>大城市铁岭</Address><IDTypeCode>1</IDTypeCode><IDNo>320721198708275413</IDNo><AccInfo>0^124^00000001660001^0^^0^^167^0000000166^147^P^^17^^0^124^00000001660001^0^^0^^167^0000000166^147^P^^17^</AccInfo><AccInfoBalance>3000</AccInfoBalance><AccInfoNo>124</AccInfoNo><PatientCard>320721198708275413</PatientCard><YBFlag>1</YBFlag><PatType>一般病人</PatType><PatTypeCode>一般病人</PatTypeCode></Response>"; 


            return response;
        }
        #endregion

        #region  //获取病人基本信息3300
        [WebMethod]
        public string GetPatInfo(string InValue)
        {
            String response = @"<Response><ResultCode>0</ResultCode><PatientID>0001147331</PatientID><PatientName>管春</PatientName><Sex>女</Sex><SexCode>2</SexCode><DOB>1972-02-06</DOB><TelephoneNo>18979156836</TelephoneNo><Mobile>18979156836</Mobile><IDTypeCode>1</IDTypeCode><IDNo>360102197202066326</IDNo><AccInfo>0^1133287^00011473310001^0^^0^^1148284^0001147331^1185720^P^^17^^0^1133287^00011473310001^0^^0^^1148284^0001147331^1185720^P^^17^</AccInfo><AccInfoBalance>300</AccInfoBalance><AccInfoNo>1133287</AccInfoNo><PatientCard>360102197202066326</PatientCard><YBFlag>1</YBFlag><PatType>省本级</PatType><PatTypeCode>省本级</PatTypeCode></Response>";

           // response = @"<Response><ResultCode>0</ResultCode><PatientID>0000000166</PatientID><PatientName>志明</PatientName><Sex>男</Sex><SexCode>1</SexCode><DOB>1985-06-09</DOB><TelephoneNo>mobile</TelephoneNo><Mobile>mobile</Mobile><Address>大城市铁岭</Address><IDTypeCode>1</IDTypeCode><IDNo>320721198708275413</IDNo><AccInfo>0^124^00000001660001^0^^0^^167^0000000166^147^P^^17^^0^124^00000001660001^0^^0^^167^0000000166^147^P^^17^</AccInfo><AccInfoBalance>3000</AccInfoBalance><AccInfoNo>124</AccInfoNo><PatientCard>320721198708275413</PatientCard><YBFlag>1</YBFlag><PatType>一般病人</PatType><PatTypeCode>一般病人</PatTypeCode></Response>"; 
           

            return response;
        }
        #endregion
        #region 门诊充值

        [WebMethod]
        public string AddOPDeposit(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>充值成功</ResultContent><DepositAmount>17.5</DepositAmount><InvoiceNo></InvoiceNo><RechargeTime>2017-07-29 17:05:15</RechargeTime></Response>";


            return response;
        }
        //院内账户预交金充值流水信息
         [WebMethod]
        public string GetOPAccPreDeposit(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><AccLists><Acclist><UserName>自助机001</UserName><Type>缴款</Type><PreDateTime>2017-05-08 15:10:44</PreDateTime><PayMode>现金</PayMode><PayAmt>1</PayAmt></Acclist><Acclist><UserName>自助机001</UserName><Type>缴款</Type><PreDateTime>2017-05-08 15:19:42</PreDateTime><PayMode>现金</PayMode><PayAmt>100</PayAmt></Acclist></AccLists></Response>";


            return response;
        }
        //院内账户预交金支付流水信息
         [WebMethod]
        public string GetAccPayList(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><AccPayLists><AccPayList><AccPLBillNo>ZZJ001000013764300001</AccPLBillNo><AccPLPayDateTime>2017-05-08 15:20:24</AccPLPayDateTime><AccPLPayRecLoc>耳鼻咽喉</AccPLPayRecLoc><PayNum>9</PayNum><UserName>自助机001</UserName></AccPayList><AccPayList><AccPLBillNo>ZZJ001000013764300002</AccPLBillNo><AccPLPayDateTime>2017-05-09 14:04:07</AccPLPayDateTime><AccPLPayRecLoc>电测听室</AccPLPayRecLoc><PayNum>9</PayNum><UserName>自助机001</UserName></AccPayList></AccPayLists></Response>";


            return response;
        }
        #endregion


         #region 缴费 4902 4903  4904  根据发票ID查询药品明细

         [WebMethod]
         public string GetAdmByCardNo(string InValue)
        {
            String response = "12354";
            /*
             <Request><TradeCode>4902</TradeCode><HospitalId>000</HospitalId><CardNo>511002196910011536</CardNo><CardTypeCode>0101</CardTypeCode><SecrityNo></SecrityNo><Userid>ZZJ001</Userid><StartDate>2017-12-29</StartDate><EndDate>2018-01-05</EndDate><AdmInfo></AdmInfo><PatAmt></PatAmt><BankTradeInfo></BankTradeInfo><ExpStr></ExpStr></Request>

             response = @"<Response><ResultCode>0</ResultCode><ResultContent>获取就诊记录成功</ResultContent><AdmItems><AdmItem><AdmRowid>44856</AdmRowid><AdmDate>2017-08-17</AdmDate><AdmLoc>甲状腺外科门诊</AdmLoc><AdmDoctor>余济春</AdmDoctor><AdmLocCode>10195</AdmLocCode><AdmDoctorCode>12022</AdmDoctorCode><AdmAmt>236.45</AdmAmt><AdmReasonCode>省本级</AdmReasonCode><AdmReasonDesc>省本级</AdmReasonDesc></AdmItem></AdmItems></Response>";
             */
            response = @"<Response><ResultCode>0</ResultCode><ResultContent>获取就诊记录成功</ResultContent><AdmItems><AdmItem><AdmRowid>734206</AdmRowid><AdmDate>2017-12-27</AdmDate><AdmLoc>内分泌代谢科门诊</AdmLoc><AdmDoctor>刘建萍</AdmDoctor><AdmLocCode>10138</AdmLocCode><AdmDoctorCode>14105</AdmDoctorCode><AdmAmt>254.47</AdmAmt><AdmReasonCode>大学生医保</AdmReasonCode><AdmReasonDesc>大学生医保</AdmReasonDesc></AdmItem><AdmItem><AdmRowid>734082</AdmRowid><AdmDate>2017-12-27</AdmDate><AdmLoc>心身医学科</AdmLoc><AdmDoctor>黄筱琴</AdmDoctor><AdmLocCode>10211</AdmLocCode><AdmDoctorCode>87007</AdmDoctorCode><AdmAmt>351</AdmAmt><AdmReasonCode>大学生医保</AdmReasonCode><AdmReasonDesc>大学生医保</AdmReasonDesc></AdmItem></AdmItems></Response>";
            response = @"<Response><ResultCode>0</ResultCode><ResultContent>获取就诊记录成功</ResultContent><AdmItems><AdmItem><AdmRowid>529506</AdmRowid><AdmDate>2018-01-05</AdmDate><AdmLoc>口腔科门诊</AdmLoc><AdmDoctor>甘洁</AdmDoctor><AdmLocCode>10173</AdmLocCode><AdmDoctorCode>83045</AdmDoctorCode><AdmAmt>2480</AdmAmt><AdmReasonCode>普通医保</AdmReasonCode><AdmReasonDesc>普通医保</AdmReasonDesc></AdmItem></AdmItems></Response>";

            return response;
        }
     
        //4903
        [WebMethod]
        public string GetBillInfo(string InValue)
         {
             #region
             String response = "";
            /*
             <Response><ResultCode>0</ResultCode><ResultContent>获取费用信息成功.</ResultContent><Err>0</Err><AdmReasonCount>1</AdmReasonCount><AdmReasons><AdmReason><GroupDR>216</GroupDR><InsuUserId>2628</InsuUserId><AdmSource>2</AdmSource><InsuTypeCode>NCA</InsuTypeCode><InsuTypeDesc>省本级</InsuTypeDesc><InsuTypeDR>6</InsuTypeDR><AmtSum>3412.36</AmtSum><TarOCCateItems><TarOCCateItem><TarOCCateDesc>西药</TarOCCateDesc><TarOCCateAmt>3208</TarOCCateAmt><OEOrdItems><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>左旋甲状腺素片(进口)[50ug*100片](优甲乐）</ArcmiDesc><Price>3208</Price><Qty>1</Qty><UOM>盒(100)</UOM><TotalAmount>3208</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount></OEOrdItem></OEOrdItems></TarOCCateItem><TarOCCateItem><TarOCCateDesc>处置治疗</TarOCCateDesc><TarOCCateAmt>4.36</TarOCCateAmt><OEOrdItems><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>一次性使用真空采血管(2ml)</ArcmiDesc><Price>.6825</Price><Qty>2</Qty><UOM>支</UOM><TotalAmount>1.36</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount></OEOrdItem><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>静脉采血</ArcmiDesc><Price>3</Price><Qty>1</Qty><UOM>次</UOM><TotalAmount>3</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount></OEOrdItem></OEOrdItems></TarOCCateItem><TarOCCateItem><TarOCCateDesc>检验</TarOCCateDesc><TarOCCateAmt>200</TarOCCateAmt><OEOrdItems><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>游离甲状腺激素(FT3,FT4,促甲)</ArcmiDesc><Price>150</Price><Qty>1</Qty><UOM>项</UOM><TotalAmount>150</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount></OEOrdItem><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>甲状腺球蛋白(TG)</ArcmiDesc><Price>50</Price><Qty>1</Qty><UOM>次</UOM><TotalAmount>50</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount></OEOrdItem></OEOrdItems></TarOCCateItem></TarOCCateItems></AdmReason></AdmReasons></Response>


             <Request><TradeCode>4903</TradeCode><HospitalId>000</HospitalId><CardNo>450422199703152882</CardNo><CardTypeCode>0101</CardTypeCode><SecrityNo></SecrityNo><Userid>ZZJ039</Userid><StartDate></StartDate><EndDate></EndDate><AdmInfo>734082</AdmInfo><ExpStr></ExpStr><PatAmt></PatAmt><BankTradeInfo></BankTradeInfo></Request>
             */
              response = @"<Response>
      <ResultCode>0</ResultCode>
      <ResultContent>获取费用信息成功.</ResultContent>
      <ChronicCodes>TSB0005^TSB0006</ChronicCodes>
      <Err>0</Err>
      <AdmReasonCount>1</AdmReasonCount>
      <AdmReasons>
        <AdmReason>
          <GroupDR>216</GroupDR>
          <InsuUserId>2528</InsuUserId>
          <AdmSource>1</AdmSource>
          <InsuTypeCode>NCB</InsuTypeCode>
          <InsuTypeDesc>普通医保</InsuTypeDesc>
          <InsuTypeDR>4</InsuTypeDR>
          <AmtSum>33.26</AmtSum>
          <TarOCCateItems>
            <TarOCCateItem>
              <TarOCCateDesc>西药</TarOCCateDesc>
              <TarOCCateAmt>.26</TarOCCateAmt>
              <OEOrdItems>
                <OEOrdItem>
                  <InsuType></InsuType>
                  <OEOrdId></OEOrdId>
                  <ArcmiDesc>0.9%氯化钠注射液(基)[10ml:90mg]</ArcmiDesc>
                  <Price>.26</Price>
                  <Qty>1</Qty>
                  <UOM>支</UOM>
                  <TotalAmount>.26</TotalAmount>
                  <PatientShareAmt>0</PatientShareAmt>
                  <DiscAmount>0</DiscAmount>
                  <ChronicCode>TSB0005</ChronicCode>
                </OEOrdItem>
                <OEOrdItem>
                  <InsuType></InsuType>
                  <OEOrdId></OEOrdId>
                  <ArcmiDesc>0.9%氯化钠注射液(基)[10ml:90mg]</ArcmiDesc>
                  <Price>1.26</Price>
                  <Qty>1</Qty>
                  <UOM>支</UOM>
                  <TotalAmount>1.26</TotalAmount>
                  <PatientShareAmt>0</PatientShareAmt>
                  <DiscAmount>0</DiscAmount>
                  <ChronicCode>TSB0006</ChronicCode>
                </OEOrdItem>
              </OEOrdItems>
            </TarOCCateItem>
            <TarOCCateItem>
              <TarOCCateDesc>检查</TarOCCateDesc>
              <TarOCCateAmt>25</TarOCCateAmt>
              <OEOrdItems>
                <OEOrdItem>
                  <InsuType></InsuType>
                  <OEOrdId></OEOrdId>
                  <ArcmiDesc>葡萄糖耐量试验</ArcmiDesc>
                  <Price>25</Price>
                  <Qty>1</Qty>
                  <UOM>每试验项目</UOM>
                  <TotalAmount>25</TotalAmount>
                  <PatientShareAmt>0</PatientShareAmt>
                  <DiscAmount>0</DiscAmount>
                  <ChronicCode>TSB0005</ChronicCode>
                </OEOrdItem>
              </OEOrdItems>
            </TarOCCateItem>
            <TarOCCateItem>
              <TarOCCateDesc>绑定治疗</TarOCCateDesc>
              <TarOCCateAmt>8</TarOCCateAmt>
              <OEOrdItems>
                <OEOrdItem>
                  <InsuType></InsuType>
                  <OEOrdId></OEOrdId>
                  <ArcmiDesc>静脉输液（绑定用法）</ArcmiDesc>
                  <Price>8</Price>
                  <Qty>1</Qty>
                  <UOM>组</UOM>
                  <TotalAmount>8</TotalAmount>
                  <PatientShareAmt>0</PatientShareAmt>
                  <DiscAmount>0</DiscAmount>
                  <ChronicCode></ChronicCode>
                </OEOrdItem>
              </OEOrdItems>
            </TarOCCateItem>
          </TarOCCateItems>
        </AdmReason>
      </AdmReasons>
    </Response>";
    
             #endregion
              /*   response = @"<Response><ResultCode>0</ResultCode><ResultContent>获取费用信息成功.</ResultContent><Err>0</Err><AdmReasonCount>1</AdmReasonCount><AdmReasons><AdmReason><GroupDR>216</GroupDR><InsuUserId>2647</InsuUserId><AdmSource>1</AdmSource><InsuTypeCode>NCB</InsuTypeCode><InsuTypeDesc>大学生医保</InsuTypeDesc><InsuTypeDR>3</InsuTypeDR><AmtSum>351</AmtSum><TarOCCateItems><TarOCCateItem><TarOCCateDesc>西药</TarOCCateDesc><TarOCCateAmt>351</TarOCCateAmt><OEOrdItems><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>草酸艾司西酞普兰片[10mg*10片]</ArcmiDesc><Price>58.5</Price><Qty>6</Qty><UOM>盒(10片)</UOM><TotalAmount>351</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount></OEOrdItem></OEOrdItems></TarOCCateItem></TarOCCateItems></AdmReason></AdmReasons></Response>";
            
              <Request><TradeCode>4903</TradeCode><HospitalId>000</HospitalId><CardNo>511002196910011536</CardNo><CardTypeCode>0101</CardTypeCode><SecrityNo></SecrityNo><Userid>ZZJ001</Userid><StartDate></StartDate><EndDate></EndDate><AdmInfo>529506</AdmInfo><ExpStr></ExpStr><PatAmt></PatAmt><BankTradeInfo></BankTradeInfo></Request>
              */
              /*  response = @"<Response><ResultCode>0</ResultCode><ResultContent>获取费用信息成功.</ResultContent><ChronicCodes>SCD0001^SCD0010</ChronicCodes><Err>0</Err><AdmReasonCount>1</AdmReasonCount><AdmReasons><AdmReason><GroupDR>216</GroupDR><InsuUserId>2528</InsuUserId><AdmSource>1</AdmSource><InsuTypeCode>NCB</InsuTypeCode><InsuTypeDesc>普通医保</InsuTypeDesc><InsuTypeDR>4</InsuTypeDR><AmtSum>2480</AmtSum><TarOCCateItems><TarOCCateItem><TarOCCateDesc>处置治疗</TarOCCateDesc><TarOCCateAmt>2480</TarOCCateAmt><OEOrdItems><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>复杂阻生牙拔除</ArcmiDesc><Price>390</Price><Qty>1</Qty><UOM>项</UOM><TotalAmount>390</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount><ChronicCode>SCD0001</ChronicCode></OEOrdItem><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>局部浸润麻醉</ArcmiDesc><Price>30</Price><Qty>1</Qty><UOM>次</UOM><TotalAmount>30</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount><ChronicCode>SCD0010</ChronicCode></OEOrdItem><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>水平位阻生牙拔除术</ArcmiDesc><Price>630</Price><Qty>1</Qty><UOM>项</UOM><TotalAmount>630</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount><ChronicCode>SCD0001</ChronicCode></OEOrdItem><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>近中位阻生牙拔除</ArcmiDesc><Price>430</Price><Qty>1</Qty><UOM>项</UOM><TotalAmount>430</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount><ChronicCode>SCD0001</ChronicCode></OEOrdItem><OEOrdItem><InsuType></InsuType><OEOrdId></OEOrdId><ArcmiDesc>高强度超声聚焦刀治疗</ArcmiDesc><Price>1000</Price><Qty>1</Qty><UOM>次</UOM><TotalAmount>1000</TotalAmount><PatientShareAmt>0</PatientShareAmt><DiscAmount>0</DiscAmount><ChronicCode>SCD0010</ChronicCode></OEOrdItem></OEOrdItems></TarOCCateItem></TarOCCateItems></AdmReason></AdmReasons></Response>";
               */
              return response;
     }
     //4904
     [WebMethod]
     public string AutoOPBillCharge(string InValue)
     {
         String response = @"<Response><ResultCode>0</ResultCode><ResultContent>结算成功</ResultContent>
 <Invoices><Invoice><InvoiceNO>1863</InvoiceNO><InvoiceAmt>3.11</InvoiceAmt><ConYBFlag>Y</ConYBFlag><YBHandle>0</YBHandle><YBUserId>2528</YBUserId><YBAdmSource>1</YBAdmSource><YBAdmReasonId>4</YBAdmReasonId><YBExpString>N^216^^^^^^^3.11^Y!2000^His</YBExpString><YBTypeCode>NCB</YBTypeCode><PrescWindow></PrescWindow></Invoice></Invoices></Response>";
         /*
          <Request><TradeCode>4904</TradeCode><HospitalId>000</HospitalId><CardNo>511002196910011536</CardNo><SecrityNo></SecrityNo><Userid>ZZJ001</Userid><StartDate></StartDate><EndDate></EndDate><PatAmt>2480.00</PatAmt><BankTradeInfo><![CDATA[<Response><TradeCode>4904</TradeCode><BankCode></BankCode><BankDate>2018-01-05 11:42:46</BankDate><BankTradeNo>114246204359</BankTradeNo><ResultCode>0000</ResultCode><ResultContent>交易成功</ResultContent><PayCardNo>6217002020064080153</PayCardNo><BankAccDate>2018-01-05 11:42:46</BankAccDate><RevTranFlag>0</RevTranFlag><PatientID>0000029557</PatientID><PayAmt>1</PayAmt><HISTradeNo></HISTradeNo><OrgHISTradeNo>4210499320180105000751</OrgHISTradeNo><OrgPaySeqNo></OrgPaySeqNo><FullPaymentFlag></FullPaymentFlag><Balance></Balance></Response>]]></BankTradeInfo><AdmInfo>529506</AdmInfo><InsuTypeDR>4</InsuTypeDR><PayModeCode>YHK</PayModeCode><TransactionId></TransactionId><InvoiceNO></InvoiceNO><YBChargeData></YBChargeData><ReceiptId></ReceiptId><PatientID>0000029557</PatientID><OriHisOrderNo></OriHisOrderNo><ExpStr>0101^^^</ExpStr><ChronicCodes>SCD0001</ChronicCodes><NewInsuType>1</NewInsuType></Request>
          */
            response = @"<Response><ResultCode>0</ResultCode><ResultContent>结算成功</ResultContent><Invoice><Invoice><TransactionId>01708170836001570</TransactionId><InvoiceNO>55275</InvoiceNO><InvoiceAmt>236.45</InvoiceAmt><ConYBFlag>Y</ConYBFlag><YBHandle>0</YBHandle><YBUserId>2628</YBUserId><YBAdmSource>2</YBAdmSource><YBAdmReasonId>6</YBAdmReasonId><YBExpString>N^216^^^^^^236.45^Y!0^His</YBExpString><YBTypeCode>NCA</YBTypeCode></Invoice></Invoice></Response>";
            response = @"<Response><ResultCode>0</ResultCode><ResultContent>结算成功</ResultContent><Invoice><Invoice><TransactionId>01801051905033551</TransactionId><InvoiceNO>983965</InvoiceNO><InvoiceAmt>2480.00</InvoiceAmt><ConYBFlag>N</ConYBFlag><YBHandle>0</YBHandle><YBUserId>2528</YBUserId><YBAdmReasonId>1</YBAdmReasonId></Invoice></Invoice></Response>";
            return response;
        }

        //医保确认
        [WebMethod]
        public string InserBankTradeInfoSingle(string InValue)
        {
            String response = @"<Response><ResultCode>0</ResultCode><ResultContent>0:HIS插入银行交易信息成功.</ResultContent></Response>";


            return response;
        }

        //根据发票ID查询药品明细
        [WebMethod]
        public string GetOPInvTarDetail(string InValue)
        {
            String response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><ChargeDate>2017-07-29 16:54:51</ChargeDate><AdmNo>1210</AdmNo><InvNo>002471</InvNo><UserName>付瑞琪</UserName><LocDesc>中医科门诊</LocDesc><DocName>资晓飞</DocName><PatName>万龙</PatName><TotalAmt>9.00</TotalAmt><SelfAmt></SelfAmt><TCAmt></TCAmt><ZHAmt></ZHAmt><PatType>普通医保</PatType><InvTarItemS><InvTarItem><PBDTotalAmount>1</PBDTotalAmount><PBDDiscAmount>0</PBDDiscAmount><PBDPayorShare>0</PBDPayorShare><PBDPatientShare>1</PBDPatientShare><PBDBillQty>1</PBDBillQty><PBDUnitPrice>1</PBDUnitPrice><TARICode>110100001</TARICode><TARIDesc>挂号费</TARIDesc><TARIUOM>139</TARIUOM><PHCDOfficialCode></PHCDOfficialCode></InvTarItem><InvTarItem><PBDTotalAmount>8</PBDTotalAmount><PBDDiscAmount>0</PBDDiscAmount><PBDPayorShare>0</PBDPayorShare><PBDPatientShare>8</PBDPatientShare><PBDBillQty>1</PBDBillQty><PBDUnitPrice>8</PBDUnitPrice><TARICode>110200002b</TARICode><TARIDesc>主任医师门诊诊查费</TARIDesc><TARIUOM>139</TARIUOM><PHCDOfficialCode></PHCDOfficialCode></InvTarItem><InvTarItem><PBDTotalAmount>.4</PBDTotalAmount><PBDDiscAmount>0</PBDDiscAmount><PBDPayorShare>0</PBDPayorShare><PBDPatientShare>.4</PBDPatientShare><PBDBillQty>1</PBDBillQty><PBDUnitPrice>.4</PBDUnitPrice><TARICode>149990221</TARICode><TARIDesc>一次性鼻塞</TARIDesc><TARIUOM>31</TARIUOM><PHCDOfficialCode></PHCDOfficialCode></InvTarItem><InvTarItem><PBDTotalAmount>.4</PBDTotalAmount><PBDDiscAmount>0</PBDDiscAmount><PBDPayorShare>0</PBDPayorShare><PBDPatientShare>.4</PBDPatientShare><PBDBillQty>1</PBDBillQty><PBDUnitPrice>.4</PBDUnitPrice><TARICode>149990221</TARICode><TARIDesc>一次性鼻塞</TARIDesc><TARIUOM>31</TARIUOM><PHCDOfficialCode></PHCDOfficialCode></InvTarItem></InvTarItemS></Response>";


            return response;
        }

        #endregion


        #region 已缴费记录查询 4905  4906

        [WebMethod]
        public string GetCompletedPayInfo(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><PayListInfos><PayListInfo><Adm>1064</Adm><AdmDate>2017-05-10</AdmDate><AdmDep>152</AdmDep><AdmDepName>ZYKMZ-中医科门诊</AdmDepName><DoctorId>57</DoctorId><DoctorName>谢庆斌</DoctorName><PayAmout>11.00</PayAmout><ReceiptId>1654</ReceiptId><ChargeDate>2017-05-10 14:35:08</ChargeDate></PayListInfo><PayListInfo><Adm>1064</Adm><AdmDate>2017-05-10</AdmDate><AdmDep>152</AdmDep><AdmDepName>ZYKMZ-中医科门诊</AdmDepName><DoctorId>57</DoctorId><DoctorName>谢庆斌</DoctorName><PayAmout>22.21</PayAmout><ReceiptId>1680</ReceiptId><ChargeDate>2017-05-10 21:36:13</ChargeDate><PrescWindow>西药房2号窗口,西药房2号窗口</PrescWindow></PayListInfo></PayListInfos></Response>";
            /*
         
             <PayListInfo><Adm>1121</Adm><AdmDate>2017-05-11</AdmDate><AdmDep>152</AdmDep><AdmDepName>ZYKMZ-中医科门诊</AdmDepName><DoctorId>1745</DoctorId><DoctorName>曹正柳</DoctorName><PayAmout>14.00</PayAmout><ReceiptId>1686</ReceiptId><ChargeDate>2017-05-11 09:14:57</ChargeDate></PayListInfo><PayListInfo><Adm>1123</Adm><AdmDate>2017-05-11</AdmDate><AdmDep>152</AdmDep><AdmDepName>ZYKMZ-中医科门诊</AdmDepName><DoctorId>1775</DoctorId><DoctorName>胡伟勇</DoctorName><PayAmout>14.00</PayAmout><ReceiptId>1687</ReceiptId><ChargeDate>2017-05-11 09:15:28</ChargeDate></PayListInfo><PayListInfo><Adm>1125</Adm><AdmDate>2017-05-11</AdmDate><AdmDep>152</AdmDep><AdmDepName>ZYKMZ-中医科门诊</AdmDepName><DoctorId>176</DoctorId><DoctorName>资晓飞</DoctorName><PayAmout>4.00</PayAmout><ReceiptId>1688</ReceiptId><ChargeDate>2017-05-11 09:15:59</ChargeDate></PayListInfo><PayListInfo><Adm>1151</Adm><AdmDate>2017-05-11</AdmDate><AdmDep>260</AdmDep><AdmDepName>BMMZ-便民门诊</AdmDepName><DoctorId>2517</DoctorId><DoctorName>便民号</DoctorName><PayAmout>1.00</PayAmout><ReceiptId>1705</ReceiptId><ChargeDate>2017-05-11 14:54:23</ChargeDate></PayListInfo><PayListInfo><Adm>1121</Adm><AdmDate>2017-05-11</AdmDate><AdmDep>152</AdmDep><AdmDepName>ZYKMZ-中医科门诊</AdmDepName><DoctorId>1745</DoctorId><DoctorName>曹正柳</DoctorName><PayAmout>19.51</PayAmout><ReceiptId>1706</ReceiptId><ChargeDate>2017-05-11 14:55:19</ChargeDate></PayListInfo><PayListInfo><Adm>1125</Adm><AdmDate>2017-05-11</AdmDate><AdmDep>152</AdmDep><AdmDepName>ZYKMZ-中医科门诊</AdmDepName><DoctorId>176</DoctorId><DoctorName>资晓飞</DoctorName><PayAmout>60.89</PayAmout><ReceiptId>1707</ReceiptId><ChargeDate>2017-05-11 14:56:12</ChargeDate></PayListInfo><PayListInfo><Adm>1211</Adm><AdmDate>2017-05-12</AdmDate><AdmDep>260</AdmDep><AdmDepName>BMMZ-便民门诊</AdmDepName><DoctorId>2517</DoctorId><DoctorName>便民号</DoctorName><PayAmout>1.00</PayAmout><ReceiptId>1750</ReceiptId><ChargeDate>2017-05-12 10:00:00</ChargeDate></PayListInfo><PayListInfo><Adm>1215</Adm><AdmDate>2017-05-12</AdmDate><AdmDep>199</AdmDep><AdmDepName>FCKMZ-妇产科门诊</AdmDepName><DoctorId>1997</DoctorId><DoctorName>刘虹</DoctorName><PayAmout>13.00</PayAmout><ReceiptId>1752</ReceiptId><ChargeDate>2017-05-12 10:21:23</ChargeDate></PayListInfo><PayListInfo><Adm>1225</Adm><AdmDate>2017-05-12</AdmDate><AdmDep>199</AdmDep><AdmDepName>FCKMZ-妇产科门诊</AdmDepName><DoctorId>1941</DoctorId><DoctorName>谭布珍</DoctorName><PayAmout>13.00</PayAmout><ReceiptId>1756</ReceiptId><ChargeDate>2017-05-12 11:15:14</ChargeDate></PayListInfo><PayListInfo><Adm>1123</Adm><AdmDate>2017-05-11</AdmDate><AdmDep>152</AdmDep><AdmDepName>ZYKMZ-中医科门诊</AdmDepName><DoctorId>1775</DoctorId><DoctorName>胡伟勇</DoctorName><PayAmout>7.10</PayAmout><ReceiptId>1758</ReceiptId><ChargeDate>2017-05-12 11:23:17</ChargeDate></PayListInfo><PayListInfo><Adm>1231</Adm><AdmDate>2017-05-12</AdmDate><AdmDep>170</AdmDep><AdmDepName>DCTS-电测听室</AdmDepName><DoctorId>1869</DoctorId><DoctorName>郭素英</DoctorName><PayAmout>9.00</PayAmout><ReceiptId>1762</ReceiptId><ChargeDate>2017-05-12 11:30:11</ChargeDate></PayListInfo><PayListInfo><Adm>1271</Adm><AdmDate>2017-05-12</AdmDate><AdmDep>169</AdmDep><AdmDepName>EBYHTJWKMZ-耳鼻咽喉-头颈外科门诊</AdmDepName><DoctorId>1793</DoctorId><DoctorName>张少容</DoctorName><PayAmout>9.00</PayAmout><ReceiptId>1791</ReceiptId><ChargeDate>2017-05-12 17:13:35</ChargeDate></PayListInfo>
             */

            return response;
        }

        [WebMethod]
        public string GetCompletedPayDetailInfo(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>获取费用信息成功.</ResultContent><OEOrdItems><OEOrdItem><InsuType> </InsuType><OEOrdId></OEOrdId><ArcmiDesc>挂号费</ArcmiDesc><Price>1.00</Price><Qty>1</Qty><UOM>次</UOM><TotalAmount>1</TotalAmount><PayorShareAmt> </PayorShareAmt><Unit>1</Unit></OEOrdItem><OEOrdItem><InsuType> </InsuType><OEOrdId></OEOrdId><ArcmiDesc>中医辨证论治(副主任中医师)</ArcmiDesc><Price>10.00</Price><Qty>1</Qty><UOM>次</UOM><TotalAmount>10</TotalAmount><PayorShareAmt> </PayorShareAmt><Unit>1</Unit></OEOrdItem></OEOrdItems></Response>";


            return response;
        }
        #endregion


        #region 药品 诊项查询
        [WebMethod]
        public string GetMedPrice(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><MedItemS><MedItem><SerialNo>1</SerialNo><ItemDesc>阿司匹林肠溶片</ItemDesc><ItemCode>100600004</ItemCode><PricesNo/><MedCate>西药口服拆分</MedCate><DrugForm>肠溶片</DrugForm><Uom>盒(60)</Uom><Price>2.3000</Price><Factory>南京白敬宇制药有限公司</Factory><Level/><ChargeStandard/><InsureSign/></MedItem><MedItem><SerialNo>2</SerialNo><ItemDesc>阿司匹林肠溶片</ItemDesc><ItemCode>100600004</ItemCode><PricesNo/><MedCate>西药口服拆分</MedCate><DrugForm>肠溶片</DrugForm><Uom>盒(60)</Uom><Price>2.3000</Price><Factory>南京白敬宇制药有限公司</Factory><Level/><ChargeStandard/><InsureSign/></MedItem></MedItemS></Response>";

            return response;
        }

        [WebMethod]
        public string GetTarItemPrice(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><TarItemS><TarItem><SerialNo>1</SerialNo><ItemDesc>雌酮测定(各种免疫学方法)</ItemDesc><ItemCode>250310034</ItemCode><PricesNo/><Uom>项</Uom><Price>20.00</Price><SpecialPrice>0.00</SpecialPrice><Factory/><ContentDesc/><ChargeStandard>250310034</ChargeStandard><InsureSign/><RegistrationNo/><RegExpDate/></TarItem><TarItem><SerialNo>2</SerialNo><ItemDesc>雌酮测定(化学发光法)</ItemDesc><ItemCode>250310034a</ItemCode><PricesNo/><Uom>项</Uom><Price>40.00</Price><SpecialPrice>0.00</SpecialPrice><Factory/><ContentDesc/><ChargeStandard>250310034a</ChargeStandard><InsureSign/><RegistrationNo/><RegExpDate/></TarItem></TarItemS></Response>";

            return response;
        }
        #endregion 药品 诊项查询


        #region 办卡 3013 3014

        [WebMethod]
        public string FindPatientCard(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>可以发卡</ResultContent><CardDepositAmt>0</CardDepositAmt></Response>";


            return response;
        }

        [WebMethod]
        public string SavePatientCard(string InValue)
        {
            String response = "12354";

            response = @"<Response><TradeCode></TradeCode><PatientCard>360423195802133712</PatientCard><SecurityNo></SecurityNo><PatientID>0001149617</PatientID><ResultCode>0</ResultCode><ResultContent>建卡成功</ResultContent><ActiveFlag></ActiveFlag><TransactionId></TransactionId><DepositAmount>0</DepositAmount></Response>";


            return response;
        }

        #endregion


        #region 预约1000  1005 2006  2001
        // 预约1000
        [WebMethod]
        public string BookService(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>预约成功</ResultContent><OrderCode>2221||5||5</OrderCode><SeqCode>谢庆斌</SeqCode><RegFee>11</RegFee><AdmitRange></AdmitRange><AdmitAddress>门诊楼二楼21、23、24诊室</AdmitAddress><OrderContent>320721198708275413^167^志明^男^2 号(白天)^2^ZYKMZ-中医科门诊^谢庆斌^2017-04-18^52944^2017-04-19^^</OrderContent><TransactionId></TransactionId></Response>";


            return response;
        }
        //QueryOrder -预约记录查询
        [WebMethod]
        public string QueryOrder(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordCount>1</RecordCount><Orders><Order><OrderCode>2222||3||2</OrderCode><OrderApptDate>2017-07-14</OrderApptDate><OrderStatus>normal</OrderStatus><OrderApptUser>徐业贵</OrderApptUser><PatientNo>0000000061</PatientNo><AdmitDate>2017-07-15</AdmitDate><DepartmentCode>152</DepartmentCode><Department>中医科门诊</Department><DoctorCode>176</DoctorCode><Doctor>资晓飞</Doctor><DoctorTitle>主任医生号</DoctorTitle><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><RegFee>9</RegFee><SeqCode>2</SeqCode><SessionName>下午</SessionName><AllowRefundFlag>Y</AllowRefundFlag><PayFlag>TB</PayFlag><HospitalName>南昌大学第二附属医院</HospitalName></Order></Orders></Response>";


            return response;
        }
        //CancelOrder -取消预约  
        [WebMethod]
        public string CancelOrder(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>取消成功</ResultContent></Response>";


            return response;
        }

        //OPAppArrive -预约取号  2001
        [WebMethod]
        public string OPAppArrive(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>取号成功</ResultContent><SeqCode>2</SeqCode><RegFee>  9.00元</RegFee><DeptName>中医科门诊</DeptName><DoctorName>资晓飞</DoctorName><DoctorLevelDesc>主任医生号</DoctorLevelDesc><TimeRange>下午</TimeRange><RegistrationID>366</RegistrationID></Response>";


            return response;
        }
        #endregion

       
        #region 获取病人住院就诊信息 GetIPPatAdmInfo

        [WebMethod]
        public string GetIPPatAdmInfo(string InValue)
        {
            ///*
            // <Response><ResultCode>0</ResultCode><ResultContent>获取就诊记录成功</ResultContent><PatientID>0001406168</PatientID><PatientName>朱胜美</PatientName><SexCode>1</SexCode><Sex>男</Sex><DOB>1977-06-26</DOB><MRID>0968289</MRID><Address>南昌市</Address><IDTypeCode>01</IDTypeCode><IDType>居民身份证</IDType><IDNo>362330197706263778</IDNo><PatType>一般病人</PatType><AdmID>809981</AdmID><AdmDate>2018-01-11</AdmDate><AdmLoc>DJBQ-东九病区</AdmLoc><DepositAmount>6705.17</DepositAmount><PrepayAmout>70000</PrepayAmout><Settled></Settled><TotalAmout>63294.83</TotalAmout><MedcareNo>0968289</MedcareNo><DiscChargeDate></DiscChargeDate><InDays>10</InDays><PatVisutus>在院</PatVisutus><HospitalId></HospitalId><DeptId>186</DeptId><BedNo></BedNo><ChargeDoctorId></ChargeDoctorId><ChargeDoctorName></ChargeDoctorName><ChargeNurseId></ChargeNurseId><ChargeNurseName></ChargeNurseName><ConnectPhone></ConnectPhone><RelatePerson></RelatePerson><Relation></Relation><RelatePhone></RelatePhone><Remark></Remark><DepName>GDWKEQ-肝胆外科二区</DepName><AdmLocId>50</AdmLocId></Response>

            // */

            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>获取就诊记录成功 </ResultContent><PatientID>0001050532</PatientID><PatientName>熊连香 </PatientName><SexCode>2</SexCode><Sex>女</Sex><DOB>1960-01- 15</DOB><MRID>0914272</MRID><Address>360121</Address><IDTypeCode>01</IDTypeCode><IDType>居民身份证 </IDType><IDNo>360121196001156928</IDNo><PatType>城镇居民医保 </PatType><AdmID>496444</AdmID><AdmDate>2017-11-10</AdmDate><AdmLoc>DSYBQ-东十一病区 </AdmLoc><DepositAmount>40883.32</DepositAmount><PrepayAmout>185000</PrepayAmout><Settled></Settled> <TotalAmout>144116.68</TotalAmout><MedcareNo>0914272</MedcareNo><DiscChargeDate></DiscChargeDate><InDays>15</InDays><PatVisutus>在院 </PatVisutus><HospitalId></HospitalId><DeptId>182</DeptId><BedNo></BedNo><ChargeDoctorId></ChargeDoctorId><ChargeDoctorName></ChargeDoctorName><ChargeNurseId></ChargeNurseId><ChargeNurseName></ChargeNurseName><ConnectPhone></ConnectPhone><RelatePerson></RelatePerson><Relation></Relation><RelatePhone ></RelatePhone><Remark></Remark><DepName>XZDXGWK-心脏大血管外科 </DepName><AdmLocId>52</AdmLocId></Response>";

            
            return response;
        }
        //住院结算
        [WebMethod]
        public string GetIPPatientInfo(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><PatientID>0001131702</PatientID><PatientName>刘宝石</PatientName><Sex>男</Sex><DOB>1989-03-31</DOB><MRID>0940667</MRID><Address>吉林省洮南市</Address><IDType>居民身份证</IDType><IDNo>2208811989****0536</IDNo><PatType>一般病人</PatType></Response>";


            return response;
        }
        #endregion

        #region 住院押金充值 没有传adm默认当前在院adm AddIPDeposit

        [WebMethod]
        public string AddIPDeposit(string InValue)
        {
            String response = @"<Request><TradeCode>80002</TradeCode><HospitalId>000</HospitalId><TerminalID>ZZJ001</TerminalID><ExtUserID>ZZJ001</ExtUserID><PatientCard>360103194908151744</PatientCard><CardTypeCode></CardTypeCode><PatientID>0001240564</PatientID><Adm>448834</Adm><Amount>2000.00</Amount><PayModeCode>YHK</PayModeCode><TransactionId></TransactionId><BankCode></BankCode><BankAccDate>20180105</BankAccDate><BankTransactionId>4210490020180104000299</BankTransactionId><BankCardNo>6216666500002357978</BankCardNo><BankRRN>101652200489</BankRRN><POSTradeInfo>006216666500002357978C000000200000         000299            2018010410165210165220048944842108062001142104900</POSTradeInfo></Request>";
            /*
             <Request><TradeCode>80002</TradeCode><HospitalId>000</HospitalId><TerminalID>ZZJ001</TerminalID><ExtUserID>ZZJ001</ExtUserID><PatientCard>360103194908151744</PatientCard><CardTypeCode></CardTypeCode><PatientID>0001240564</PatientID><Adm>448834</Adm><Amount>2000.00</Amount><PayModeCode>YHK</PayModeCode><TransactionId></TransactionId><BankCode></BankCode><BankAccDate>20180105</BankAccDate><BankTransactionId>4210490020180104000299</BankTransactionId><BankCardNo>6216666500002357978</BankCardNo><BankRRN>101652200489</BankRRN><POSTradeInfo>006216666500002357978C000000200000         000299            2018010410165210165220048944842108062001142104900</POSTradeInfo></Request>
             */
            response = @"<Response><ResultCode>0</ResultCode><ResultContent>交押金成功</ResultContent><DepositAmount>-394.58</DepositAmount></Response>";


            return response;
        }
        #endregion


        #region 住院押金充值查询 GetDepPayRecord
        [WebMethod]
        public string GetDepPayRecord(string InValue)
        {
            String response = "<Request><TradeCode></TradeCode><Adm>809981</Adm></Request>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordInfos><RecordInfo><PayTime>2018-01-11 22:55:47</PayTime><PayAmout>20000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo><RecordInfo><PayTime>2018-01-14 11:37:46</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo><RecordInfo><PayTime>2018-01-14 11:39:27</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo><RecordInfo><PayTime>2018-01-14 11:40:11</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo><RecordInfo><PayTime>2018-01-14 11:40:46</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo><RecordInfo><PayTime>2018-01-14 11:41:43</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo><RecordInfo><PayTime>2018-01-14 11:42:20</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo><RecordInfo><PayTime>2018-01-18 06:58:07</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo><RecordInfo><PayTime>2018-01-18 06:58:46</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo><RecordInfo><PayTime>2018-01-20 08:40:22</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo><RecordInfo><PayTime>2018-01-20 08:40:59</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>1</PayFlag><Remark> </Remark></RecordInfo></RecordInfos></Response>";


            return response;
        }
        [WebMethod]
        public string GetIPDepositRecord(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordInfoList><RecordInfo><PayTime>2017-08-2119:06:00</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>正常</PayFlag><Remark>已使用</Remark></RecordInfo><RecordInfo><PayTime>2017-08-2608:36:59</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>正常</PayFlag><Remark>已使用</Remark></RecordInfo><RecordInfo><PayTime>2017-08-2612:09:39</PayTime><PayAmout>30000</PayAmout><PayMode>银行卡</PayMode><PayFlag>正常</PayFlag><Remark>已使用</Remark></RecordInfo><RecordInfo><PayTime>2017-08-2914:45:41</PayTime><PayAmout>4760.69</PayAmout><PayMode>银行卡</PayMode><PayFlag>正常</PayFlag><Remark>已使用</Remark></RecordInfo></RecordInfoList></Response>";


            return response;
        }
        #endregion

        #region 住院日清单 GetIPDailyBill

        [WebMethod]
        public string GetIPDailyBill(string InValue)
        {
            String response = "12354";

            response = @"<Response>
	<ResultCode>0</ResultCode>
	<ErrorMsg>成功</ErrorMsg>
	<PatientID>0000000061</PatientID>
	<PatName>徐业贵</PatName>
	<PatAge>30岁</PatAge>
	<PatSex>男</PatSex>
	<AdmReason>一般病人</AdmReason>
	<Department>XWK-胸外科</Department>
	<Ward>综十病区</Ward>
	<BedNO>01</BedNO>
	<PatFee>1518.56</PatFee>
	<Deposit>500035.01</Deposit>
	<VisitStatus>A</VisitStatus>
	<PrintFlag>N</PrintFlag>
	<PrintTimes>0</PrintTimes>
	<TarItemList>
		<TarItemDetail>
			<Index>1</Index>
			<Category>诊查费</Category>
			<ItemName>住院诊查费</ItemName>
			<Qty>1</Qty>
			<UOM>日</UOM>
			<Price>7.0000</Price>
			<TotalAmt>7.00</TotalAmt>
			<DisAmt>0</DisAmt>
			<PayorAmt>0</PayorAmt>
			<PatShareAmt>0</PatShareAmt>
			<BillDate>2017-07-27</BillDate>
			<BillTime>00:05:00</BillTime>
			<InsuRatio/>
			<InsuClass/>
			<ItemChargeBasis>110200005</ItemChargeBasis>
		</TarItemDetail>
		<TarItemDetail>
			<Index>2</Index>
			<Category>取暖降温费</Category>
			<ItemName>病房空调降温费(中央空调)</ItemName>
			<Qty>1</Qty>
			<UOM>日</UOM>
			<Price>8.0000</Price>
			<TotalAmt>8.00</TotalAmt>
			<DisAmt>0</DisAmt>
			<PayorAmt>0</PayorAmt>
			<PatShareAmt>0</PatShareAmt>
			<BillDate>2017-07-27</BillDate>
			<BillTime>00:05:00</BillTime>
			<InsuRatio/>
			<InsuClass/>
			<ItemChargeBasis>110800001b</ItemChargeBasis>
		</TarItemDetail>
		<TarItemDetail>
			<Index>3</Index>
			<Category>床位费</Category>
			<ItemName>5人间及以上床位费</ItemName>
			<Qty>1</Qty>
			<UOM>日</UOM>
			<Price>18.0000</Price>
			<TotalAmt>18.00</TotalAmt>
			<DisAmt>0</DisAmt>
			<PayorAmt>0</PayorAmt>
			<PatShareAmt>0</PatShareAmt>
			<BillDate>2017-07-27</BillDate>
			<BillTime>00:05:00</BillTime>
			<InsuRatio/>
			<InsuClass/>
			<ItemChargeBasis>110900001y</ItemChargeBasis>
		</TarItemDetail>
	</TarItemList>
</Response>";


            return response;
        }
        #endregion

        #region 住院费用汇总查询 GetIPTotalCost

        [WebMethod]
        public string GetIPTotalCost(string InValue)
        {
            String response = @"<Request><TradeCode></TradeCode><AdmID>70364</AdmID></Request>";
            ////老的
            //response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><totalAmout>130654</totalAmout><prepayAmout>4181100</prepayAmout><unsettled>103104</unsettled><validPrepayAmout>0</validPrepayAmout><feeInfo><TarOCCateItem><TarOCCateDesc>诊查费</TarOCCateDesc><TarOCCateCode>诊查费</TarOCCateCode><TarOCCateAmt>18200</TarOCCateAmt></TarOCCateItem><TarOCCateItem><TarOCCateDesc>治疗费</TarOCCateDesc><TarOCCateCode>治疗费</TarOCCateCode><TarOCCateAmt>19200</TarOCCateAmt></TarOCCateItem><TarOCCateItem><TarOCCateDesc>检查费</TarOCCateDesc><TarOCCateCode>检查费</TarOCCateCode><TarOCCateAmt>8000</TarOCCateAmt></TarOCCateItem><TarOCCateItem><TarOCCateDesc>床位费</TarOCCateDesc><TarOCCateCode>床位费</TarOCCateCode><TarOCCateAmt>85250</TarOCCateAmt></TarOCCateItem><TarOCCateItem><TarOCCateDesc>西药费</TarOCCateDesc><TarOCCateCode>西药费</TarOCCateCode><TarOCCateAmt>4</TarOCCateAmt></TarOCCateItem></feeInfo></Response>";
            //新的
            /*
             入参:
	<Request><TradeCode></TradeCode><AdmID>70364</AdmID></Request>
             */
            response = @"<Response>
  <ResultCode>0</ResultCode>
  <ResultContent>成功</ResultContent>
  <TotalAmout>21866.49</TotalAmout>
  <PrepayAmout>5000</PrepayAmout>
  <ValidPrepayAmout>5000</ValidPrepayAmout>
  <Unsettled>21866.49</Unsettled>
  <FeeInfoList>
    <FeeInfo>
      <TypeCode> 诊查费</TypeCode>
      <TypeName>诊查费</TypeName>
      <TypeAmout>2862</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>治疗费</TypeCode>
      <TypeName>治疗费</TypeName>
      <TypeAmout>2552.08</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>检查费</TypeCode>
      <TypeName>检查费</TypeName>
      <TypeAmout>1430</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>
        取暖降温费
      </TypeCode>
      <TypeName>取暖降温费</TypeName>
      <TypeAmout>800</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>床位费</TypeCode>
      <TypeName>床位费</TypeName>
      <TypeAmout>6600</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>护理费</TypeCode>
      <TypeName>护理费</TypeName>
      <TypeAmout>3010.57</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>检验费</TypeCode>
      <TypeName> 检验费</TypeName>
      <TypeAmout>2728</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>材料费</TypeCode>
      <TypeName>材料费</TypeName>
      <TypeAmout>696.75</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>西药费</TypeCode>
      <TypeName>西药费</TypeName>
      <TypeAmout>635.09</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>中成药费</TypeCode>
      <TypeName>中成药费</TypeName>
      <TypeAmout>552</TypeAmout>
    </FeeInfo>
  </FeeInfoList>
</Response>";

            return response;
        }
        #endregion

        #region 住院费用分类明细 GetIPDetailCost

        [WebMethod]
        public string GetIPDetailCost(string InValue)
        {
            String response = "";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordCount>5</RecordCount><RecordInfoList><Record><DatailCat>诊查费</DatailCat><DetailId>110200005</DetailId><DetailName>住院诊查费</DetailName><DetailPrice>30</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>30</DetailAmout></Record><Record><DatailCat>取暖降温费</DatailCat><DetailId>110700001</DetailId><DetailName>病房取暖费(中央空调)</DetailName><DetailPrice>8</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>8</DetailAmout></Record><Record><DatailCat>取暖降温费</DatailCat><DetailId>110800001b</DetailId><DetailName>病房空调降温费(中央空调)</DetailName><DetailPrice>8</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>8</DetailAmout></Record><Record><DatailCat>床位费</DatailCat><DetailId>110900001c</DetailId><DetailName>双人间床位费</DetailName><DetailPrice>35</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>35</DetailAmout></Record><Record><DatailCat>床位费</DatailCat><DetailId>110900001p</DetailId><DetailName>两人间床位费(医疗中心大楼)</DetailName><DetailPrice>55</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>55</DetailAmout></Record></RecordInfoList></Response>";
            /*<Request><TradeCode></TradeCode><AdmID>70364</AdmID><BillDate></BillDate><Page>1</Page><Size>20</Size></Request>*/
           // response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordCount>180</RecordCount><RecordInfoList><Record><DatailCat>诊查费</DatailCat><DetailId>110200005</DetailId><DetailName>住院诊查费</DetailName><DetailPrice>7</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>7</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400001b</DetailId><DetailName>皮内注射（6岁以下儿童）</DetailName><DetailPrice>2</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>2</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400002</DetailId><DetailName>静脉注射</DetailName><DetailPrice>4</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>4</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400002a</DetailId><DetailName>静脉采血</DetailName><DetailPrice>3</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>3</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400006</DetailId><DetailName>静脉输液</DetailName><DetailPrice>5</DetailPrice><DetailCount>1</DetailCount><DetailUnit>组</DetailUnit><DetailAmout>5</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400006b</DetailId><DetailName>静脉注药</DetailName><DetailPrice>5</DetailPrice><DetailCount>1</DetailCount><DetailUnit>组</DetailUnit><DetailAmout>5</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400006c</DetailId><DetailName>静脉输液(从第二组起)</DetailName><DetailPrice>1</DetailPrice><DetailCount>1</DetailCount><DetailUnit>组</DetailUnit><DetailAmout>1</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400006f</DetailId><DetailName>使用微量泵或输液泵加收</DetailName><DetailPrice>1</DetailPrice><DetailCount>1</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>1</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400012</DetailId><DetailName>动脉穿刺置管术</DetailName><DetailPrice>50</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>50</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120600003</DetailId><DetailName>中换药</DetailName><DetailPrice>15</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>15</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120700001b</DetailId><DetailName>高压泵氧气雾化</DetailName><DetailPrice>8</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>8</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310607006</DetailId><DetailName>舱外高流量吸氧</DetailName><DetailPrice>5</DetailPrice><DetailCount>.46</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>2.3</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310701021</DetailId><DetailName>动态血压监测(24小时内)</DetailName><DetailPrice>5</DetailPrice><DetailCount>4.83</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>24.15</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310701021a</DetailId><DetailName>动态血压监测(24小时后)</DetailName><DetailPrice>3</DetailPrice><DetailCount>4.83</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>14.49</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310701022</DetailId><DetailName>心电监测(24小时内)</DetailName><DetailPrice>5</DetailPrice><DetailCount>1</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>5</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310701028</DetailId><DetailName>血氧饱和度监测</DetailName><DetailPrice>3</DetailPrice><DetailCount>4.83</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>14.49</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310702001a</DetailId><DetailName>有创性血流动力学监测(床旁)(心排血量测定)</DetailName><DetailPrice>100</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>100</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>320500001</DetailId><DetailName>冠状动脉造影术</DetailName><DetailPrice>1600</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>1600</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>320500002</DetailId><DetailName>经皮冠状动脉腔内成形术(PTCA)</DetailName><DetailPrice>2000</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>2000</DetailAmout></Record></RecordInfoList></Response>";
            return response;
        }
        #endregion

        #region 通过卡号获取住院有效就诊记录
        [WebMethod]
        public string GetIPAdmInfo(string InValue)
        {
            String response = "<Request><TradeCode></TradeCode><PatientCard>620101198001010491</PatientCard><ExtUserID>ZZJ001</ExtUserID><PatientID></PatientID><AimFlag>Dep</AimFlag></Request>";
            ////获取交押金就诊 Dep
            //response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><AdmInfoList><AdmInfo><AdmID>152049</AdmID><AdmDate>2017-10-20</AdmDate><AdmLoc>中医科</AdmLoc><AdmReason>跨省新农合</AdmReason><NationalCode>4</NationalCode><DepositAmount>5000.00</DepositAmount><TotalAmount>19209.18</TotalAmount><DepositBalance>-14209.18</DepositBalance></AdmInfo></AdmInfoList></Response>";
            //获取出院结算就诊 Pay
            response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><PatientID>0001131702</PatientID><PatientName>刘宝石</PatientName><Sex>男</Sex><DOB>1989-03-31</DOB><MRID>0940667</MRID><Address>吉林省洮南市</Address><IDType>居民身份证</IDType><IDNo>2208811989****0536</IDNo><PatType>一般病人</PatType><AdmInfoList><AdmInfo><AdmID>152087</AdmID><AdmDate>2017-12-19</AdmDate><InDays>1</InDays><AdmLoc>胸外科</AdmLoc><AdmLocId>180</AdmLocId><BQ>BSYBQ-北十一病区</BQ><BQID>9</BQID><BillNo>544509</BillNo><AdmReason>一般病人</AdmReason><DepositAmount>151.00</DepositAmount><TotalAmount>136.00</TotalAmount><DepositBalance>15.00</DepositBalance></AdmInfo></AdmInfoList></Response>";
            ////获取出院结算就诊 All
            //response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><AdmInfoList><AdmInfo><AdmID>134236</AdmID><AdmDate>2017-09-02</AdmDate><AdmLoc>肾脏内科</AdmLoc><AdmReason>普通医保</AdmReason><NationalCode>1</NationalCode><DepositAmount>0</DepositAmount><TotalAmount>21866.49</TotalAmount><DepositBalance>0</DepositBalance></AdmInfo><AdmInfo><AdmID>99946</AdmID><AdmDate>2017-08-27</AdmDate><AdmLoc>妇科</AdmLoc><AdmReason>普通医保</AdmReason><NationalCode>1</NationalCode><DepositAmount>0</DepositAmount><TotalAmount>3877.02</TotalAmount><DepositBalance>0</DepositBalance></AdmInfo></AdmInfoList></Response>";
            return response;
        }
        #endregion

        #region 出院费用核查
        [WebMethod]
        public string CheckBillFee(string InValue)
        {
            String response = @"<Request><TradeCode></TradeCode><PatientCard>220881198903310536</PatientCard><ExtUserID>ZZJ001</ExtUserID><PatientID></PatientID><AdmID>152087</AdmID><DepositAmount>151.00</DepositAmount><BillNo>544509</BillNo><TotalAmount>136.00</TotalAmount ><PatShare>136.00</PatShare><InsuShare></InsuShare></Request>";
            //
          //  response = @"<Response><ResultCode>0</ResultCode><ResultContent>费用核查成功</ResultContent><AdmID>152049</AdmID><BillNo>544161</BillNo><AdmReason>跨省新农合</AdmReason><NationalCode>4</NationalCode ><TotalAmount>19209.18</TotalAmount><PatShare>19209.18</PatShare ><InsuShare>0.00</InsuShare><DepositAmount>20000.00</DepositAmount><DepositBalance>790.82</DepositBalance ></Response>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>费用核查成功</ResultContent><AdmInfoList><AdmInfo><AdmID>152087</AdmID><AdmDate>2017-11-12</AdmDate><AdmLoc>胸外科</AdmLoc><BillNo>544509</BillNo><AdmReason>一般病人</AdmReason><DepositAmount>151.00</DepositAmount><TotalAmount>136.00</TotalAmount><DepositBalance>15.00</DepositBalance><PatShare>136.00</PatShare></AdmInfo></AdmInfoList></Response>";
            return response;
        }
        #endregion

        #region 出院结算
        [WebMethod]
        public string IPBillPay(string InValue)
        {
            String response = @"<Request><TradeCode></TradeCode><PatientCard>620101198001010491</PatientCard><ExtUserID>ZZJ001</ExtUserID><PatientID></PatientID><AdmID>152049</AdmID><DepositAmount>20000.00</DepositAmount><BillNo>544161</BillNo><TotalAmount>19209.18</TotalAmount><PatShare>19209.18</PatShare><InsuShare></InsuShare></Request>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>出院结算成功</ResultContent><AdmID>152049</AdmID><Invoice>9704</Invoice><PayModeCode>MISPOS</PayModeCode><PaidFlag>1</PaidFlag><Amount>790.82</Amount><BankCardList><BankCardInfo><BankCardNo>6228480928679846172</BankCardNo><BankCode>001</BankCode></BankCardInfo><BankCardInfo><BankCardNo>6217984240000164646</BankCardNo><BankCode>105</BankCode></BankCardInfo></BankCardList></Response>";


            return response;
        }
        #endregion

        #region 补退信息通知
        [WebMethod]
        public string PayResult(string InValue)
        {
            String response = @"<Request><TradeCode></TradeCode><PatientCard>620101198001010491</PatientCard><ExtUserID>ZZJ001</ExtUserID><PatientID></PatientID><AdmID>152049</AdmID><Invoice>9704</Invoice><PaidFlag>1</PaidFlag><Amount>790.82</Amount><PayModeCode>MISPOS</PayModeCode><BankCardNo>6217984240000164646</BankCardNo><POSTradeInfo>006217984240000164646R0000007908200001001   000046      0000012017121514360914360987184244842108062001142104982</POSTradeInfo></Request>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>通知成功</ResultContent></Response>";


            return response;
        }
        #endregion

        #region 电子病历

        [WebMethod]
        public string GetTodayPrintList(string InValue)
        {
            String response = "12354";

            response = "[{\"id\":\"2461||1\",\"ctloc\":\"基本外科门诊\",\"doc\":\"牛备战\",\"date\":\"2014-12-08 10:36:09\",\"status\":\"2014-12-08 17:38:49\"},{\"id\":\"2462||1\",\"ctloc\":\"基本外科门诊2\",\"doc\":\"牛备战2\",\"date\":\"2014-12-08 14:36:09\",\"status\":\"2014-12-09 19:38:49\"}]";


            return response;
        }
        public string GetSelfPrintParam(string InValue)
        {
            String response = "12354";

            response = @"csp/emr.record.browse.browsform.editor.csp?id=2461||1&chartItemType=Single&pluginType=DOC&Print=Y";


            return response;
        }
        #endregion

        #region 清钞对账  发票

        [WebMethod]
        public string AutoZZJDailyReport(string InValue)
        {
            String response = "<Request><Userid>ZZJ001</Userid><ExpStr>OP</ExpStr></Request>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>结账成功</ResultContent><PayModeStr>CASH^现金^16345|YHK^银行卡^2000</PayModeStr><HandReportNum>389|846</HandReportNum><HandDate>2017-05-24 14:16:18</HandDate><HandType>OP</HandType></Response>";


            return response;
        }

        public string GetPatAccList(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><PatientID>0000137877</PatientID><PapmiRowid>137879</PapmiRowid><PatName>熊承煌1</PatName><PatAge>32岁</PatAge><PatSex>女</PatSex><PatType/><AccMRowID>137797</AccMRowID><AccMOCDate/><AccMOCTime/><AccMBalance/><AccMDepPrice/><AccMAccStatus>N</AccMAccStatus><AccList><AccListDetail><Index>1</Index><PrtDate>1846-07-10</PrtDate><PrtTime>00:00:10</PrtTime><FairType>收费</FairType><FairTypeFlag>F</FairTypeFlag><Amt>800.00</Amt><User>cashier</User><BillNO/><Left/><LocDesc/><PLRowID>1811</PLRowID><PRTRowID>1811</PRTRowID><OrderDetails>人工肝治疗^800.00^1^中医科门诊</OrderDetails></AccListDetail></AccList></Response>";


            return response;
        }
        public string PrintInvoice(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><AccMRowID>124</AccMRowID><Invoices><Invoice><Index>1</Index><PrtDate>2017-05-19</PrtDate><PrtTime>19:00:14</PrtTime><FairType>收费</FairType><FairTypeFlag>F</FairTypeFlag><AdmReason>一般病人</AdmReason><PatientID>0000000166</PatientID><PatName>志明</PatName><AdmLocDesc>中医科门诊</AdmLocDesc><Amt>8.63</Amt><AmtDX> 捌元陆角叁分</AmtDX><UserName>自助机001</UserName><UserCode>ZZJ001</UserCode><InvNO>214401</InvNO><CateDetail>西药费^8.63</CateDetail><ItemDetail>维生素B1片^3.11^瓶(100)^1^3.11!氨茶碱缓释片^5.52^盒(24)^1^5.52</ItemDetail><DepDesc/><DocDesc/><SessionType/><TimeRange/><SeqNo/><RoomNo/><RoomFloor/><RegFee/><AppFee/><OtherFee/><ClinicGroupCode/><BoroughDesc/><PrnRegFee/><PrnCheckFee/><PrnReCheckFee/><PrnMRFee/><PrnCardFee/><AdmDate/><RegDate/><PayModeStr>统筹支付^30!个人账户^20!其它医保^30!个人支付^122</PayModeStr><PatSocialType>门诊特殊病</PatSocialType><PatSocialNo>11111112222222</PatSocialNo></Invoice></Invoices></Response>";


            return response;
        }
        #endregion


        #region 检验报告
        //检验报告
        [WebMethod]
        public string Print(string ob1, string obj2)
        {
            string response = @"<RetDto>
  <CanPrint>3</CanPrint>
  <NotAuth>0</NotAuth>
  <CName>黄舜松</CName>
  <Remark />
  <DetailList>
    <ReportDetail>
      <Location>急诊内科门诊</Location>
      <Ward />
      <Doctor>曹戍</Doctor>
      <Specimen>全血</Specimen>
      <TestSetDesc>急查血常规(五分类法）</TestSetDesc>
      <Remark />
      <RegNo>0001152008</RegNo>
      <VisitNumber>1708185999</VisitNumber>
      <ReceiveDate>2017-08-18</ReceiveDate>
      <ReceiveTime>22:37:12</ReceiveTime>
      <AcceptDate>2017-08-18</AcceptDate>
      <AcceptTime>22:37:33</AcceptTime>
      <EntryDate>2017-08-18</EntryDate>
      <EntryTime>23:11:39</EntryTime>
      <AuthDate>2017-08-18</AuthDate>
      <AuthTime>23:11:39</AuthTime>
      <Printed />
      <SelfPrinted>0</SelfPrinted>
      <StatusDesc>审核</StatusDesc>
    </ReportDetail>
    <ReportDetail>
      <Location>急诊内科门诊</Location>
      <Ward />
      <Doctor>曹戍</Doctor>
      <Specimen>血清</Specimen>
      <TestSetDesc>肾功能I+电解质I(血清)+肌酶谱</TestSetDesc>
      <Remark />
      <RegNo>0001152008</RegNo>
      <VisitNumber>1708186000</VisitNumber>
      <ReceiveDate>2017-08-18</ReceiveDate>
      <ReceiveTime>23:06:05</ReceiveTime>
      <AcceptDate>2017-08-18</AcceptDate>
      <AcceptTime>23:07:05</AcceptTime>
      <EntryDate>2017-08-18</EntryDate>
      <EntryTime>23:33:38</EntryTime>
      <AuthDate>2017-08-18</AuthDate>
      <AuthTime>23:33:38</AuthTime>
      <Printed />
      <SelfPrinted>0</SelfPrinted>
      <StatusDesc>审核</StatusDesc>
    </ReportDetail>
    <ReportDetail>
      <Location>急诊内科门诊</Location>
      <Ward />
      <Doctor>曹戍</Doctor>
      <Specimen>血浆</Specimen>
      <TestSetDesc>凝血四项+D-二聚体</TestSetDesc>
      <Remark />
      <RegNo>0001152008</RegNo>
      <VisitNumber>1708186001</VisitNumber>
      <ReceiveDate>2017-08-18</ReceiveDate>
      <ReceiveTime>23:42:43</ReceiveTime>
      <AcceptDate>2017-08-18</AcceptDate>
      <AcceptTime>23:43:29</AcceptTime>
      <EntryDate>2017-08-18</EntryDate>
      <EntryTime>23:53:48</EntryTime>
      <AuthDate>2017-08-18</AuthDate>
      <AuthTime>23:53:48</AuthTime>
      <Printed />
      <SelfPrinted>0</SelfPrinted>
      <StatusDesc>审核</StatusDesc>
    </ReportDetail>
  </DetailList>
</RetDto>";

            return response;
        }
        #endregion


        #region 病理报告
        //获取病理打印数据
        [WebMethod]
        public string GetRPTInfoByPatientNo(string InValue)
        {
            String response = "12354";

            response = @"<Response>
	<Reports>
		<Report>
			<ReportType>病理标本检查报告</ReportType>
			<ReportId>3682</ReportId>
			<ErrorMsg>查询成功</ErrorMsg>
			<PatientNo>0001159437</PatientNo>
			<VisitNo>73508</VisitNo>
			<PathologyNo>550556</PathologyNo>
			<Name>宋木水</Name>
			<Sex>男</Sex>
			<Age>60岁</Age>
			<BedNo>60</BedNo>
			<SpecimenTime>1840-12-31 00:00:00</SpecimenT ime>
			<SpecimenName>胸腔</SpecimenName>
			<CheckStatus>120</CheckStatus>
			<Hospitalizat  ionNo>0937457</HospitalizationNo>
			<Department>胸外科</Department>
			<Location>北十一病区</Location>
			<ApplicationDoctor>张小强</ApplicationDoctor>
			<See>胸腔肿瘤：灰白 灰红色不规则组织一堆，合计16×12×4.5CM，切面灰白灰红色，质软。</See>
			<Images>http://10.3.1.55:8080/pis3Data/2017-08-25/550556/550556_1_1.pdf</Images>
			<Imagedesc/>
			<Diagnosis>（胸腔）纤维组织增生伴玻璃样变，可见片状炎性肉芽组织，大量 炎性坏死及渗出物。
			</Diagnosis>
			<DiagnosisDoctor/>
			<DiagnosisTime>2017-08-29 08:28:56</DiagnosisTime>
			<Inputer/>
			<Rptprintflag>1</Rptprintflag>
			<Rptprint>2017-08-29 08:28:59</Rptprint>
			<AdmType>I</AdmType>
			<OrdName>手术标本检查与诊断</OrdName>
		</Report>
		<Report>
			<ReportType>病理检查补充报告</ReportType>
			<ReportId>4271</Rep  ortId>
			<ErrorMsg>查询成功</ErrorMsg>
			<PatientNo>0001159437</PatientNo>
			<VisitNo>73508</VisitNo>
			<PathologyNo>550556</PathologyNo>
			<Name>宋木水</Name>
			<Sex>男</Sex>
			<Age>60岁</Age>
			<BedNo>60</BedNo>
			<SpecimenTime>1840-12-31 00:00:00</SpecimenTime>
			<Sp ecimenName>胸腔</SpecimenName>
			<CheckStatus>120</CheckStatus>
			<HospitalizationNo>0  937457</HospitalizationNo>
			<Department>胸外科</Department>
			<Location>北十一病区</L  ocation>
			<ApplicationDoctor>张小强</ApplicationDoctor>
			<See>胸腔肿瘤：灰白灰红色不  规则组织一堆，合计16×12×4.5CM，切面灰白灰红色，质软。</See>
			<Images>http://10.3.1.55:8080/pis3Data/2017-08-25/550556/550556_3_2.pdf</Images>
			<Imagedesc/>
			<Diagnosis>特殊染色：抗酸(-)、PAS(-)、PASM(-)。
			</Diagnosis>
			<DiagnosisDoctor/>
			<DiagnosisTime>2017-08-30 16:06:55</DiagnosisTime>
			<Inputer/>
			<Rptprintflag>1</Rptprintflag>
			<Rptprint>2017-08-30 15:00:00</Rptprint>
			<AdmType>I</AdmType>
			<OrdName>手术标本检查与诊断</OrdName>
		</Report>
	</Reports>
</Response>";

            return response;
        }

        //第三方更新病理报告打印标志接口
        [WebMethod]
        public string UpdatePrintSignByRptId(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent></Response>";

            return response;
        }


        #endregion

        #region 挂号
        //1012
        [WebMethod]
        public string QueryDepartment(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><RecordCount>43</RecordCount><Departments><Department><DepartmentCode>260</DepartmentCode><DepartmentName>便民门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼一楼</DepartmentAddress></Department><Department><DepartmentCode>231</DepartmentCode><DepartmentName>磁共振室</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>综合大楼一楼</DepartmentAddress></Department><Department><DepartmentCode>170</DepartmentCode><DepartmentName>电测听室</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼四楼</DepartmentAddress></Department><Department><DepartmentCode>169</DepartmentCode><DepartmentName>耳鼻咽喉头颈外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼四楼</DepartmentAddress></Department><Department><DepartmentCode>156</DepartmentCode><DepartmentName>儿内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>179</DepartmentCode><DepartmentName>儿童眼科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼五楼</DepartmentAddress></Department><Department><DepartmentCode>199</DepartmentCode><DepartmentName>妇产科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>121</DepartmentCode><DepartmentName>风湿免疫科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>90</DepartmentCode><DepartmentName>干部保健门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>综合楼五楼</DepartmentAddress></Department><Department><DepartmentCode>187</DepartmentCode><DepartmentName>肝胆外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>167</DepartmentCode><DepartmentName>骨科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼康复医学科骨科病区</DepartmentAddress></Department><Department><DepartmentCode>159</DepartmentCode><DepartmentName>感染性疾病科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>住院大楼一楼</DepartmentAddress></Department><Department><DepartmentCode>116</DepartmentCode><DepartmentName>呼吸内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>194</DepartmentCode><DepartmentName>甲状腺外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼一楼</DepartmentAddress></Department><Department><DepartmentCode>209</DepartmentCode><DepartmentName>康复医学科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>173</DepartmentCode><DepartmentName>口腔科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼五楼</DepartmentAddress></Department><Department><DepartmentCode>261</DepartmentCode><DepartmentName>离退休专家门诊</DepartmentName><ParentId>-1</ParentId></Department><Department><DepartmentCode>165</DepartmentCode><DepartmentName>泌尿外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>203</DepartmentCode><DepartmentName>麻醉科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>综合楼三楼内腔镜左边第三间</DepartmentAddress></Department><Department><DepartmentCode>81</DepartmentCode><DepartmentName>门诊手术室</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>综合楼四楼</DepartmentAddress></Department><Department><DepartmentCode>138</DepartmentCode><DepartmentName>内分泌代谢科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>154</DepartmentCode><DepartmentName>皮肤科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼四楼</DepartmentAddress></Department><Department><DepartmentCode>270</DepartmentCode><DepartmentName>普外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>305</DepartmentCode><DepartmentName>全科医学科门诊</DepartmentName><ParentId>-1</ParentId></Department><Department><DepartmentCode>196</DepartmentCode><DepartmentName>乳腺外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>143</DepartmentCode><DepartmentName>神经内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>162</DepartmentCode><DepartmentName>神经外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>123</DepartmentCode><DepartmentName>肾脏内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>239</DepartmentCode><DepartmentName>体检中心</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>体检楼二楼</DepartmentAddress></Department><Department><DepartmentCode>150</DepartmentCode><DepartmentName>疼痛科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼一楼</DepartmentAddress></Department><Department><DepartmentCode>190</DepartmentCode><DepartmentName>胃肠外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>192</DepartmentCode><DepartmentName>血管外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>135</DepartmentCode><DepartmentName>消化内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>210</DepartmentCode><DepartmentName>心身医学科</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>181</DepartmentCode><DepartmentName>胸外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>128</DepartmentCode><DepartmentName>心血管内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>140</DepartmentCode><DepartmentName>血液内科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department><Department><DepartmentCode>183</DepartmentCode><DepartmentName>心脏大血管外科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>175</DepartmentCode><DepartmentName>眼科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼五楼</DepartmentAddress></Department><Department><DepartmentCode>177</DepartmentCode><DepartmentName>眼科准分子</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼四楼</DepartmentAddress></Department><Department><DepartmentCode>205</DepartmentCode><DepartmentName>医疗美容科</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>综合楼五楼</DepartmentAddress></Department><Department><DepartmentCode>147</DepartmentCode><DepartmentName>肿瘤科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼三楼</DepartmentAddress></Department><Department><DepartmentCode>152</DepartmentCode><DepartmentName>中医科门诊</DepartmentName><ParentId>-1</ParentId><DepartmentAddress>门诊楼二楼</DepartmentAddress></Department></Departments></Response>";

            return response;
        }

        //1004 排班查询
        [WebMethod]
        public string QueryAdmSchedule(string InValue)
        {
            String response = @"<Response><ResultCode>0</ResultCode><RecordCount>8</RecordCount><Schedules><Schedule><ScheduleItemCode>2141||29</ScheduleItemCode><ServiceDate>2017-08-18</ServiceDate><WeekDay>5</WeekDay><SessionCode>01</SessionCode><SessionName>上午</SessionName><StartTime>08:00</StartTime><EndTime>11:45</EndTime><DepartmentCode>138</DepartmentCode><DepartmentName>内分泌代谢科门诊</DepartmentName><DoctorCode>200</DoctorCode><DoctorName>杨雅</DoctorName><DoctorTitleCode>4</DoctorTitleCode><DoctorTitle>主任医生号</DoctorTitle><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><ServiceCode>122</ServiceCode><ServiceName>内分泌代谢科</ServiceName><Fee>9</Fee><RegFee>1</RegFee><CheckupFee>8</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>6,7,8,9,10,11,12,13,14,15,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,62,63,64,65,66,67,68,69,70,71,72,73,74,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>113</AvailableTotalNum><AvailableLeftNum>104</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>2141||41</ScheduleItemCode><ServiceDate>2017-08-18</ServiceDate><WeekDay>5</WeekDay><SessionCode>02</SessionCode><SessionName>下午</SessionName><StartTime>14:00</StartTime><EndTime>17:00</EndTime><DepartmentCode>138</DepartmentCode><DepartmentName>内分泌代谢科门诊</DepartmentName><DoctorCode>200</DoctorCode><DoctorName>杨雅</DoctorName><DoctorTitleCode>4</DoctorTitleCode><DoctorTitle>主任医生号</DoctorTitle><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><ServiceCode>122</ServiceCode><ServiceName>内分泌代谢科</ServiceName><Fee>9</Fee><RegFee>1</RegFee><CheckupFee>8</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>90</AvailableTotalNum><AvailableLeftNum>89</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>2149||29</ScheduleItemCode><ServiceDate>2017-08-18</ServiceDate><WeekDay>5</WeekDay><SessionCode>01</SessionCode><SessionName>上午</SessionName><StartTime>08:00</StartTime><EndTime>11:45</EndTime><DepartmentCode>138</DepartmentCode><DepartmentName>内分泌代谢科门诊</DepartmentName><DoctorCode>2065</DoctorCode><DoctorName>张美英</DoctorName><DoctorTitleCode>4</DoctorTitleCode><DoctorTitle>主任医生号</DoctorTitle><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><ServiceCode>122</ServiceCode><ServiceName>内分泌代谢科</ServiceName><Fee>9</Fee><RegFee>1</RegFee><CheckupFee>8</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>14,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>113</AvailableTotalNum><AvailableLeftNum>98</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>2149||41</ScheduleItemCode><ServiceDate>2017-08-18</ServiceDate><WeekDay>5</WeekDay><SessionCode>02</SessionCode><SessionName>下午</SessionName><StartTime>14:00</StartTime><EndTime>17:00</EndTime><DepartmentCode>138</DepartmentCode><DepartmentName>内分泌代谢科门诊</DepartmentName><DoctorCode>2065</DoctorCode><DoctorName>张美英</DoctorName><DoctorTitleCode>4</DoctorTitleCode><DoctorTitle>主任医生号</DoctorTitle><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><ServiceCode>122</ServiceCode><ServiceName>内分泌代谢科</ServiceName><Fee>9</Fee><RegFee>1</RegFee><CheckupFee>8</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,3,4,5,6,7,8,9,10,11,12,13,14,15,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>90</AvailableTotalNum><AvailableLeftNum>88</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>2151||30</ScheduleItemCode><ServiceDate>2017-08-18</ServiceDate><WeekDay>5</WeekDay><SessionCode>02</SessionCode><SessionName>下午</SessionName><StartTime>14:00</StartTime><EndTime>17:00</EndTime><DepartmentCode>138</DepartmentCode><DepartmentName>内分泌代谢科门诊</DepartmentName><DoctorCode>2286</DoctorCode><DoctorName>张笠</DoctorName><DoctorTitleCode>3</DoctorTitleCode><DoctorTitle>副主任医生号</DoctorTitle><DoctorSessTypeCode>3</DoctorSessTypeCode><DoctorSessType>副主任医生号</DoctorSessType><ServiceCode>122</ServiceCode><ServiceName>内分泌代谢科</ServiceName><Fee>7</Fee><RegFee>1</RegFee><CheckupFee>6</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>45</AvailableTotalNum><AvailableLeftNum>45</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>2151||5</ScheduleItemCode><ServiceDate>2017-08-18</ServiceDate><WeekDay>5</WeekDay><SessionCode>01</SessionCode><SessionName>上午</SessionName><StartTime>08:00</StartTime><EndTime>11:45</EndTime><DepartmentCode>138</DepartmentCode><DepartmentName>内分泌代谢科门诊</DepartmentName><DoctorCode>2286</DoctorCode><DoctorName>张笠</DoctorName><DoctorTitleCode>3</DoctorTitleCode><DoctorTitle>副主任医生号</DoctorTitle><DoctorSessTypeCode>3</DoctorSessTypeCode><DoctorSessType>副主任医生号</DoctorSessType><ServiceCode>122</ServiceCode><ServiceName>内分泌代谢科</ServiceName><Fee>7</Fee><RegFee>1</RegFee><CheckupFee>6</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>57</AvailableTotalNum><AvailableLeftNum>56</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>2622||135</ScheduleItemCode><ServiceDate>2017-08-18</ServiceDate><WeekDay>5</WeekDay><SessionCode>01</SessionCode><SessionName>上午</SessionName><StartTime>08:00</StartTime><EndTime>11:45</EndTime><DepartmentCode>138</DepartmentCode><DepartmentName>内分泌代谢科门诊</DepartmentName><DoctorCode>2502</DoctorCode><DoctorName>普通号</DoctorName><DoctorTitleCode>2</DoctorTitleCode><DoctorTitle>普通号</DoctorTitle><DoctorSessTypeCode>2</DoctorSessTypeCode><DoctorSessType>普通号</DoctorSessType><Fee>4</Fee><RegFee>1</RegFee><CheckupFee>3</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>225</AvailableTotalNum><AvailableLeftNum>223</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>2622||147</ScheduleItemCode><ServiceDate>2017-08-18</ServiceDate><WeekDay>5</WeekDay><SessionCode>02</SessionCode><SessionName>下午</SessionName><StartTime>14:00</StartTime><EndTime>17:00</EndTime><DepartmentCode>138</DepartmentCode><DepartmentName>内分泌代谢科门诊</DepartmentName><DoctorCode>2502</DoctorCode><DoctorName>普通号</DoctorName><DoctorTitleCode>2</DoctorTitleCode><DoctorTitle>普通号</DoctorTitle><DoctorSessTypeCode>2</DoctorSessTypeCode><DoctorSessType>普通号</DoctorSessType><Fee>4</Fee><RegFee>1</RegFee><CheckupFee>3</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180</AvailableNumStr><AdmitAddress>门诊楼二楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>180</AvailableTotalNum><AvailableLeftNum>180</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule></Schedules></Response>";
            //response = @"<Response><ResultCode>0</ResultCode><RecordCount>4</RecordCount><Schedules><Schedule><ScheduleItemCode>2561||1</ScheduleItemCode><ServiceDate>2017-09-16</ServiceDate><WeekDay>6</WeekDay><SessionCode>01</SessionCode><SessionName>上午</SessionName><StartTime>08:00</StartTime><EndTime>11:45</EndTime><DepartmentCode>209</DepartmentCode><DepartmentName>康复医学科门诊</DepartmentName><DoctorCode>1130</DoctorCode><DoctorName>朱怡文</DoctorName><DoctorTitleCode>2</DoctorTitleCode><DoctorTitle>普通号</DoctorTitle><DoctorSessTypeCode>2</DoctorSessTypeCode><DoctorSessType>普通号</DoctorSessType><Fee>16</Fee><RegFee>0</RegFee><CheckupFee>16</CheckupFee><OtherFee>0</OtherFee><AdmitAddress>门诊楼三楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><TimeRangeFlag>0</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>2561||2</ScheduleItemCode><ServiceDate>2017-09-16</ServiceDate><WeekDay>6</WeekDay><SessionCode>02</SessionCode><SessionName>下午</SessionName><StartTime>14:00</StartTime><EndTime>17:15</EndTime><DepartmentCode>209</DepartmentCode><DepartmentName>康复医学科门诊</DepartmentName><DoctorCode>1130</DoctorCode><DoctorName>朱怡文</DoctorName><DoctorTitleCode>2</DoctorTitleCode><DoctorTitle>普通号</DoctorTitle><DoctorSessTypeCode>2</DoctorSessTypeCode><DoctorSessType>普通号</DoctorSessType><Fee>16</Fee><RegFee>0</RegFee><CheckupFee>16</CheckupFee><OtherFee>0</OtherFee><AdmitAddress>门诊楼三楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><TimeRangeFlag>0</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>2610||81</ScheduleItemCode><ServiceDate>2017-09-16</ServiceDate><WeekDay>6</WeekDay><SessionCode>01</SessionCode><SessionName>上午</SessionName><StartTime>08:01</StartTime><EndTime>12:00</EndTime><DepartmentCode>209</DepartmentCode><DepartmentName>康复医学科门诊</DepartmentName><DoctorCode>2502</DoctorCode><DoctorName>普通号</DoctorName><DoctorTitleCode>2</DoctorTitleCode><DoctorTitle>普通号</DoctorTitle><DoctorSessTypeCode>2</DoctorSessTypeCode><DoctorSessType>普通号</DoctorSessType><Fee>16</Fee><RegFee>0</RegFee><CheckupFee>16</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75</AvailableNumStr><AdmitAddress>门诊楼三楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>75</AvailableTotalNum><AvailableLeftNum>75</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule><Schedule><ScheduleItemCode>2610||82</ScheduleItemCode><ServiceDate>2017-09-16</ServiceDate><WeekDay>6</WeekDay><SessionCode>02</SessionCode><SessionName>下午</SessionName><StartTime>14:00</StartTime><EndTime>17:00</EndTime><DepartmentCode>209</DepartmentCode><DepartmentName>康复医学科门诊</DepartmentName><DoctorCode>2502</DoctorCode><DoctorName>普通号</DoctorName><DoctorTitleCode>2</DoctorTitleCode><DoctorTitle>普通号</DoctorTitle><DoctorSessTypeCode>2</DoctorSessTypeCode><DoctorSessType>普通号</DoctorSessType><Fee>16</Fee><RegFee>0</RegFee><CheckupFee>16</CheckupFee><OtherFee>0</OtherFee><AvailableNumStr>1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60</AvailableNumStr><AdmitAddress>门诊楼三楼</AdmitAddress><ScheduleStatus>1</ScheduleStatus><AvailableTotalNum>60</AvailableTotalNum><AvailableLeftNum>60</AvailableLeftNum><TimeRangeFlag>1</TimeRangeFlag></Schedule></Schedules></Response>";
            response = @"<Response>
  <ResultCode>0</ResultCode>
  <RecordCount>8</RecordCount>
  <Schedules>
    <Schedule>
      <ScheduleItemCode>2141||29</ScheduleItemCode>
      <ServiceDate>2017-08-18</ServiceDate>
      <WeekDay>5</WeekDay>
      <SessionCode>01</SessionCode>
      <SessionName>上午</SessionName>
      <StartTime>08:00</StartTime>
      <EndTime>11:45</EndTime>
      <DepartmentCode>138</DepartmentCode>
      <DepartmentName>内分泌代谢科门诊</DepartmentName>
      <DoctorCode>200</DoctorCode>
      <DoctorName>杨雅</DoctorName>
      <DoctorTitleCode>4</DoctorTitleCode>
      <DoctorTitle>主任医生号</DoctorTitle>
      <DoctorSessTypeCode>4</DoctorSessTypeCode>
      <DoctorSessType>主任医生号</DoctorSessType>
      <ServiceCode>122</ServiceCode>
      <ServiceName>内分泌代谢科</ServiceName>
      <Fee>9</Fee>
      <RegFee>1</RegFee>
      <CheckupFee>8</CheckupFee>
      <OtherFee>0</OtherFee>
      <AvailableNumStr>6,7,8,9,10,11,12,13,14,15,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,62,63,64,65,66,67,68,69,70,71,72,73,74,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113</AvailableNumStr>
      <AdmitAddress>门诊楼二楼</AdmitAddress>
      <ScheduleStatus>1</ScheduleStatus>
<AvailableNum>113</AvailableNum>
      <AvailableTotalNum>113</AvailableTotalNum>
      <AvailableLeftNum>104</AvailableLeftNum>
      <TimeRangeFlag>1</TimeRangeFlag>
    </Schedule>
    <Schedule>
      <ScheduleItemCode>2141||41</ScheduleItemCode>
      <ServiceDate>2017-08-18</ServiceDate>
      <WeekDay>5</WeekDay>
      <SessionCode>02</SessionCode>
      <SessionName>下午</SessionName>
      <StartTime>14:00</StartTime>
      <EndTime>17:00</EndTime>
      <DepartmentCode>138</DepartmentCode>
      <DepartmentName>内分泌代谢科门诊</DepartmentName>
      <DoctorCode>200</DoctorCode>
      <DoctorName>杨雅</DoctorName>
      <DoctorTitleCode>4</DoctorTitleCode>
      <DoctorTitle>主任医生号</DoctorTitle>
      <DoctorSessTypeCode>4</DoctorSessTypeCode>
      <DoctorSessType>主任医生号</DoctorSessType>
      <ServiceCode>122</ServiceCode>
      <ServiceName>内分泌代谢科</ServiceName>
      <Fee>9</Fee>
      <RegFee>1</RegFee>
      <CheckupFee>8</CheckupFee>
      <OtherFee>0</OtherFee>
      <AvailableNumStr>1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90</AvailableNumStr>
      <AdmitAddress>门诊楼二楼</AdmitAddress>
      <ScheduleStatus>1</ScheduleStatus>
<AvailableNum>113</AvailableNum>
      <AvailableTotalNum>90</AvailableTotalNum>
      <AvailableLeftNum>89</AvailableLeftNum>
      <TimeRangeFlag>1</TimeRangeFlag>
    </Schedule>
    <Schedule>
      <ScheduleItemCode>2149||29</ScheduleItemCode>
      <ServiceDate>2017-08-18</ServiceDate>
      <WeekDay>5</WeekDay>
      <SessionCode>01</SessionCode>
      <SessionName>上午</SessionName>
      <StartTime>08:00</StartTime>
      <EndTime>11:45</EndTime>
      <DepartmentCode>138</DepartmentCode>
      <DepartmentName>内分泌代谢科门诊</DepartmentName>
      <DoctorCode>2065</DoctorCode>
      <DoctorName>张美英</DoctorName>
      <DoctorTitleCode>4</DoctorTitleCode>
      <DoctorTitle>主任医生号</DoctorTitle>
      <DoctorSessTypeCode>4</DoctorSessTypeCode>
      <DoctorSessType>主任医生号</DoctorSessType>
      <ServiceCode>122</ServiceCode>
      <ServiceName>内分泌代谢科</ServiceName>
      <Fee>9</Fee>
      <RegFee>1</RegFee>
      <CheckupFee>8</CheckupFee>
      <OtherFee>0</OtherFee>
      <AvailableNumStr>14,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113</AvailableNumStr>
      <AdmitAddress>门诊楼二楼</AdmitAddress>
      <ScheduleStatus>1</ScheduleStatus>
<AvailableNum>113</AvailableNum>
      <AvailableTotalNum>113</AvailableTotalNum>
      <AvailableLeftNum>98</AvailableLeftNum>
      <TimeRangeFlag>1</TimeRangeFlag>
    </Schedule>
    <Schedule>
      <ScheduleItemCode>2149||41</ScheduleItemCode>
      <ServiceDate>2017-08-18</ServiceDate>
      <WeekDay>5</WeekDay>
      <SessionCode>02</SessionCode>
      <SessionName>下午</SessionName>
      <StartTime>14:00</StartTime>
      <EndTime>17:00</EndTime>
      <DepartmentCode>138</DepartmentCode>
      <DepartmentName>内分泌代谢科门诊</DepartmentName>
      <DoctorCode>2065</DoctorCode>
      <DoctorName>张美英</DoctorName>
      <DoctorTitleCode>4</DoctorTitleCode>
      <DoctorTitle>主任医生号</DoctorTitle>
      <DoctorSessTypeCode>4</DoctorSessTypeCode>
      <DoctorSessType>主任医生号</DoctorSessType>
      <ServiceCode>122</ServiceCode>
      <ServiceName>内分泌代谢科</ServiceName>
      <Fee>9</Fee>
      <RegFee>1</RegFee>
      <CheckupFee>8</CheckupFee>
      <OtherFee>0</OtherFee>
      <AvailableNumStr>1,3,4,5,6,7,8,9,10,11,12,13,14,15,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90</AvailableNumStr>
      <AdmitAddress>门诊楼二楼</AdmitAddress>
      <ScheduleStatus>1</ScheduleStatus>
<AvailableNum>90</AvailableNum>
      <AvailableTotalNum>90</AvailableTotalNum>
      <AvailableLeftNum>88</AvailableLeftNum>
      <TimeRangeFlag>1</TimeRangeFlag>
    </Schedule>
    <Schedule>
      <ScheduleItemCode>2151||30</ScheduleItemCode>
      <ServiceDate>2017-08-18</ServiceDate>
      <WeekDay>5</WeekDay>
      <SessionCode>02</SessionCode>
      <SessionName>下午</SessionName>
      <StartTime>14:00</StartTime>
      <EndTime>17:00</EndTime>
      <DepartmentCode>138</DepartmentCode>
      <DepartmentName>内分泌代谢科门诊</DepartmentName>
      <DoctorCode>2286</DoctorCode>
      <DoctorName>张笠</DoctorName>
      <DoctorTitleCode>3</DoctorTitleCode>
      <DoctorTitle>副主任医生号</DoctorTitle>
      <DoctorSessTypeCode>3</DoctorSessTypeCode>
      <DoctorSessType>副主任医生号</DoctorSessType>
      <ServiceCode>122</ServiceCode>
      <ServiceName>内分泌代谢科</ServiceName>
      <Fee>7</Fee>
      <RegFee>1</RegFee>
      <CheckupFee>6</CheckupFee>
      <OtherFee>0</OtherFee>
      <AvailableNumStr>1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45</AvailableNumStr>
      <AdmitAddress>门诊楼二楼</AdmitAddress>
      <ScheduleStatus>1</ScheduleStatus>
<AvailableNum>45</AvailableNum>
      <AvailableTotalNum>45</AvailableTotalNum>
      <AvailableLeftNum>45</AvailableLeftNum>
      <TimeRangeFlag>1</TimeRangeFlag>
    </Schedule>
    <Schedule>
      <ScheduleItemCode>2151||5</ScheduleItemCode>
      <ServiceDate>2017-08-18</ServiceDate>
      <WeekDay>5</WeekDay>
      <SessionCode>01</SessionCode>
      <SessionName>上午</SessionName>
      <StartTime>08:00</StartTime>
      <EndTime>11:45</EndTime>
      <DepartmentCode>138</DepartmentCode>
      <DepartmentName>内分泌代谢科门诊</DepartmentName>
      <DoctorCode>2286</DoctorCode>
      <DoctorName>张笠</DoctorName>
      <DoctorTitleCode>3</DoctorTitleCode>
      <DoctorTitle>副主任医生号</DoctorTitle>
      <DoctorSessTypeCode>3</DoctorSessTypeCode>
      <DoctorSessType>副主任医生号</DoctorSessType>
      <ServiceCode>122</ServiceCode>
      <ServiceName>内分泌代谢科</ServiceName>
      <Fee>7</Fee>
      <RegFee>1</RegFee>
      <CheckupFee>6</CheckupFee>
      <OtherFee>0</OtherFee>
      <AvailableNumStr>1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57</AvailableNumStr>
      <AdmitAddress>门诊楼二楼</AdmitAddress>
      <ScheduleStatus>1</ScheduleStatus>
<AvailableNum>57</AvailableNum>
      <AvailableTotalNum>57</AvailableTotalNum>
      <AvailableLeftNum>56</AvailableLeftNum>
      <TimeRangeFlag>1</TimeRangeFlag>
    </Schedule>
    <Schedule>
      <ScheduleItemCode>2622||135</ScheduleItemCode>
      <ServiceDate>2017-08-18</ServiceDate>
      <WeekDay>5</WeekDay>
      <SessionCode>01</SessionCode>
      <SessionName>上午</SessionName>
      <StartTime>08:00</StartTime>
      <EndTime>11:45</EndTime>
      <DepartmentCode>138</DepartmentCode>
      <DepartmentName>内分泌代谢科门诊</DepartmentName>
      <DoctorCode>2502</DoctorCode>
      <DoctorName>普通号</DoctorName>
      <DoctorTitleCode>2</DoctorTitleCode>
      <DoctorTitle>普通号</DoctorTitle>
      <DoctorSessTypeCode>2</DoctorSessTypeCode>
      <DoctorSessType>普通号</DoctorSessType>
      <Fee>4</Fee>
      <RegFee>1</RegFee>
      <CheckupFee>3</CheckupFee>
      <OtherFee>0</OtherFee>
      <AvailableNumStr>2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225</AvailableNumStr>
      <AdmitAddress>门诊楼二楼</AdmitAddress>
      <ScheduleStatus>1</ScheduleStatus>
<AvailableNum>225</AvailableNum>
      <AvailableTotalNum>225</AvailableTotalNum>
      <AvailableLeftNum>223</AvailableLeftNum>
      <TimeRangeFlag>1</TimeRangeFlag>
    </Schedule>
    <Schedule>
      <ScheduleItemCode>2622||147</ScheduleItemCode>
      <ServiceDate>2017-08-18</ServiceDate>
      <WeekDay>5</WeekDay>
      <SessionCode>02</SessionCode>
      <SessionName>下午</SessionName>
      <StartTime>14:00</StartTime>
      <EndTime>17:00</EndTime>
      <DepartmentCode>138</DepartmentCode>
      <DepartmentName>内分泌代谢科门诊</DepartmentName>
      <DoctorCode>2502</DoctorCode>
      <DoctorName>普通号</DoctorName>
      <DoctorTitleCode>2</DoctorTitleCode>
      <DoctorTitle>普通号</DoctorTitle>
      <DoctorSessTypeCode>2</DoctorSessTypeCode>
      <DoctorSessType>普通号</DoctorSessType>
      <Fee>4</Fee>
      <RegFee>1</RegFee>
      <CheckupFee>3</CheckupFee>
      <OtherFee>0</OtherFee>
      <AvailableNumStr>1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180</AvailableNumStr>
      <AdmitAddress>门诊楼二楼</AdmitAddress>
      <ScheduleStatus>1</ScheduleStatus>
<AvailableNum>180</AvailableNum>
      <AvailableTotalNum>180</AvailableTotalNum>
      <AvailableLeftNum>180</AvailableLeftNum>
      <TimeRangeFlag>1</TimeRangeFlag>
    </Schedule>
  </Schedules>
</Response>";
            return response;
        }



        //获取医保挂号HIS信息
        [WebMethod]
        public string GetInsuRegPara(string InValue)
        {

            String response = @"<Response><ResultCode>0</ResultCode><AdmReasonAdmSource>1</AdmReasonAdmSource><AdmReason>4</AdmReason><Handle>0</Handle><UserID>2528</UserID><ExpString>O^张茂如^14^10152^2528^^4^^ZYKMZ-中医科门诊^曹正柳^^!7802^110100001^挂号费^1!17259^480000006b^中医辨证论治(主任中医师)^13</ExpString></Response>";

            return response;
        }



        ///10015 10016 锁号
        [WebMethod]
        public string LockOrder(string InValue)
        {
            String response = "<TradeCode>10015</TradeCode>";
            if (InValue.Contains("<TradeCode>10015</TradeCode>"))
            {
                response = @"<Response><TradeCode>10015</TradeCode><ResultCode>0</ResultCode><ResultContent>加号成功</ResultContent><LockQueueNo>4</LockQueueNo><ScheduleItemCode>2498||14</ScheduleItemCode><AdmDoc>妇产科主任医生号</AdmDoc><AdmDate>2017-05-12</AdmDate><AdmTime>下午</AdmTime><RegFee>13</RegFee></Response>";
            }

            if (InValue.Contains("<TradeCode>10016</TradeCode>"))
            {
                response = @"<Response><TradeCode>10016</TradeCode><ResultCode>0</ResultCode><ResultContent>取消加号成功</ResultContent><LockQueueNo>4</LockQueueNo><ScheduleItemCode>2498||14</ScheduleItemCode><AdmDoc>妇产科主任医生号</AdmDoc><AdmDate>2017-05-12</AdmDate><AdmTime>下午</AdmTime><RegFee>13</RegFee></Response>";
            }

            return response;
        }


        //OPRegister -挂号、提前挂号 1101
        [WebMethod]
        public string OPRegister(string InValue)
        {
            String response = "<TradeCode>1101</TradeCode>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>挂号成功</ResultContent><SeqCode>4</SeqCode><RegFee>13</RegFee><AdmitAddress>门诊楼二楼</AdmitAddress><AdmNo>1225</AdmNo><DeptName>妇产科门诊</DeptName><DoctorName>谭布珍</DoctorName><DoctorLevelDesc>妇产科主任医生号</DoctorLevelDesc><TimeRange>下午</TimeRange><RegistrationID>811</RegistrationID></Response>";


            return response;
        }

        //QueryAdmOPReg -查询挂号记录 1104
        [WebMethod]
        public string QueryAdmOPReg(string InValue)
        {
            String response = "<TradeCode>1104</TradeCode>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordCount>1</RecordCount><Orders><Order><RegID>544304</RegID><RegDate>2017-11-20</RegDate><Status>正常</Status><PatName>董睿</PatName><PatientID>0001327769</PatientID><AdmitDate>2017-11-20</AdmitDate><HospitalName>南昌大学第二附属医院</HospitalName><DepartmentCode>135</DepartmentCode><Department>消化内科门诊</Department><DoctorCode>1983</DoctorCode><Doctor>文艺</Doctor><DoctorTitle>主任医生号</DoctorTitle><RegFee> 25.00元</RegFee><SeqCode>25</SeqCode><AdmitAddress>门诊楼二楼</AdmitAddress><SessionName>上午</SessionName><AdmitRange>2017-11-20 09:12-09:15</AdmitRange><ServiceName>1190</ServiceName><ReturnFlag>N</ReturnFlag><NotReturnReason>当天上午号自助机不可退</NotReturnReason></Order></Orders></Response>";


            return response;
        }

        //查询已经计费的检查医嘱信息
        [WebMethod]
        public string FindCheckOrderByType(string InValue)
        {
            String response = "<TradeCode>1104</TradeCode>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordCount>2</RecordCount><OrderLists><OrderList><OrderName>挂号费</OrderName><OrdItmId>799||1</OrdItmId><OrderTypeCode>2301</OrderTypeCode><OrderTypeDesc>挂号</OrderTypeDesc></OrderList><OrderList><OrderName>主任医师门诊诊查费</OrderName><OrdItmId>799||2</OrdItmId><OrderTypeCode>2201</OrderTypeCode><OrderTypeDesc>诊查</OrderTypeDesc></OrderList></OrderLists></Response>";


            return response;
        }

        //检查的签到（自助机）
        [WebMethod]
        public string SaveCheckOrder(string InValue)
        {
            String response = "<TradeCode>1104</TradeCode>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent></Response>";


            return response;
        }
        #endregion

        #region 10041 分时信息查询


        //10041 分时信息查询
        [WebMethod]
        public string QueryScheduleTimeInfo(string InValue)
        {

            String response = @"<Response><ResultCode>0</ResultCode><RecordCount>99</RecordCount><TimeRanges><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>1</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:00</StartTime><EndTime>08:02</EndTime><AvailableNumStr>1</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>2</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:02</StartTime><EndTime>08:04</EndTime><AvailableNumStr>2</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>3</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:04</StartTime><EndTime>08:06</EndTime><AvailableNumStr>3</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>4</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:06</StartTime><EndTime>08:08</EndTime><AvailableNumStr>4</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>5</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:08</StartTime><EndTime>08:10</EndTime><AvailableNumStr>5</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>6</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:10</StartTime><EndTime>08:12</EndTime><AvailableNumStr>6</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>7</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:12</StartTime><EndTime>08:14</EndTime><AvailableNumStr>7</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>8</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:14</StartTime><EndTime>08:16</EndTime><AvailableNumStr>8</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>9</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:16</StartTime><EndTime>08:18</EndTime><AvailableNumStr>9</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>10</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:18</StartTime><EndTime>08:20</EndTime><AvailableNumStr>10</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>11</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:20</StartTime><EndTime>08:22</EndTime><AvailableNumStr>11</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>12</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:22</StartTime><EndTime>08:24</EndTime><AvailableNumStr>12</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>13</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:24</StartTime><EndTime>08:26</EndTime><AvailableNumStr>13</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>14</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:26</StartTime><EndTime>08:28</EndTime><AvailableNumStr>14</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>15</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:28</StartTime><EndTime>08:30</EndTime><AvailableNumStr>15</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>16</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:30</StartTime><EndTime>08:32</EndTime><AvailableNumStr>16</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>17</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:32</StartTime><EndTime>08:34</EndTime><AvailableNumStr>17</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>18</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:34</StartTime><EndTime>08:36</EndTime><AvailableNumStr>18</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>19</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:36</StartTime><EndTime>08:38</EndTime><AvailableNumStr>19</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>20</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:38</StartTime><EndTime>08:40</EndTime><AvailableNumStr>20</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>21</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:40</StartTime><EndTime>08:42</EndTime><AvailableNumStr>21</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>22</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:42</StartTime><EndTime>08:44</EndTime><AvailableNumStr>22</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>23</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:44</StartTime><EndTime>08:46</EndTime><AvailableNumStr>23</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>24</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:46</StartTime><EndTime>08:48</EndTime><AvailableNumStr>24</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>25</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:48</StartTime><EndTime>08:50</EndTime><AvailableNumStr>25</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>26</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:50</StartTime><EndTime>08:52</EndTime><AvailableNumStr>26</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>27</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:52</StartTime><EndTime>08:54</EndTime><AvailableNumStr>27</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>28</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:54</StartTime><EndTime>08:56</EndTime><AvailableNumStr>28</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>29</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:56</StartTime><EndTime>08:58</EndTime><AvailableNumStr>29</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>30</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>08:58</StartTime><EndTime>09:00</EndTime><AvailableNumStr>30</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>31</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:00</StartTime><EndTime>09:02</EndTime><AvailableNumStr>31</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>32</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:02</StartTime><EndTime>09:04</EndTime><AvailableNumStr>32</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>33</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:04</StartTime><EndTime>09:06</EndTime><AvailableNumStr>33</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>34</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:06</StartTime><EndTime>09:08</EndTime><AvailableNumStr>34</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>35</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:08</StartTime><EndTime>09:10</EndTime><AvailableNumStr>35</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>36</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:10</StartTime><EndTime>09:12</EndTime><AvailableNumStr>36</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>37</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:12</StartTime><EndTime>09:14</EndTime><AvailableNumStr>37</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>38</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:14</StartTime><EndTime>09:16</EndTime><AvailableNumStr>38</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>39</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:16</StartTime><EndTime>09:18</EndTime><AvailableNumStr>39</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>40</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:18</StartTime><EndTime>09:20</EndTime><AvailableNumStr>40</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>41</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:20</StartTime><EndTime>09:22</EndTime><AvailableNumStr>41</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>42</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:22</StartTime><EndTime>09:24</EndTime><AvailableNumStr>42</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>43</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:24</StartTime><EndTime>09:26</EndTime><AvailableNumStr>43</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>44</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:26</StartTime><EndTime>09:28</EndTime><AvailableNumStr>44</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>45</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:28</StartTime><EndTime>09:30</EndTime><AvailableNumStr>45</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>46</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:30</StartTime><EndTime>09:32</EndTime><AvailableNumStr>46</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>47</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:32</StartTime><EndTime>09:34</EndTime><AvailableNumStr>47</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>48</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:34</StartTime><EndTime>09:36</EndTime><AvailableNumStr>48</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>49</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:36</StartTime><EndTime>09:38</EndTime><AvailableNumStr>49</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>50</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:38</StartTime><EndTime>09:40</EndTime><AvailableNumStr>50</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>51</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:40</StartTime><EndTime>09:42</EndTime><AvailableNumStr>51</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>52</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:42</StartTime><EndTime>09:44</EndTime><AvailableNumStr>52</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>53</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:44</StartTime><EndTime>09:46</EndTime><AvailableNumStr>53</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>54</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:46</StartTime><EndTime>09:48</EndTime><AvailableNumStr>54</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>55</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:48</StartTime><EndTime>09:50</EndTime><AvailableNumStr>55</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>56</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:50</StartTime><EndTime>09:52</EndTime><AvailableNumStr>56</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>57</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:52</StartTime><EndTime>09:54</EndTime><AvailableNumStr>57</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>58</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:54</StartTime><EndTime>09:56</EndTime><AvailableNumStr>58</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>59</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:56</StartTime><EndTime>09:58</EndTime><AvailableNumStr>59</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>60</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>09:58</StartTime><EndTime>10:00</EndTime><AvailableNumStr>60</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>61</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:00</StartTime><EndTime>10:02</EndTime><AvailableNumStr>61</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>62</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:02</StartTime><EndTime>10:04</EndTime><AvailableNumStr>62</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>63</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:04</StartTime><EndTime>10:06</EndTime><AvailableNumStr>63</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>64</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:06</StartTime><EndTime>10:08</EndTime><AvailableNumStr>64</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>65</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:08</StartTime><EndTime>10:10</EndTime><AvailableNumStr>65</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>66</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:10</StartTime><EndTime>10:12</EndTime><AvailableNumStr>66</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>67</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:12</StartTime><EndTime>10:14</EndTime><AvailableNumStr>67</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>68</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:14</StartTime><EndTime>10:16</EndTime><AvailableNumStr>68</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>69</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:16</StartTime><EndTime>10:18</EndTime><AvailableNumStr>69</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>70</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:18</StartTime><EndTime>10:20</EndTime><AvailableNumStr>70</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>71</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:20</StartTime><EndTime>10:22</EndTime><AvailableNumStr>71</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>72</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:22</StartTime><EndTime>10:24</EndTime><AvailableNumStr>72</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>73</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:24</StartTime><EndTime>10:26</EndTime><AvailableNumStr>73</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>74</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:26</StartTime><EndTime>10:28</EndTime><AvailableNumStr>74</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>75</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:28</StartTime><EndTime>10:30</EndTime><AvailableNumStr>75</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>76</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:30</StartTime><EndTime>10:32</EndTime><AvailableNumStr>76</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>77</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:32</StartTime><EndTime>10:34</EndTime><AvailableNumStr>77</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>78</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:34</StartTime><EndTime>10:36</EndTime><AvailableNumStr>78</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>79</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:36</StartTime><EndTime>10:38</EndTime><AvailableNumStr>79</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>80</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:38</StartTime><EndTime>10:40</EndTime><AvailableNumStr>80</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>81</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:40</StartTime><EndTime>10:42</EndTime><AvailableNumStr>81</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>82</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:42</StartTime><EndTime>10:44</EndTime><AvailableNumStr>82</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>83</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:44</StartTime><EndTime>10:46</EndTime><AvailableNumStr>83</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>84</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:46</StartTime><EndTime>10:48</EndTime><AvailableNumStr>84</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>85</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:48</StartTime><EndTime>10:50</EndTime><AvailableNumStr>85</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>86</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:50</StartTime><EndTime>10:52</EndTime><AvailableNumStr>86</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>87</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:52</StartTime><EndTime>10:54</EndTime><AvailableNumStr>87</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>88</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:54</StartTime><EndTime>10:56</EndTime><AvailableNumStr>88</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>89</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:56</StartTime><EndTime>10:58</EndTime><AvailableNumStr>89</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>90</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>10:58</StartTime><EndTime>11:00</EndTime><AvailableNumStr>90</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>91</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>11:00</StartTime><EndTime>11:02</EndTime><AvailableNumStr>91</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>92</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>11:02</StartTime><EndTime>11:04</EndTime><AvailableNumStr>92</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>93</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>11:04</StartTime><EndTime>11:06</EndTime><AvailableNumStr>93</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>94</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>11:06</StartTime><EndTime>11:08</EndTime><AvailableNumStr>94</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>95</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>11:08</StartTime><EndTime>11:10</EndTime><AvailableNumStr>95</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>96</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>11:10</StartTime><EndTime>11:12</EndTime><AvailableNumStr>96</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>97</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>11:12</StartTime><EndTime>11:14</EndTime><AvailableNumStr>97</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>98</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>11:14</StartTime><EndTime>11:16</EndTime><AvailableNumStr>98</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange><TimeRange><ScheduleItemCode>2750||8</ScheduleItemCode><TimeRangeSeqNo>99</TimeRangeSeqNo><ServiceDate>2017-07-01</ServiceDate><WeekDay>6</WeekDay><SessionName>上午</SessionName><StartTime>11:16</StartTime><EndTime>11:18</EndTime><AvailableNumStr>99</AvailableNumStr><AvailableTotalNum>1</AvailableTotalNum><AvailableLeftNum>1</AvailableLeftNum><DoctorSessTypeCode>4</DoctorSessTypeCode><DoctorSessType>主任医生号</DoctorSessType><DoctorCode>2531</DoctorCode><DoctorName>温志立</DoctorName><DepartmentCode>135</DepartmentCode><DepartmentName>XHNKMZ-消化内科门诊</DepartmentName></TimeRange></TimeRanges></Response>";

            return response;
        }
        #endregion


    }
}
