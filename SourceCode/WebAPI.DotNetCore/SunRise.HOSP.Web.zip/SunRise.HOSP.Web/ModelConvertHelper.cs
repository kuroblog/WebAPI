﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace SunRise.HOSP.Web
{
    public class ModelConvertHelper
    {
        public static object XmlToModel(string xml)
        {
            object ReturnModel = new object();
            try
            {
                xml = xml.Replace("\"{", "{").Replace("}\"", "}").Replace("\\\"", "\"");

                ReturnModel = Newtonsoft.Json.JsonConvert.DeserializeObject(xml);

                ReturnModel = DeserializeJsonToObject<object>(xml);


                //SunRise.HOSP.Common.Log.WriteModuleLogLn(LogType.ErrorLog, LogModule.WebService, "测试报文2:" + ReturnModel.GetType());
                //SunRise.HOSP.Common.Log.WriteModuleLogLn(LogType.ErrorLog, LogModule.WebService, "测试报文3:" + ((JsonOut_GetPatientCardNo)ReturnModel).result);
            }
            catch (Exception ex)
            {

            }

            return ReturnModel;

        }
        /// <summary>
        /// 解析JSON字符串生成对象实体
        /// </summary>
        /// <typeparam name="T">对象类型</typeparam>
        /// <param name="json">json字符串(eg.{"ID":"112","Name":"石子儿"})</param>
        /// <returns>对象实体</returns>
        public static T DeserializeJsonToObject<T>(string json) where T : class
        {
            JsonSerializer serializer = new JsonSerializer();
            StringReader sr = new StringReader(json);
            object o = serializer.Deserialize(new JsonTextReader(sr), typeof(T));
            T t = o as T;
            return t;
        }
  
    }
    

}