﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace SunRise.HOSP.Web
{
    /// <summary>
    /// WebService1 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }


        #region 获取病人住院就诊信息 GetIPPatAdmInfo

        [WebMethod]
        public string GetIPPatAdmInfo(string InValue)
        {
            ///*
            // <Response><ResultCode>-3</ResultCode><ResultContent>此病人不在院.</ResultContent><PatientID>0001304954</PatientID><PatientName>许美红</PatientName><SexCode>2</SexCode><Sex>女</Sex><DOB>1939-07-07</DOB><MRID>0954671</MRID><Address>江西省上饶市鄱阳县侯家岗乡程团村</Address><IDTypeCode>01</IDTypeCode><IDType>居民身份证</IDType><IDNo>362330193907071766</IDNo><PatType></PatType><AdmID></AdmID><AdmDate></AdmDate><AdmLoc></AdmLoc><DepositAmount></DepositAmount><PrepayAmout></PrepayAmout><Settled></Settled><TotalAmout></TotalAmout><MedcareNo>0954671</MedcareNo><DiscChargeDate></DiscChargeDate><InDays></InDays><PatVisutus>出院</PatVisutus><HospitalId></HospitalId><DeptId>174</DeptId><BedNo></BedNo><ChargeDoctorId></ChargeDoctorId><ChargeDoctorName></ChargeDoctorName><ChargeNurseId></ChargeNurseId><ChargeNurseName></ChargeNurseName><ConnectPhone></ConnectPhone><RelatePerson></RelatePerson><Relation></Relation><RelatePhone></RelatePhone><Remark></Remark></Response>

            // */

            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>获取就诊记录成功 </ResultContent><PatientID>0001050532</PatientID><PatientName>熊连香 </PatientName><SexCode>2</SexCode><Sex>女</Sex><DOB>1960-01- 15</DOB><MRID>0914272</MRID><Address>360121</Address><IDTypeCode>01</IDTypeCode><IDType>居民身份证 </IDType><IDNo>360121196001156928</IDNo><PatType>城镇居民医保 </PatType><AdmID>496444</AdmID><AdmDate>2017-11-10</AdmDate><AdmLoc>DSYBQ-东十一病区 </AdmLoc><DepositAmount>40883.32</DepositAmount><PrepayAmout>185000</PrepayAmout><Settled></Settled> <TotalAmout>144116.68</TotalAmout><MedcareNo>0914272</MedcareNo><DiscChargeDate></DiscChargeDate><InDays>15</InDays><PatVisutus>在院 </PatVisutus><HospitalId></HospitalId><DeptId>182</DeptId><BedNo></BedNo><ChargeDoctorId></ChargeDoctorId><ChargeDoctorName></ChargeDoctorName><ChargeNurseId></ChargeNurseId><ChargeNurseName></ChargeNurseName><ConnectPhone></ConnectPhone><RelatePerson></RelatePerson><Relation></Relation><RelatePhone ></RelatePhone><Remark></Remark><DepName>XZDXGWK-心脏大血管外科 </DepName><AdmLocId>52</AdmLocId></Response>";


            return response;
        }
        //住院结算
        [WebMethod]
        public string GetIPPatientInfo(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><PatientID>0001131702</PatientID><PatientName>刘宝石</PatientName><Sex>男</Sex><DOB>1989-03-31</DOB><MRID>0940667</MRID><Address>吉林省洮南市</Address><IDType>居民身份证</IDType><IDNo>2208811989****0536</IDNo><PatType>一般病人</PatType></Response>";


            return response;
        }
        #endregion

        #region 住院押金充值 没有传adm默认当前在院adm AddIPDeposit

        [WebMethod]
        public string AddIPDeposit(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>交押金成功</ResultContent><DepositAmount>1.21</DepositAmount></Response>";


            return response;
        }
        #endregion


        #region 住院押金充值查询 GetDepPayRecord

        [WebMethod]
        public string GetIPDepositRecord(string InValue)
        {
            String response = "12354";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordInfoList><RecordInfo><PayTime>2017-08-2119:06:00</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>正常</PayFlag><Remark>已使用</Remark></RecordInfo><RecordInfo><PayTime>2017-08-2608:36:59</PayTime><PayAmout>5000</PayAmout><PayMode>银行卡</PayMode><PayFlag>正常</PayFlag><Remark>已使用</Remark></RecordInfo><RecordInfo><PayTime>2017-08-2612:09:39</PayTime><PayAmout>30000</PayAmout><PayMode>银行卡</PayMode><PayFlag>正常</PayFlag><Remark>已使用</Remark></RecordInfo><RecordInfo><PayTime>2017-08-2914:45:41</PayTime><PayAmout>4760.69</PayAmout><PayMode>银行卡</PayMode><PayFlag>正常</PayFlag><Remark>已使用</Remark></RecordInfo></RecordInfoList></Response>";


            return response;
        }
        #endregion

        #region 住院日清单 GetIPDailyBill

        [WebMethod]
        public string GetIPDailyBill(string InValue)
        {
            String response = "12354";

            response = @"<Response>
	<ResultCode>0</ResultCode>
	<ErrorMsg>成功</ErrorMsg>
	<PatientID>0000000061</PatientID>
	<PatName>徐业贵</PatName>
	<PatAge>30岁</PatAge>
	<PatSex>男</PatSex>
	<AdmReason>一般病人</AdmReason>
	<Department>XWK-胸外科</Department>
	<Ward>综十病区</Ward>
	<BedNO>01</BedNO>
	<PatFee>1518.56</PatFee>
	<Deposit>500035.01</Deposit>
	<VisitStatus>A</VisitStatus>
	<PrintFlag>N</PrintFlag>
	<PrintTimes>0</PrintTimes>
	<TarItemList>
		<TarItemDetail>
			<Index>1</Index>
			<Category>诊查费</Category>
			<ItemName>住院诊查费</ItemName>
			<Qty>1</Qty>
			<UOM>日</UOM>
			<Price>7.0000</Price>
			<TotalAmt>7.00</TotalAmt>
			<DisAmt>0</DisAmt>
			<PayorAmt>0</PayorAmt>
			<PatShareAmt>0</PatShareAmt>
			<BillDate>2017-07-27</BillDate>
			<BillTime>00:05:00</BillTime>
			<InsuRatio/>
			<InsuClass/>
			<ItemChargeBasis>110200005</ItemChargeBasis>
		</TarItemDetail>
		<TarItemDetail>
			<Index>2</Index>
			<Category>取暖降温费</Category>
			<ItemName>病房空调降温费(中央空调)</ItemName>
			<Qty>1</Qty>
			<UOM>日</UOM>
			<Price>8.0000</Price>
			<TotalAmt>8.00</TotalAmt>
			<DisAmt>0</DisAmt>
			<PayorAmt>0</PayorAmt>
			<PatShareAmt>0</PatShareAmt>
			<BillDate>2017-07-27</BillDate>
			<BillTime>00:05:00</BillTime>
			<InsuRatio/>
			<InsuClass/>
			<ItemChargeBasis>110800001b</ItemChargeBasis>
		</TarItemDetail>
		<TarItemDetail>
			<Index>3</Index>
			<Category>床位费</Category>
			<ItemName>5人间及以上床位费</ItemName>
			<Qty>1</Qty>
			<UOM>日</UOM>
			<Price>18.0000</Price>
			<TotalAmt>18.00</TotalAmt>
			<DisAmt>0</DisAmt>
			<PayorAmt>0</PayorAmt>
			<PatShareAmt>0</PatShareAmt>
			<BillDate>2017-07-27</BillDate>
			<BillTime>00:05:00</BillTime>
			<InsuRatio/>
			<InsuClass/>
			<ItemChargeBasis>110900001y</ItemChargeBasis>
		</TarItemDetail>
	</TarItemList>
</Response>";


            return response;
        }
        #endregion

        #region 住院费用汇总查询 GetIPTotalCost

        [WebMethod]
        public string GetIPTotalCost(string InValue)
        {
            String response = @"<Request><TradeCode></TradeCode><HospitalId>000</HospitalId><AdmID>152087</AdmID><PatientID></PatientID><TypeCode>诊查费</TypeCode><BillDate></BillDate><Page></Page><Size></Size></Request>";
            ////老的
            //response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><totalAmout>130654</totalAmout><prepayAmout>4181100</prepayAmout><unsettled>103104</unsettled><validPrepayAmout>0</validPrepayAmout><feeInfo><TarOCCateItem><TarOCCateDesc>诊查费</TarOCCateDesc><TarOCCateCode>诊查费</TarOCCateCode><TarOCCateAmt>18200</TarOCCateAmt></TarOCCateItem><TarOCCateItem><TarOCCateDesc>治疗费</TarOCCateDesc><TarOCCateCode>治疗费</TarOCCateCode><TarOCCateAmt>19200</TarOCCateAmt></TarOCCateItem><TarOCCateItem><TarOCCateDesc>检查费</TarOCCateDesc><TarOCCateCode>检查费</TarOCCateCode><TarOCCateAmt>8000</TarOCCateAmt></TarOCCateItem><TarOCCateItem><TarOCCateDesc>床位费</TarOCCateDesc><TarOCCateCode>床位费</TarOCCateCode><TarOCCateAmt>85250</TarOCCateAmt></TarOCCateItem><TarOCCateItem><TarOCCateDesc>西药费</TarOCCateDesc><TarOCCateCode>西药费</TarOCCateCode><TarOCCateAmt>4</TarOCCateAmt></TarOCCateItem></feeInfo></Response>";
            //新的
            /*
             入参:
	<Request><TradeCode></TradeCode><AdmID>70364</AdmID></Request>
             */
            response = @"<Response>
  <ResultCode>0</ResultCode>
  <ResultContent>成功</ResultContent>
  <TotalAmout>21866.49</TotalAmout>
  <PrepayAmout>5000</PrepayAmout>
  <ValidPrepayAmout>5000</ValidPrepayAmout>
  <Unsettled>21866.49</Unsettled>
  <FeeInfoList>
    <FeeInfo>
      <TypeCode> 诊查费</TypeCode>
      <TypeName>诊查费</TypeName>
      <TypeAmout>2862</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>治疗费</TypeCode>
      <TypeName>治疗费</TypeName>
      <TypeAmout>2552.08</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>检查费</TypeCode>
      <TypeName>检查费</TypeName>
      <TypeAmout>1430</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>
        取暖降温费
      </TypeCode>
      <TypeName>取暖降温费</TypeName>
      <TypeAmout>800</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>床位费</TypeCode>
      <TypeName>床位费</TypeName>
      <TypeAmout>6600</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>护理费</TypeCode>
      <TypeName>护理费</TypeName>
      <TypeAmout>3010.57</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>检验费</TypeCode>
      <TypeName> 检验费</TypeName>
      <TypeAmout>2728</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>材料费</TypeCode>
      <TypeName>材料费</TypeName>
      <TypeAmout>696.75</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>西药费</TypeCode>
      <TypeName>西药费</TypeName>
      <TypeAmout>635.09</TypeAmout>
    </FeeInfo>
    <FeeInfo>
      <TypeCode>中成药费</TypeCode>
      <TypeName>中成药费</TypeName>
      <TypeAmout>552</TypeAmout>
    </FeeInfo>
  </FeeInfoList>
</Response>";

            return response;
        }
        #endregion

        #region 住院费用分类明细 GetIPDetailCost

        [WebMethod]
        public string GetIPDetailCost(string InValue)
        {
            String response = "";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordCount>5</RecordCount><RecordInfoList><Record><DatailCat>诊查费</DatailCat><DetailId>110200005</DetailId><DetailName>住院诊查费</DetailName><DetailPrice>30</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>30</DetailAmout></Record><Record><DatailCat>取暖降温费</DatailCat><DetailId>110700001</DetailId><DetailName>病房取暖费(中央空调)</DetailName><DetailPrice>8</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>8</DetailAmout></Record><Record><DatailCat>取暖降温费</DatailCat><DetailId>110800001b</DetailId><DetailName>病房空调降温费(中央空调)</DetailName><DetailPrice>8</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>8</DetailAmout></Record><Record><DatailCat>床位费</DatailCat><DetailId>110900001c</DetailId><DetailName>双人间床位费</DetailName><DetailPrice>35</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>35</DetailAmout></Record><Record><DatailCat>床位费</DatailCat><DetailId>110900001p</DetailId><DetailName>两人间床位费(医疗中心大楼)</DetailName><DetailPrice>55</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>55</DetailAmout></Record></RecordInfoList></Response>";
            /*<Request><TradeCode></TradeCode><AdmID>70364</AdmID><BillDate></BillDate><Page>1</Page><Size>20</Size></Request>*/
            // response = @"<Response><ResultCode>0</ResultCode><ResultContent>查询成功</ResultContent><RecordCount>180</RecordCount><RecordInfoList><Record><DatailCat>诊查费</DatailCat><DetailId>110200005</DetailId><DetailName>住院诊查费</DetailName><DetailPrice>7</DetailPrice><DetailCount>1</DetailCount><DetailUnit>日</DetailUnit><DetailAmout>7</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400001b</DetailId><DetailName>皮内注射（6岁以下儿童）</DetailName><DetailPrice>2</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>2</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400002</DetailId><DetailName>静脉注射</DetailName><DetailPrice>4</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>4</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400002a</DetailId><DetailName>静脉采血</DetailName><DetailPrice>3</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>3</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400006</DetailId><DetailName>静脉输液</DetailName><DetailPrice>5</DetailPrice><DetailCount>1</DetailCount><DetailUnit>组</DetailUnit><DetailAmout>5</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400006b</DetailId><DetailName>静脉注药</DetailName><DetailPrice>5</DetailPrice><DetailCount>1</DetailCount><DetailUnit>组</DetailUnit><DetailAmout>5</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400006c</DetailId><DetailName>静脉输液(从第二组起)</DetailName><DetailPrice>1</DetailPrice><DetailCount>1</DetailCount><DetailUnit>组</DetailUnit><DetailAmout>1</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400006f</DetailId><DetailName>使用微量泵或输液泵加收</DetailName><DetailPrice>1</DetailPrice><DetailCount>1</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>1</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120400012</DetailId><DetailName>动脉穿刺置管术</DetailName><DetailPrice>50</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>50</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120600003</DetailId><DetailName>中换药</DetailName><DetailPrice>15</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>15</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>120700001b</DetailId><DetailName>高压泵氧气雾化</DetailName><DetailPrice>8</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>8</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310607006</DetailId><DetailName>舱外高流量吸氧</DetailName><DetailPrice>5</DetailPrice><DetailCount>.46</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>2.3</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310701021</DetailId><DetailName>动态血压监测(24小时内)</DetailName><DetailPrice>5</DetailPrice><DetailCount>4.83</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>24.15</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310701021a</DetailId><DetailName>动态血压监测(24小时后)</DetailName><DetailPrice>3</DetailPrice><DetailCount>4.83</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>14.49</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310701022</DetailId><DetailName>心电监测(24小时内)</DetailName><DetailPrice>5</DetailPrice><DetailCount>1</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>5</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310701028</DetailId><DetailName>血氧饱和度监测</DetailName><DetailPrice>3</DetailPrice><DetailCount>4.83</DetailCount><DetailUnit>小时</DetailUnit><DetailAmout>14.49</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>310702001a</DetailId><DetailName>有创性血流动力学监测(床旁)(心排血量测定)</DetailName><DetailPrice>100</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>100</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>320500001</DetailId><DetailName>冠状动脉造影术</DetailName><DetailPrice>1600</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>1600</DetailAmout></Record><Record><DatailCat>治疗费</DatailCat><DetailId>320500002</DetailId><DetailName>经皮冠状动脉腔内成形术(PTCA)</DetailName><DetailPrice>2000</DetailPrice><DetailCount>1</DetailCount><DetailUnit>次</DetailUnit><DetailAmout>2000</DetailAmout></Record></RecordInfoList></Response>";
            return response;
        }
        #endregion

        #region 通过卡号获取住院有效就诊记录
        [WebMethod]
        public string GetIPAdmInfo(string InValue)
        {
            String response = "<Request><TradeCode></TradeCode><PatientCard>620101198001010491</PatientCard><ExtUserID>ZZJ001</ExtUserID><PatientID></PatientID><AimFlag>Dep</AimFlag></Request>";
            ////获取交押金就诊 Dep
            //response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><AdmInfoList><AdmInfo><AdmID>152049</AdmID><AdmDate>2017-10-20</AdmDate><AdmLoc>中医科</AdmLoc><AdmReason>跨省新农合</AdmReason><NationalCode>4</NationalCode><DepositAmount>5000.00</DepositAmount><TotalAmount>19209.18</TotalAmount><DepositBalance>-14209.18</DepositBalance></AdmInfo></AdmInfoList></Response>";
            //获取出院结算就诊 Pay
            response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><PatientID>0001131702</PatientID><PatientName>刘宝石</PatientName><Sex>男</Sex><DOB>1989-03-31</DOB><MRID>0940667</MRID><Address>吉林省洮南市</Address><IDType>居民身份证</IDType><IDNo>220881198903310536</IDNo><PatType>一般病人</PatType><AdmInfoList><AdmInfo><AdmID>152087</AdmID><AdmDate>2017-12-19</AdmDate><InDays>1</InDays><AdmLoc>胸外科</AdmLoc><AdmLocId>180</AdmLocId><BQ>BSYBQ-北十一病区</BQ><BQID>9</BQID><BillNo>544539</BillNo><AdmStutas>出院未结算</AdmStutas><AdmReason>一般病人</AdmReason><DepositAmount>150.00</DepositAmount><TotalAmount>136.00</TotalAmount><DepositBalance>14.00</DepositBalance></AdmInfo></AdmInfoList></Response>";
            ////获取出院结算就诊 All
            //response = @"<Response><ResultCode>0</ResultCode><ResultContent>成功</ResultContent><AdmInfoList><AdmInfo><AdmID>134236</AdmID><AdmDate>2017-09-02</AdmDate><AdmLoc>肾脏内科</AdmLoc><AdmReason>普通医保</AdmReason><NationalCode>1</NationalCode><DepositAmount>0</DepositAmount><TotalAmount>21866.49</TotalAmount><DepositBalance>0</DepositBalance></AdmInfo><AdmInfo><AdmID>99946</AdmID><AdmDate>2017-08-27</AdmDate><AdmLoc>妇科</AdmLoc><AdmReason>普通医保</AdmReason><NationalCode>1</NationalCode><DepositAmount>0</DepositAmount><TotalAmount>3877.02</TotalAmount><DepositBalance>0</DepositBalance></AdmInfo></AdmInfoList></Response>";
            return response;
        }
        #endregion

        #region 出院费用核查
        [WebMethod]
        public string CheckBillFee(string InValue)
        {
            String response = @"<Request><TradeCode></TradeCode><PatientCard>220881198903310536</PatientCard><ExtUserID>ZZJ001</ExtUserID><PatientID></PatientID><AdmID>152087</AdmID><DepositAmount>151.00</DepositAmount><BillNo>544509</BillNo><TotalAmount>136.00</TotalAmount ><PatShare>136.00</PatShare><InsuShare></InsuShare></Request>";
            //
            //  response = @"<Response><ResultCode>0</ResultCode><ResultContent>费用核查成功</ResultContent><AdmID>152049</AdmID><BillNo>544161</BillNo><AdmReason>跨省新农合</AdmReason><NationalCode>4</NationalCode ><TotalAmount>19209.18</TotalAmount><PatShare>19209.18</PatShare ><InsuShare>0.00</InsuShare><DepositAmount>20000.00</DepositAmount><DepositBalance>790.82</DepositBalance ></Response>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>费用核查成功</ResultContent><AdmInfoList><AdmInfo><AdmID>152087</AdmID><AdmDate>2017-11-12</AdmDate><AdmLoc>胸外科</AdmLoc><BillNo>544513</BillNo><AdmReason>一般病人</AdmReason><DepositAmount>150.00</DepositAmount><TotalAmount>136.00</TotalAmount><DepositBalance>14.00</DepositBalance><PatShare>136.00</PatShare><InsuShare>0.00</InsuShare></AdmInfo></AdmInfoList></Response>";
            return response;
        }
        #endregion

        #region 出院结算
        [WebMethod]
        public string IPBillPay(string InValue)
        {
            String response = @"<Request><TradeCode></TradeCode><PatientCard>620101198001010491</PatientCard><ExtUserID>ZZJ001</ExtUserID><PatientID></PatientID><AdmID>152049</AdmID><DepositAmount>20000.00</DepositAmount><BillNo>544161</BillNo><TotalAmount>19209.18</TotalAmount><PatShare>19209.18</PatShare><InsuShare></InsuShare></Request>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>出院结算成功</ResultContent><Invoice>9722</Invoice><BankCardList><BankCardInfo><BankCode>903</BankCode></BankCardInfo><BankCardInfo></BankCardInfo><BankCardInfo><BankCode>903</BankCode></BankCardInfo><BankCardInfo><BankCode>903</BankCode></BankCardInfo><BankCardInfo><BankCode>903</BankCode></BankCardInfo><BankCardInfo><BankCode>903</BankCode></BankCardInfo><BankCardInfo><BankCode>902</BankCode></BankCardInfo><BankCardInfo></BankCardInfo><BankCardInfo><BankCode>105</BankCode></BankCardInfo><BankCardInfo><BankCode>001</BankCode></BankCardInfo></BankCardList></Response>";


            return response;
        }
        #endregion

        #region 补退信息通知
        [WebMethod]
        public string PayResult(string InValue)
        {
            String response = @"<Request><TradeCode></TradeCode><PatientCard>620101198001010491</PatientCard><ExtUserID>ZZJ001</ExtUserID><PatientID></PatientID><AdmID>152049</AdmID><Invoice>9704</Invoice><PaidFlag>1</PaidFlag><Amount>790.82</Amount><PayModeCode>MISPOS</PayModeCode><BankCardNo>6217984240000164646</BankCardNo><POSTradeInfo>006217984240000164646R0000007908200001001   000046      0000012017121514360914360987184244842108062001142104982</POSTradeInfo></Request>";

            response = @"<Response><ResultCode>0</ResultCode><ResultContent>通知成功</ResultContent></Response>";


            return response;
        }
        #endregion

    }
}
